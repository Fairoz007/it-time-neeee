-- 1. Ensure the role column exists in the profiles table
ALTER TABLE IF EXISTS profiles 
ADD COLUMN IF NOT EXISTS role VARCHAR(50) DEFAULT 'user' NOT NULL;

-- 2. Find users in auth.users that don't have profiles
-- Note: This query requires access to the auth schema which may be restricted
WITH auth_users AS (
  SELECT id FROM auth.users
)
SELECT id FROM auth_users
WHERE id NOT IN (SELECT user_id FROM profiles);

-- 3. Insert missing users into profiles table
-- This is a template - you'll need to replace the values
INSERT INTO profiles (user_id, full_name, email, role, created_at, updated_at)
VALUES 
('user-id-1', 'User Name', 'user@example.com', 'user', NOW(), NOW()),
('user-id-2', 'Another User', 'another@example.com', 'user', NOW(), NOW());

-- 4. Update profiles without roles
UPDATE profiles
SET role = 'user', updated_at = NOW()
WHERE role IS NULL OR role = '';
