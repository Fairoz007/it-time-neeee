import { syncUsersToProfiles, ensureProfileRoles } from "../lib/sync-users-to-profiles"

async function main() {
  console.log("Starting user synchronization process...")

  // First ensure all users have profiles
  const syncResult = await syncUsersToProfiles()
  console.log(syncResult.success ? "✅ " : "❌ ", syncResult.message || syncResult.error)

  // Then ensure all profiles have roles
  const roleResult = await ensureProfileRoles()
  console.log(roleResult.success ? "✅ " : "❌ ", roleResult.message || roleResult.error)

  console.log("User synchronization process completed")
}

main().catch((error) => {
  console.error("Error in sync-users script:", error)
  process.exit(1)
})
