/**
 * Security utilities to protect against common web vulnerabilities
 */

// Content Security Policy (CSP) header value
export const contentSecurityPolicy = {
  "default-src": ["'self'"],
  "script-src": ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://analytics.devtimetracker.com"],
  "style-src": ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
  "img-src": ["'self'", "data:", "https://images.devtimetracker.com", "https://secure.gravatar.com"],
  "font-src": ["'self'", "https://fonts.gstatic.com"],
  "connect-src": ["'self'", "https://api.devtimetracker.com"],
  "frame-src": ["'none'"],
  "object-src": ["'none'"],
  "base-uri": ["'self'"],
  "form-action": ["'self'"],
}

// Generate CSP header string
export function generateCSP() {
  return Object.entries(contentSecurityPolicy)
    .map(([key, values]) => `${key} ${values.join(" ")}`)
    .join("; ")
}

// Sanitize user input to prevent XSS attacks
export function sanitizeInput(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
}

// Validate and sanitize URL to prevent open redirect vulnerabilities
export function sanitizeUrl(url: string): string {
  // Only allow http:// and https:// protocols
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    return "#"
  }

  // Only allow specific domains
  const allowedDomains = [
    "devtimetracker.com",
    "www.devtimetracker.com",
    "api.devtimetracker.com",
    "docs.devtimetracker.com",
  ]

  try {
    const urlObj = new URL(url)
    if (!allowedDomains.includes(urlObj.hostname)) {
      return "#"
    }
    return url
  } catch (e) {
    return "#"
  }
}

// Generate a nonce for CSP
export function generateNonce(): string {
  const array = new Uint8Array(16)
  crypto.getRandomValues(array)
  return Array.from(array, (byte) => byte.toString(16).padStart(2, "0")).join("")
}

// Prevent clickjacking by setting X-Frame-Options
export const xFrameOptions = "SAMEORIGIN"

// Prevent MIME type sniffing
export const xContentTypeOptions = "nosniff"

// Enable XSS protection in older browsers
export const xXssProtection = "1; mode=block"

// Referrer policy
export const referrerPolicy = "strict-origin-when-cross-origin"

// Permissions policy
export const permissionsPolicy = "camera=(), microphone=(), geolocation=()"

// CSRF token generation
export function generateCsrfToken(): string {
  const array = new Uint8Array(32)
  crypto.getRandomValues(array)
  return Array.from(array, (byte) => byte.toString(16).padStart(2, "0")).join("")
}

// Validate CSRF token
export function validateCsrfToken(token: string, storedToken: string): boolean {
  if (!token || !storedToken) {
    return false
  }

  // Use timing-safe comparison to prevent timing attacks
  let valid = true
  let mismatch = 0

  for (let i = 0; i < token.length; i++) {
    if (i >= storedToken.length || token[i] !== storedToken[i]) {
      mismatch++
    }
  }

  if (mismatch > 0 || token.length !== storedToken.length) {
    valid = false
  }

  return valid
}

// Rate limiting utility
export class RateLimiter {
  private requests: Map<string, { count: number; resetTime: number }>
  private limit: number
  private windowMs: number

  constructor(limit = 100, windowMs = 60000) {
    this.requests = new Map()
    this.limit = limit
    this.windowMs = windowMs
  }

  check(ip: string): boolean {
    const now = Date.now()
    const record = this.requests.get(ip)

    if (!record) {
      this.requests.set(ip, { count: 1, resetTime: now + this.windowMs })
      return true
    }

    if (now > record.resetTime) {
      record.count = 1
      record.resetTime = now + this.windowMs
      return true
    }

    if (record.count >= this.limit) {
      return false
    }

    record.count++
    return true
  }

  getRemainingRequests(ip: string): number {
    const now = Date.now()
    const record = this.requests.get(ip)

    if (!record) {
      return this.limit
    }

    if (now > record.resetTime) {
      return this.limit
    }

    return Math.max(0, this.limit - record.count)
  }

  getResetTime(ip: string): number | null {
    const record = this.requests.get(ip)
    return record ? record.resetTime : null
  }
}
