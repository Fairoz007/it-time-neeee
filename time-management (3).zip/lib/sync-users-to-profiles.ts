import { supabase } from "./supabase-client"

/**
 * Syncs all users from auth.users to the profiles table
 * Adds missing users and ensures role column is populated
 */
export async function syncUsersToProfiles() {
  try {
    console.log("Starting user to profile synchronization...")

    // Step 1: Get all users from auth.users
    const { data: authUsers, error: authError } = await supabase.auth.admin.listUsers()

    if (authError) {
      console.error("Error fetching auth users:", authError)
      return { success: false, error: authError.message }
    }

    if (!authUsers || !authUsers.users || authUsers.users.length === 0) {
      console.log("No users found in auth.users")
      return { success: true, message: "No users to sync" }
    }

    console.log(`Found ${authUsers.users.length} users in auth.users`)

    // Step 2: Get all existing profiles
    const { data: existingProfiles, error: profilesError } = await supabase.from("profiles").select("user_id")

    if (profilesError) {
      console.error("Error fetching existing profiles:", profilesError)
      return { success: false, error: profilesError.message }
    }

    // Create a set of existing user_ids for quick lookup
    const existingUserIds = new Set(existingProfiles?.map((profile) => profile.user_id) || [])
    console.log(`Found ${existingUserIds.size} existing profiles`)

    // Step 3: Find users without profiles
    const usersToAdd = authUsers.users.filter((user) => !existingUserIds.has(user.id))
    console.log(`Found ${usersToAdd.length} users without profiles`)

    if (usersToAdd.length === 0) {
      return { success: true, message: "All users already have profiles" }
    }

    // Step 4: Create profiles for users without them
    // Note: We're not specifying the id field, letting the database generate it
    const profilesToInsert = usersToAdd.map((user) => ({
      // id field is omitted to let the database generate it
      user_id: user.id,
      full_name: user.user_metadata?.full_name || user.user_metadata?.name || user.email?.split("@")[0] || "User",
      email: user.email || "",
      role: user.user_metadata?.role || "user", // Default to 'user' role
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }))

    // Insert profiles in batches of 50 to avoid hitting limits
    const batchSize = 50
    let successCount = 0

    for (let i = 0; i < profilesToInsert.length; i += batchSize) {
      const batch = profilesToInsert.slice(i, i + batchSize)
      const { error: insertError, count } = await supabase.from("profiles").insert(batch)

      if (insertError) {
        console.error(`Error inserting batch ${i / batchSize + 1}:`, insertError)
      } else {
        successCount += count || batch.length
        console.log(`Successfully inserted batch ${i / batchSize + 1} (${batch.length} profiles)`)
      }
    }

    return {
      success: true,
      message: `Added ${successCount} out of ${usersToAdd.length} missing profiles`,
    }
  } catch (error: any) {
    console.error("Exception in syncUsersToProfiles:", error)
    return { success: false, error: error.message || "Unknown error occurred" }
  }
}

/**
 * Updates all existing profiles to ensure they have a role
 */
export async function ensureProfileRoles() {
  try {
    console.log("Ensuring all profiles have roles...")

    // Find profiles without roles or with null roles
    const { data: profilesWithoutRoles, error: findError } = await supabase
      .from("profiles")
      .select("id, user_id")
      .or("role.is.null,role.eq.")

    if (findError) {
      console.error("Error finding profiles without roles:", findError)
      return { success: false, error: findError.message }
    }

    if (!profilesWithoutRoles || profilesWithoutRoles.length === 0) {
      console.log("All profiles already have roles")
      return { success: true, message: "All profiles already have roles" }
    }

    console.log(`Found ${profilesWithoutRoles.length} profiles without roles`)

    // Update profiles without roles to have the default 'user' role
    const { error: updateError } = await supabase
      .from("profiles")
      .update({ role: "user", updated_at: new Date().toISOString() })
      .in(
        "id",
        profilesWithoutRoles.map((p) => p.id),
      )

    if (updateError) {
      console.error("Error updating profiles with default roles:", updateError)
      return { success: false, error: updateError.message }
    }

    return {
      success: true,
      message: `Updated ${profilesWithoutRoles.length} profiles with default 'user' role`,
    }
  } catch (error: any) {
    console.error("Exception in ensureProfileRoles:", error)
    return { success: false, error: error.message || "Unknown error occurred" }
  }
}
