"use client"

import React from "react"

/**
 * Performance optimization utilities
 */

// Debounce function to limit how often a function can be called
export function debounce<T extends (...args: any[]) => any>(func: T, wait: number): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null

  return (...args: Parameters<T>): void => {
    if (timeout) {
      clearTimeout(timeout)
    }

    timeout = setTimeout(() => {
      func(...args)
    }, wait)
  }
}

// Throttle function to limit how often a function can be called
export function throttle<T extends (...args: any[]) => any>(func: T, limit: number): (...args: Parameters<T>) => void {
  let inThrottle = false

  return (...args: Parameters<T>): void => {
    if (!inThrottle) {
      func(...args)
      inThrottle = true
      setTimeout(() => {
        inThrottle = false
      }, limit)
    }
  }
}

// Memoize function to cache results of expensive function calls
export function memoize<T extends (...args: any[]) => any>(
  func: T,
  resolver?: (...args: Parameters<T>) => string,
): (...args: Parameters<T>) => ReturnType<T> {
  const cache = new Map<string, ReturnType<T>>()

  return (...args: Parameters<T>): ReturnType<T> => {
    const key = resolver ? resolver(...args) : JSON.stringify(args)

    if (cache.has(key)) {
      return cache.get(key)!
    }

    const result = func(...args)
    cache.set(key, result)

    return result
  }
}

// Lazy loading utility for components
export function lazyLoad<T extends React.ComponentType<any>>(
  importFunc: () => Promise<{ default: T }>,
  fallback: React.ReactNode = null,
): React.LazyExoticComponent<T> & { preload: () => void } {
  const LazyComponent = React.lazy(importFunc)

  // Add preload method
  const PreloadableComponent = LazyComponent as React.LazyExoticComponent<T> & { preload: () => void }
  PreloadableComponent.preload = importFunc

  return PreloadableComponent
}

// Image optimization utility
export function getOptimizedImageUrl(
  url: string,
  width?: number,
  height?: number,
  quality = 80,
  format: "webp" | "jpeg" | "png" | "avif" = "webp",
): string {
  // In a real application, this would use an image optimization service
  // like Cloudinary, Imgix, or Next.js Image Optimization

  if (!url) return url

  // For demonstration purposes, we'll just append query parameters
  const params = new URLSearchParams()

  if (width) params.append("w", width.toString())
  if (height) params.append("h", height.toString())
  params.append("q", quality.toString())
  params.append("fmt", format)

  // Check if URL already has query parameters
  const separator = url.includes("?") ? "&" : "?"

  return `${url}${separator}${params.toString()}`
}

// Resource hints for performance
export function addResourceHints(resources: {
  preconnect?: string[]
  prefetch?: string[]
  preload?: Array<{ href: string; as: string; type?: string }>
}): void {
  if (typeof document === "undefined") return

  // Add preconnect hints
  if (resources.preconnect) {
    resources.preconnect.forEach((url) => {
      const link = document.createElement("link")
      link.rel = "preconnect"
      link.href = url
      document.head.appendChild(link)
    })
  }

  // Add prefetch hints
  if (resources.prefetch) {
    resources.prefetch.forEach((url) => {
      const link = document.createElement("link")
      link.rel = "prefetch"
      link.href = url
      document.head.appendChild(link)
    })
  }

  // Add preload hints
  if (resources.preload) {
    resources.preload.forEach((resource) => {
      const link = document.createElement("link")
      link.rel = "preload"
      link.href = resource.href
      link.as = resource.as
      if (resource.type) link.type = resource.type
      document.head.appendChild(link)
    })
  }
}

// Measure component render time
export function useRenderTime(componentName: string): void {
  const startTime = React.useRef(performance.now())

  React.useEffect(() => {
    const endTime = performance.now()
    const renderTime = endTime - startTime.current
    console.log(`[Performance] ${componentName} rendered in ${renderTime.toFixed(2)}ms`)

    return () => {
      const unmountTime = performance.now()
      const lifetime = unmountTime - startTime.current
      console.log(`[Performance] ${componentName} unmounted after ${lifetime.toFixed(2)}ms`)
    }
  }, [componentName])
}

// Web Vitals reporting
export function reportWebVitals(metric: {
  id: string
  name: string
  value: number
}): void {
  // In a real application, this would send the metrics to an analytics service
  console.log("[Web Vitals]", metric)

  // Example of sending to Google Analytics
  if (typeof window !== "undefined" && "gtag" in window) {
    // @ts-ignore
    window.gtag("event", metric.name, {
      value: Math.round(metric.name === "CLS" ? metric.value * 1000 : metric.value),
      event_category: "Web Vitals",
      event_label: metric.id,
      non_interaction: true,
    })
  }
}
