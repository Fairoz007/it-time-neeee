import { supabase } from "@/lib/supabase-client"
import { ensureUserProfile } from "@/lib/profile-utils"

/**
 * Utility functions for authentication
 */

/**
 * Sign in with email and password
 */
export async function signInWithEmail(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) {
    throw error
  }

  // Ensure the user has a profile
  if (data.user) {
    await ensureUserProfile(data.user.id)
  }

  return data
}

/**
 * Sign up with email and password
 */
export async function signUpWithEmail(email: string, password: string, metadata: Record<string, any> = {}) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: metadata,
    },
  })

  if (error) {
    throw error
  }

  return data
}

/**
 * Sign out the current user
 */
export async function signOut() {
  const { error } = await supabase.auth.signOut()

  if (error) {
    throw error
  }
}

/**
 * Send a password reset email
 */
export async function resetPassword(email: string, redirectUrl: string) {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: redirectUrl,
  })

  if (error) {
    throw error
  }
}

/**
 * Update user password
 */
export async function updatePassword(password: string) {
  const { error } = await supabase.auth.updateUser({
    password,
  })

  if (error) {
    throw error
  }
}

/**
 * Get the current session
 */
export async function getSession() {
  const { data, error } = await supabase.auth.getSession()

  if (error) {
    throw error
  }

  return data.session
}

/**
 * Get the current user
 */
export async function getCurrentUser() {
  const { data, error } = await supabase.auth.getUser()

  if (error) {
    throw error
  }

  return data.user
}

/**
 * Check if a user is authenticated
 */
export async function isAuthenticated() {
  try {
    const session = await getSession()
    return !!session
  } catch (error) {
    return false
  }
}
