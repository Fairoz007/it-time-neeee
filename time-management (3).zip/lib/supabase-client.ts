// Update the imports at the top of the file
import { createClient } from "@supabase/supabase-js"
import { env } from "@/app/env"

// Initialize the Supabase client
const supabaseUrl = env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = env.NEXT_PUBLIC_SUPABASE_ANON_KEY

// Check if the required environment variables are set
if (!supabaseUrl || !supabaseAnonKey) {
  console.warn("Supabase URL or Anonymous Key is missing. Using mock data.", {
    url: supabaseUrl ? "Set" : "Missing",
    key: supabaseAnonKey ? "Set" : "Missing",
  })
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Improve error handling for Supabase client initialization
export function isSupabaseConfigured(): boolean {
  if (!supabaseUrl || !supabaseAnonKey) {
    console.warn("Supabase URL or Anonymous Key is missing. Using mock data.", {
      url: supabaseUrl ? "Set" : "Missing",
      key: supabaseAnonKey ? "Set" : "Missing",
    })
    return false
  }
  return true
}

// Add a function to check connection health
export async function checkSupabaseConnection(): Promise<boolean> {
  try {
    const { data, error } = await supabase.from("projects").select("count").limit(1)
    return !error
  } catch (err) {
    console.error("Supabase connection test failed:", err)
    return false
  }
}

// Type definitions for our database tables
export type Project = {
  id: string
  name: string
  description: string
  status: "active" | "completed" | "on_hold"
  start_date: string
  end_date: string | null
  progress: number
  team_members: string[] // Now storing user_ids instead of names
  resource_allocation: number
  estimated_hours: number
  actual_hours: number
  created_at: string
  updated_at: string
  risk_level?: "low" | "medium" | "high"
}

export type Task = {
  id: string
  title: string
  description: string
  priority: "low" | "medium" | "high" | "critical"
  status: "todo" | "in_progress" | "completed"
  due_date: string
  project_id: string
  tags: string[]
  assignee_id: string
  dependencies: string[]
  blocking: string[]
  estimated_hours: number
  actual_hours: number
  created_at: string
  updated_at: string
}

export type TimeEntry = {
  id: string
  task_id: string
  project_id: string
  user_id: string
  start_time: string
  end_time: string | null
  duration: number
  billable: boolean
  notes: string
  created_at: string
}

export type Integration = {
  id: string
  name: string
  type: string
  status: "connected" | "disconnected"
  settings: Record<string, any>
  created_at: string
  updated_at: string
}

// Data fetching functions
export async function fetchProjects(): Promise<Project[]> {
  // Check if Supabase is configured
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Using mock data for projects.")
    return getMockProjects()
  }

  try {
    const { data, error } = await supabase.from("projects").select("*").order("updated_at", { ascending: false })

    if (error) {
      console.error("Error fetching projects:", error)
      return getMockProjects()
    }

    return data || []
  } catch (err) {
    console.error("Exception fetching projects:", err)
    return getMockProjects()
  }
}

// Add a function to generate mock projects when Supabase is unavailable
function getMockProjects(): Project[] {
  const today = new Date()
  const endDate = new Date(today)
  endDate.setDate(endDate.getDate() + 30)

  return [
    {
      id: "mock-project-1",
      name: "API Integration",
      description: "Integrate with third-party APIs and implement authentication",
      status: "active",
      start_date: new Date(today.getTime() - 15 * 86400000).toISOString().split("T")[0],
      end_date: endDate.toISOString().split("T")[0],
      progress: 35,
      team_members: ["John Doe", "Sarah Smith"],
      resource_allocation: 75,
      estimated_hours: 120,
      actual_hours: 42,
      created_at: new Date(today.getTime() - 20 * 86400000).toISOString(),
      updated_at: today.toISOString(),
      risk_level: "medium",
    },
    {
      id: "mock-project-2",
      name: "Frontend Development",
      description: "Develop the user interface and implement responsive design",
      status: "active",
      start_date: new Date(today.getTime() - 10 * 86400000).toISOString().split("T")[0],
      end_date: new Date(endDate.getTime() + 15 * 86400000).toISOString().split("T")[0],
      progress: 20,
      team_members: ["Alex Johnson", "Emily Chen"],
      resource_allocation: 60,
      estimated_hours: 160,
      actual_hours: 32,
      created_at: new Date(today.getTime() - 12 * 86400000).toISOString(),
      updated_at: today.toISOString(),
      risk_level: "low",
    },
  ]
}

export async function fetchProjectsByStatus(status: Project["status"] | "all"): Promise<Project[]> {
  if (!isSupabaseConfigured()) {
    const allProjects = getMockProjects()
    return status === "all" ? allProjects : allProjects.filter((p) => p.status === status)
  }

  try {
    let query = supabase.from("projects").select("*").order("updated_at", { ascending: false })

    if (status !== "all") {
      query = query.eq("status", status)
    }

    const { data, error } = await query

    if (error) {
      console.error(`Error fetching ${status} projects:`, error)
      const allProjects = getMockProjects()
      return status === "all" ? allProjects : allProjects.filter((p) => p.status === status)
    }

    return data || []
  } catch (err) {
    console.error(`Exception fetching ${status} projects:`, err)
    const allProjects = getMockProjects()
    return status === "all" ? allProjects : allProjects.filter((p) => p.status === status)
  }
}

export async function createProject(
  project: Omit<Project, "id" | "created_at" | "updated_at">,
): Promise<Project | null> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot create project.")
    return null
  }

  try {
    const { data, error } = await supabase.from("projects").insert([project]).select().single()

    if (error) {
      console.error("Error creating project:", error)
      return null
    }

    return data
  } catch (err) {
    console.error("Exception creating project:", err)
    return null
  }
}

export async function updateProject(id: string, updates: Partial<Project>): Promise<Project | null> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot update project.")
    return null
  }

  try {
    const { data, error } = await supabase.from("projects").update(updates).eq("id", id).select().single()

    if (error) {
      console.error("Error updating project:", error)
      return null
    }

    return data
  } catch (err) {
    console.error("Exception updating project:", err)
    return null
  }
}

export async function fetchTasks(filters?: {
  status?: Task["status"]
  priority?: Task["priority"]
  project_id?: string
  assignee_id?: string
  due_date_start?: string
  due_date_end?: string
}): Promise<Task[]> {
  // Check if Supabase is configured
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Using mock data for tasks.")
    return getMockTasks()
  }

  try {
    let query = supabase.from("tasks").select("*").order("due_date", { ascending: true })

    if (filters) {
      if (filters.status) query = query.eq("status", filters.status)
      if (filters.priority) query = query.eq("priority", filters.priority)
      if (filters.project_id) query = query.eq("project_id", filters.project_id)
      if (filters.assignee_id) query = query.eq("assignee_id", filters.assignee_id)
      if (filters.due_date_start) query = query.gte("due_date", filters.due_date_start)
      if (filters.due_date_end) query = query.lte("due_date", filters.due_date_end)
    }

    const { data, error } = await query

    if (error) {
      console.error("Error fetching tasks:", error)
      return getMockTasks()
    }

    return data || []
  } catch (err) {
    console.error("Exception fetching tasks:", err)
    return getMockTasks()
  }
}

// Add a function to generate mock tasks when Supabase is unavailable
function getMockTasks(): Task[] {
  const today = new Date()
  const tomorrow = new Date(today)
  tomorrow.setDate(tomorrow.getDate() + 1)

  return [
    {
      id: "mock-task-1",
      title: "Fix authentication bug",
      description: "Users are experiencing login issues after the latest deployment",
      priority: "critical",
      status: "in_progress",
      due_date: today.toISOString().split("T")[0],
      project_id: "mock-project-1",
      tags: ["bug", "security"],
      assignee_id: "default-user",
      dependencies: [],
      blocking: ["mock-task-2"],
      estimated_hours: 4,
      actual_hours: 2.5,
      created_at: new Date(today.getTime() - 86400000).toISOString(),
      updated_at: today.toISOString(),
    },
    {
      id: "mock-task-2",
      title: "Update API documentation",
      description: "Add new endpoints and authentication flow",
      priority: "medium",
      status: "todo",
      due_date: tomorrow.toISOString().split("T")[0],
      project_id: "mock-project-1",
      tags: ["documentation", "api"],
      assignee_id: "default-user",
      dependencies: ["mock-task-1"],
      blocking: [],
      estimated_hours: 3,
      actual_hours: 0,
      created_at: new Date(today.getTime() - 86400000).toISOString(),
      updated_at: today.toISOString(),
    },
    {
      id: "mock-task-3",
      title: "Design new dashboard layout",
      description: "Create wireframes and mockups for the new dashboard",
      priority: "high",
      status: "todo",
      due_date: new Date(today.getTime() + 2 * 86400000).toISOString().split("T")[0],
      project_id: "mock-project-2",
      tags: ["design", "ui"],
      assignee_id: "default-user",
      dependencies: [],
      blocking: [],
      estimated_hours: 6,
      actual_hours: 0,
      created_at: new Date(today.getTime() - 2 * 86400000).toISOString(),
      updated_at: today.toISOString(),
    },
  ]
}

export async function fetchTasksForToday(): Promise<Task[]> {
  if (!isSupabaseConfigured()) {
    const allTasks = getMockTasks()
    const today = new Date().toISOString().split("T")[0]
    return allTasks.filter((task) => task.due_date === today)
  }

  try {
    const today = new Date().toISOString().split("T")[0]

    const { data, error } = await supabase
      .from("tasks")
      .select("*")
      .eq("due_date", today)
      .order("priority", { ascending: false })

    if (error) {
      console.error("Error fetching today's tasks:", error)
      const allTasks = getMockTasks()
      return allTasks.filter((task) => task.due_date === today)
    }

    return data || []
  } catch (err) {
    console.error("Exception fetching today's tasks:", err)
    const allTasks = getMockTasks()
    const today = new Date().toISOString().split("T")[0]
    return allTasks.filter((task) => task.due_date === today)
  }
}

export async function fetchUpcomingTasks(): Promise<Task[]> {
  if (!isSupabaseConfigured()) {
    const allTasks = getMockTasks()
    const today = new Date().toISOString().split("T")[0]
    const nextWeek = new Date()
    nextWeek.setDate(nextWeek.getDate() + 7)
    const nextWeekStr = nextWeek.toISOString().split("T")[0]

    return allTasks.filter((task) => task.due_date > today && task.due_date <= nextWeekStr)
  }

  try {
    const today = new Date().toISOString().split("T")[0]
    const nextWeek = new Date()
    nextWeek.setDate(nextWeek.getDate() + 7)
    const nextWeekStr = nextWeek.toISOString().split("T")[0]

    const { data, error } = await supabase
      .from("tasks")
      .select("*")
      .gt("due_date", today)
      .lte("due_date", nextWeekStr)
      .order("due_date", { ascending: true })

    if (error) {
      console.error("Error fetching upcoming tasks:", error)
      const allTasks = getMockTasks()
      return allTasks.filter((task) => task.due_date > today && task.due_date <= nextWeekStr)
    }

    return data || []
  } catch (err) {
    console.error("Exception fetching upcoming tasks:", err)
    const allTasks = getMockTasks()
    const today = new Date().toISOString().split("T")[0]
    const nextWeek = new Date()
    nextWeek.setDate(nextWeek.getDate() + 7)
    const nextWeekStr = nextWeek.toISOString().split("T")[0]

    return allTasks.filter((task) => task.due_date > today && task.due_date <= nextWeekStr)
  }
}

export async function createTask(task: Omit<Task, "id" | "created_at" | "updated_at">): Promise<Task | null> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot create task.")
    return null
  }

  try {
    const { data, error } = await supabase.from("tasks").insert([task]).select().single()

    if (error) {
      console.error("Error creating task:", error)
      return null
    }

    return data
  } catch (err) {
    console.error("Exception creating task:", err)
    return null
  }
}

export async function updateTask(id: string, updates: Partial<Task>): Promise<Task | null> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot update task.")
    return null
  }

  try {
    const { data, error } = await supabase.from("tasks").update(updates).eq("id", id).select().single()

    if (error) {
      console.error("Error updating task:", error)
      return null
    }

    return data
  } catch (err) {
    console.error("Exception updating task:", err)
    return null
  }
}

export async function fetchTimeEntries(filters?: {
  user_id?: string
  project_id?: string
  task_id?: string
  start_date?: string
  end_date?: string
}): Promise<TimeEntry[]> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Using mock data for time entries.")
    return getMockTimeEntries()
  }

  try {
    let query = supabase.from("time_entries").select("*").order("start_time", { ascending: false })

    if (filters) {
      if (filters.user_id) query = query.eq("user_id", filters.user_id)
      if (filters.project_id) query = query.eq("project_id", filters.project_id)
      if (filters.task_id) query = query.eq("task_id", filters.task_id)
      if (filters.start_date) query = query.gte("start_time", filters.start_date)
      if (filters.end_date) query = query.lte("start_time", filters.end_date)
    }

    const { data, error } = await query

    if (error) {
      console.error("Error fetching time entries:", error)
      return getMockTimeEntries()
    }

    return data || []
  } catch (err) {
    console.error("Exception fetching time entries:", err)
    return getMockTimeEntries()
  }
}

// Add a function to generate mock time entries
function getMockTimeEntries(): TimeEntry[] {
  const now = new Date()
  const yesterday = new Date(now)
  yesterday.setDate(yesterday.getDate() - 1)

  return [
    {
      id: "mock-time-entry-1",
      task_id: "mock-task-1",
      project_id: "mock-project-1",
      user_id: "default-user",
      start_time: yesterday.toISOString(),
      end_time: new Date(yesterday.getTime() + 2 * 3600000).toISOString(),
      duration: 7200, // 2 hours in seconds
      billable: true,
      notes: "Working on authentication bug fix",
      created_at: yesterday.toISOString(),
    },
    {
      id: "mock-time-entry-2",
      task_id: "mock-task-1",
      project_id: "mock-project-1",
      user_id: "default-user",
      start_time: new Date(now.getTime() - 4 * 3600000).toISOString(),
      end_time: new Date(now.getTime() - 2 * 3600000).toISOString(),
      duration: 7200, // 2 hours in seconds
      billable: true,
      notes: "Continued work on authentication bug",
      created_at: new Date(now.getTime() - 4 * 3600000).toISOString(),
    },
  ]
}

export async function startTimeEntry(entry: {
  task_id: string
  project_id: string
  user_id: string
  notes?: string
  billable?: boolean
}): Promise<TimeEntry | null> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot start time entry.")
    return null
  }

  try {
    const now = new Date().toISOString()

    const { data, error } = await supabase
      .from("time_entries")
      .insert([
        {
          ...entry,
          start_time: now,
          end_time: null,
          duration: 0,
          notes: entry.notes || "",
          billable: entry.billable || true,
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Error starting time entry:", error)
      return null
    }

    return data
  } catch (err) {
    console.error("Exception starting time entry:", err)
    return null
  }
}

export async function stopTimeEntry(id: string): Promise<TimeEntry | null> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot stop time entry.")
    return null
  }

  try {
    const now = new Date().toISOString()

    // First, get the current entry to calculate duration
    const { data: currentEntry, error: fetchError } = await supabase
      .from("time_entries")
      .select("*")
      .eq("id", id)
      .single()

    if (fetchError || !currentEntry) {
      console.error("Error fetching time entry:", fetchError)
      return null
    }

    // Calculate duration in seconds
    const startTime = new Date(currentEntry.start_time).getTime()
    const endTime = new Date(now).getTime()
    const durationInSeconds = Math.floor((endTime - startTime) / 1000)

    // Update the entry
    const { data, error } = await supabase
      .from("time_entries")
      .update({
        end_time: now,
        duration: durationInSeconds,
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("Error stopping time entry:", error)
      return null
    }

    return data
  } catch (err) {
    console.error("Exception stopping time entry:", err)
    return null
  }
}

export async function fetchIntegrations(): Promise<Integration[]> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Using mock data for integrations.")
    return getMockIntegrations()
  }

  try {
    const { data, error } = await supabase.from("integrations").select("*").order("name", { ascending: true })

    if (error) {
      console.error("Error fetching integrations:", error)
      return getMockIntegrations()
    }

    return data || []
  } catch (err) {
    console.error("Exception fetching integrations:", err)
    return getMockIntegrations()
  }
}

// Add a function to generate mock integrations
function getMockIntegrations(): Integration[] {
  const now = new Date().toISOString()

  return [
    {
      id: "mock-integration-1",
      name: "GitHub",
      type: "github",
      status: "connected",
      settings: {
        repoUrl: "https://github.com/username/repo",
        autoTrackPRs: true,
        syncIssues: true,
        trackCommits: false,
      },
      created_at: now,
      updated_at: now,
    },
    {
      id: "mock-integration-2",
      name: "Slack",
      type: "slack",
      status: "connected",
      settings: {
        workspace: "My Workspace",
        dailySummaries: true,
        timerCommands: true,
        taskNotifications: false,
      },
      created_at: now,
      updated_at: now,
    },
    {
      id: "mock-integration-3",
      name: "Google Calendar",
      type: "google calendar",
      status: "disconnected",
      settings: {},
      created_at: now,
      updated_at: now,
    },
  ]
}

export async function connectIntegration(
  integration: Omit<Integration, "id" | "created_at" | "updated_at">,
): Promise<Integration | null> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot connect integration.")
    return null
  }

  try {
    const { data, error } = await supabase.from("integrations").insert([integration]).select().single()

    if (error) {
      console.error("Error connecting integration:", error)
      return null
    }

    return data
  } catch (err) {
    console.error("Exception connecting integration:", err)
    return null
  }
}

export async function updateIntegration(id: string, updates: Partial<Integration>): Promise<Integration | null> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot update integration.")
    return null
  }

  try {
    const { data, error } = await supabase.from("integrations").update(updates).eq("id", id).select().single()

    if (error) {
      console.error("Error updating integration:", error)
      return null
    }

    return data
  } catch (err) {
    console.error("Exception updating integration:", err)
    return null
  }
}

// Dashboard metrics
export async function fetchDashboardMetrics(userId: string): Promise<{
  activeProjects: number
  pendingTasks: number
  hoursTrackedThisWeek: number
  productivityScore: number
}> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Using mock data for dashboard metrics.")
    return {
      activeProjects: 2,
      pendingTasks: 5,
      hoursTrackedThisWeek: 24.5,
      productivityScore: 78,
    }
  }

  try {
    // Get active projects count
    const { data: projects, error: projectsError } = await supabase.from("projects").select("id").eq("status", "active")

    if (projectsError) throw projectsError

    // Get pending tasks count
    const { data: tasks, error: tasksError } = await supabase.from("tasks").select("id").neq("status", "completed")

    if (tasksError) throw tasksError

    // Get hours tracked this week
    const startOfWeek = new Date()
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay())
    startOfWeek.setHours(0, 0, 0, 0)

    const { data: timeEntries, error: timeError } = await supabase
      .from("time_entries")
      .select("duration")
      .gte("start_time", startOfWeek.toISOString())

    if (timeError) throw timeError

    const hoursTracked = timeEntries.reduce((total, entry) => total + entry.duration / 3600, 0)

    // Calculate productivity score
    const { data: completedTasks, error: completedError } = await supabase
      .from("tasks")
      .select("id")
      .eq("status", "completed")
      .gte("updated_at", startOfWeek.toISOString())

    if (completedError) throw completedError

    // Simple productivity score calculation
    const productivityScore = Math.min(100, Math.round(completedTasks.length * 15 + hoursTracked * 5))

    return {
      activeProjects: projects.length,
      pendingTasks: tasks.length,
      hoursTrackedThisWeek: Number.parseFloat(hoursTracked.toFixed(1)),
      productivityScore,
    }
  } catch (error) {
    console.error("Error fetching dashboard metrics:", error)
    return {
      activeProjects: 2,
      pendingTasks: 5,
      hoursTrackedThisWeek: 24.5,
      productivityScore: 78,
    }
  }
}

export async function fetchTeamMembersByProjectId(projectId: string): Promise<any[]> {
  if (!isSupabaseConfigured()) {
    console.warn("Supabase is not properly configured. Cannot fetch team members.")
    return []
  }

  try {
    // First get the project to get the team member names
    const { data: project, error: projectError } = await supabase
      .from("projects")
      .select("team_members")
      .eq("id", projectId)
      .single()

    if (projectError || !project) {
      console.error("Error fetching project team members:", projectError)
      return []
    }

    // If no team members, return empty array
    if (!project.team_members || project.team_members.length === 0) {
      return []
    }

    // Fetch profiles that match the team member names
    // Note: In a real app, you might store user IDs instead of names
    const { data: profiles, error: profilesError } = await supabase
      .from("profiles")
      .select("*")
      .in("name", project.team_members)

    if (profilesError) {
      console.error("Error fetching team member profiles:", profilesError)
      return []
    }

    return profiles || []
  } catch (err) {
    console.error("Exception fetching team members:", err)
    return []
  }
}

// Add this function to the supabase-client.ts file

export async function fetchUserProfiles(userIds: string[]): Promise<any[]> {
  if (!isSupabaseConfigured() || userIds.length === 0) {
    return []
  }

  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("id, user_id, full_name, email, avatar_url, job_title, department, created_at")
      .in("user_id", userIds)

    if (error) {
      console.error("Error fetching user profiles:", error)
      return []
    }

    return data || []
  } catch (err) {
    console.error("Exception fetching user profiles:", err)
    return []
  }
}
