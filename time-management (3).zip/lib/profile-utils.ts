import { supabase } from "@/lib/supabase-client"

/**
 * Checks if a profile exists for a user and creates one if it doesn't
 * @param userId The user ID to check/create a profile for
 * @param userData Optional user data to use when creating the profile
 */
export async function ensureUserProfile(
  userId: string,
  userData?: {
    full_name?: string
    email?: string
    role?: string
    department?: string
    avatar_url?: string
  },
) {
  try {
    // Check if profile exists
    const { data: existingProfile, error: fetchError } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", userId)
      .single()

    if (fetchError && fetchError.code !== "PGRST116") {
      // PGRST116 is the error code for "no rows returned" - that's expected if profile doesn't exist
      console.error("Error checking for existing profile:", fetchError)
      throw fetchError
    }

    // If profile exists, return it
    if (existingProfile) {
      return { success: true, profile: existingProfile }
    }

    // Get user data if not provided
    let profileData = userData
    if (!profileData) {
      const { data: user, error: userError } = await supabase.auth.getUser()

      if (userError || !user) {
        console.error("Error fetching user data:", userError)
        throw userError || new Error("User not found")
      }

      profileData = {
        full_name: user.user?.user_metadata?.full_name || "",
        email: user.user?.email || "",
        role: user.user?.user_metadata?.role || "user",
      }
    }

    // Create profile
    const { data: newProfile, error: insertError } = await supabase
      .from("profiles")
      .insert([
        {
          user_id: userId,
          full_name: profileData.full_name || "",
          email: profileData.email || "",
          role: profileData.role || "user",
          department: profileData.department || "",
          avatar_url: profileData.avatar_url || "",
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (insertError) {
      console.error("Error creating user profile:", insertError)
      throw insertError
    }

    return { success: true, profile: newProfile }
  } catch (error: any) {
    console.error("Exception ensuring user profile:", error)
    return { success: false, error: error.message || "Failed to ensure user profile" }
  }
}

/**
 * Updates a user's profile
 * @param userId The user ID whose profile to update
 * @param updates The profile fields to update
 */
export async function updateUserProfile(
  userId: string,
  updates: {
    full_name?: string
    email?: string
    role?: string
    department?: string
    avatar_url?: string
    job_title?: string
  },
) {
  try {
    // First ensure the profile exists
    const { success, error } = await ensureUserProfile(userId)

    if (!success) {
      throw new Error(error || "Failed to ensure user profile exists")
    }

    // Update the profile
    const { data, error: updateError } = await supabase
      .from("profiles")
      .update(updates)
      .eq("user_id", userId)
      .select()
      .single()

    if (updateError) {
      console.error("Error updating user profile:", updateError)
      throw updateError
    }

    return { success: true, profile: data }
  } catch (error: any) {
    console.error("Exception updating user profile:", error)
    return { success: false, error: error.message || "Failed to update user profile" }
  }
}
