"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { LoadingSpinner } from "@/components/loading-spinner"

interface ProtectedRouteProps {
  children: React.ReactNode
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { user, isLoading, isInitialized, setRedirectUrl } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Only check after auth is initialized and not loading
    if (!isLoading && isInitialized && !user) {
      // Save the current URL for redirect after login
      setRedirectUrl(pathname)
      // Redirect to login
      router.push("/login")
    }
  }, [user, isLoading, isInitialized, router, pathname, setRedirectUrl])

  // Show loading state while checking auth
  if (isLoading || !isInitialized) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <LoadingSpinner className="mx-auto mb-4" />
          <h3 className="text-lg font-medium">Loading...</h3>
          <p className="text-sm text-muted-foreground">Please wait while we authenticate you</p>
        </div>
      </div>
    )
  }

  // If user is authenticated, render children
  if (user) {
    return <>{children}</>
  }

  // This should not be visible as we redirect in the useEffect
  return null
}
