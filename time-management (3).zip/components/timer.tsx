"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Pause, Play, X, Clock, CheckCircle } from "lucide-react"
import { useTimeTracking } from "@/hooks/use-time-tracking"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useData } from "@/contexts/data-context"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Card, CardContent } from "@/components/ui/card"

export function TimerButton() {
  const { isTracking, formatElapsedTime, startTracking, stopTracking, activeEntry } = useTimeTracking()
  const { projects, tasks } = useData()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedTask, setSelectedTask] = useState("")
  const [selectedProject, setSelectedProject] = useState("")
  const [notes, setNotes] = useState("")
  const [isStopDialogOpen, setIsStopDialogOpen] = useState(false)
  const [stopNotes, setStopNotes] = useState("")

  // When opening the dialog, pre-select the active task/project if there is one
  useEffect(() => {
    if (isDialogOpen && activeEntry) {
      if (activeEntry.taskId) {
        setSelectedTask(activeEntry.taskId)
      }
      if (activeEntry.projectId) {
        setSelectedProject(activeEntry.projectId)
      }
    }
  }, [isDialogOpen, activeEntry])

  const handleTimerAction = async () => {
    if (isTracking) {
      setIsStopDialogOpen(true)
    } else {
      setIsDialogOpen(true)
    }
  }

  const handleStartTracking = async () => {
    if (!selectedTask && !selectedProject) {
      // At least one of task or project must be selected
      return
    }

    const taskTitle = selectedTask ? tasks.find((t) => t.id === selectedTask)?.title : undefined
    const projectName = selectedProject ? projects.find((p) => p.id === selectedProject)?.name : undefined

    await startTracking({
      taskId: selectedTask || undefined,
      projectId: selectedProject || undefined,
      notes,
      taskTitle,
      projectName,
    })

    setIsDialogOpen(false)
    setNotes("")
  }

  const handleStopTracking = async () => {
    await stopTracking(stopNotes)
    setIsStopDialogOpen(false)
    setStopNotes("")
  }

  return (
    <>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant={isTracking ? "destructive" : "default"} onClick={handleTimerAction} className="focus-ring">
              {isTracking ? (
                <>
                  <Pause className="mr-2 h-4 w-4" />
                  {formatElapsedTime()}
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  Start Timer
                </>
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            {isTracking ? "Stop the current timer" : "Start tracking time for a task or project"}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      {/* Start Timer Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Start Time Tracking</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="project" className="text-sm font-medium">
                Project
              </label>
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger id="project">
                  <SelectValue placeholder="Select a project" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="no_project">No project</SelectItem>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <label htmlFor="task" className="text-sm font-medium">
                Task
              </label>
              <Select value={selectedTask} onValueChange={setSelectedTask}>
                <SelectTrigger id="task">
                  <SelectValue placeholder="Select a task" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="no_task">No task</SelectItem>
                  {tasks
                    .filter((task) => !selectedProject || task.project_id === selectedProject)
                    .map((task) => (
                      <SelectItem key={task.id} value={task.id}>
                        {task.title}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <label htmlFor="notes" className="text-sm font-medium">
                Notes (optional)
              </label>
              <Textarea
                id="notes"
                placeholder="What are you working on?"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleStartTracking} disabled={!selectedTask && !selectedProject}>
              Start Tracking
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stop Timer Dialog */}
      <Dialog open={isStopDialogOpen} onOpenChange={setIsStopDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Stop Time Tracking</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {activeEntry && (
              <div className="rounded-md bg-muted p-3">
                <div className="font-medium">{activeEntry.taskTitle || activeEntry.projectName || "Time Entry"}</div>
                <div className="text-sm text-muted-foreground mt-1">Duration: {formatElapsedTime()}</div>
              </div>
            )}

            <div className="grid gap-2">
              <label htmlFor="stopNotes" className="text-sm font-medium">
                Notes (optional)
              </label>
              <Textarea
                id="stopNotes"
                placeholder="What did you accomplish?"
                value={stopNotes}
                onChange={(e) => setStopNotes(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsStopDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleStopTracking}>Stop Tracking</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

export function TimerDisplay() {
  const { isTracking, elapsedTime, formatElapsedTime, stopTracking, resetTimer, discardTimeEntry, activeEntry } =
    useTimeTracking()
  const [isExpanded, setIsExpanded] = useState(false)
  const [showControls, setShowControls] = useState(false)
  const { projects, tasks } = useData()

  // Don't show if not tracking
  if (!isTracking) return null

  // Find task and project details
  const task = activeEntry?.taskId ? tasks.find((t) => t.id === activeEntry.taskId) : null
  const project = activeEntry?.projectId ? projects.find((p) => p.id === activeEntry.projectId) : null

  return (
    <Card
      className="fixed bottom-4 right-4 z-50 shadow-lg transition-all duration-200 hover:shadow-xl"
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
      style={{
        width: isExpanded ? "320px" : "180px",
      }}
    >
      <CardContent className="p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Clock className="h-5 w-5 text-primary mr-2" />
            <div className="font-mono text-lg font-bold">{formatElapsedTime()}</div>
          </div>
          <div className="flex items-center space-x-1">
            {showControls && (
              <>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setIsExpanded(!isExpanded)}>
                  {isExpanded ? <X className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-destructive"
                  onClick={() => discardTimeEntry()}
                >
                  <X className="h-4 w-4" />
                </Button>
              </>
            )}
            <Button variant="destructive" size="sm" className="h-7" onClick={() => stopTracking()}>
              <Pause className="mr-1 h-3 w-3" />
              Stop
            </Button>
          </div>
        </div>

        {isExpanded && (
          <div className="mt-2 text-sm">
            {(task || project) && (
              <div className="mb-2">
                {task && (
                  <div className="flex items-center mb-1">
                    <span className="text-muted-foreground mr-2">Task:</span>
                    <Badge variant="outline">{task.title}</Badge>
                  </div>
                )}
                {project && (
                  <div className="flex items-center">
                    <span className="text-muted-foreground mr-2">Project:</span>
                    <Badge variant="outline">{project.name}</Badge>
                  </div>
                )}
              </div>
            )}
            <Progress value={(elapsedTime % 3600) / 36} className="h-1 mb-1" />
            <div className="text-xs text-muted-foreground text-right">
              {Math.floor(elapsedTime / 3600)} hrs {Math.floor((elapsedTime % 3600) / 60)} mins
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
