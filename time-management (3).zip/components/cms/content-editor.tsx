"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Bold,
  Italic,
  LinkIcon,
  List,
  ListOrdered,
  ImageIcon,
  Code,
  Heading1,
  Heading2,
  Heading3,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Save,
  Eye,
  FileText,
  Upload,
  X,
  Check,
} from "lucide-react"
import { DynamicContent } from "@/components/dynamic-content"

interface ContentEditorProps {
  initialContent?: string
  onSave?: (content: string, metadata: ContentMetadata) => void
  readOnly?: boolean
  contentType?: "page" | "post" | "documentation"
}

interface ContentMetadata {
  title: string
  description: string
  slug: string
  author: string
  tags: string[]
  publishDate: string
  status: "draft" | "published" | "archived"
  featuredImage?: string
}

export function ContentEditor({
  initialContent = "",
  onSave,
  readOnly = false,
  contentType = "page",
}: ContentEditorProps) {
  const [content, setContent] = useState(initialContent)
  const [previewMode, setPreviewMode] = useState(false)
  const [metadata, setMetadata] = useState<ContentMetadata>({
    title: "",
    description: "",
    slug: "",
    author: "",
    tags: [],
    publishDate: new Date().toISOString().split("T")[0],
    status: "draft",
  })
  const [tagInput, setTagInput] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)

  // Load initial content
  useEffect(() => {
    setContent(initialContent)
  }, [initialContent])

  // Handle metadata changes
  const handleMetadataChange = (key: keyof ContentMetadata, value: string) => {
    setMetadata((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  // Handle tag input
  const handleAddTag = () => {
    if (tagInput.trim() && !metadata.tags.includes(tagInput.trim())) {
      setMetadata((prev) => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()],
      }))
      setTagInput("")
    }
  }

  // Handle tag removal
  const handleRemoveTag = (tag: string) => {
    setMetadata((prev) => ({
      ...prev,
      tags: prev.tags.filter((t) => t !== tag),
    }))
  }

  // Handle save
  const handleSave = async () => {
    if (onSave) {
      setIsSaving(true)

      try {
        // Generate slug if empty
        if (!metadata.slug) {
          const slug = metadata.title
            .toLowerCase()
            .replace(/[^\w\s]/gi, "")
            .replace(/\s+/g, "-")

          setMetadata((prev) => ({
            ...prev,
            slug,
          }))
        }

        // Call save handler
        await onSave(content, {
          ...metadata,
          slug:
            metadata.slug ||
            metadata.title
              .toLowerCase()
              .replace(/[^\w\s]/gi, "")
              .replace(/\s+/g, "-"),
        })

        // Show success message
        setSaveSuccess(true)
        setTimeout(() => setSaveSuccess(false), 3000)
      } catch (error) {
        console.error("Error saving content:", error)
      } finally {
        setIsSaving(false)
      }
    }
  }

  // Editor toolbar actions
  const insertText = (before: string, after = "") => {
    const textarea = document.querySelector("textarea") as HTMLTextAreaElement
    if (!textarea) return

    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const selectedText = content.substring(start, end)
    const newText = content.substring(0, start) + before + selectedText + after + content.substring(end)

    setContent(newText)

    // Set cursor position after insertion
    setTimeout(() => {
      textarea.focus()
      textarea.setSelectionRange(start + before.length, start + before.length + selectedText.length)
    }, 0)
  }

  // Toolbar actions
  const toolbarActions = [
    { icon: <Bold size={18} />, action: () => insertText("**", "**"), tooltip: "Bold" },
    { icon: <Italic size={18} />, action: () => insertText("*", "*"), tooltip: "Italic" },
    { icon: <Heading1 size={18} />, action: () => insertText("# ", "\n"), tooltip: "Heading 1" },
    { icon: <Heading2 size={18} />, action: () => insertText("## ", "\n"), tooltip: "Heading 2" },
    { icon: <Heading3 size={18} />, action: () => insertText("### ", "\n"), tooltip: "Heading 3" },
    { icon: <List size={18} />, action: () => insertText("- "), tooltip: "Bullet List" },
    { icon: <ListOrdered size={18} />, action: () => insertText("1. "), tooltip: "Numbered List" },
    { icon: <LinkIcon size={18} />, action: () => insertText("[", "](url)"), tooltip: "Link" },
    { icon: <ImageIcon size={18} />, action: () => insertText("![alt text](", ")"), tooltip: "Image" },
    { icon: <Code size={18} />, action: () => insertText("```\n", "\n```"), tooltip: "Code Block" },
    { icon: <AlignLeft size={18} />, action: () => {}, tooltip: "Align Left" },
    { icon: <AlignCenter size={18} />, action: () => {}, tooltip: "Align Center" },
    { icon: <AlignRight size={18} />, action: () => {}, tooltip: "Align Right" },
  ]

  return (
    <div className="space-y-4">
      <Tabs defaultValue="editor" className="w-full">
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="editor" onClick={() => setPreviewMode(false)}>
              <FileText className="mr-2 h-4 w-4" />
              Editor
            </TabsTrigger>
            <TabsTrigger value="preview" onClick={() => setPreviewMode(true)}>
              <Eye className="mr-2 h-4 w-4" />
              Preview
            </TabsTrigger>
            <TabsTrigger value="metadata">
              <FileText className="mr-2 h-4 w-4" />
              Metadata
            </TabsTrigger>
          </TabsList>

          <div className="flex items-center space-x-2">
            <Select value={metadata.status} onValueChange={(value) => handleMetadataChange("status", value as any)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="published">Published</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>

            <Button
              onClick={handleSave}
              disabled={isSaving || readOnly}
              className={saveSuccess ? "bg-green-500 hover:bg-green-600" : ""}
            >
              {isSaving ? (
                "Saving..."
              ) : saveSuccess ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Saved
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save {metadata.status === "published" ? "& Publish" : "Draft"}
                </>
              )}
            </Button>
          </div>
        </div>

        <TabsContent value="editor" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Content Editor</CardTitle>
              <CardDescription>Edit your content using Markdown or the toolbar below</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-1 mb-2 border-b pb-2">
                {toolbarActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    size="sm"
                    onClick={action.action}
                    disabled={readOnly}
                    title={action.tooltip}
                    className="h-8 w-8 p-0"
                  >
                    {action.icon}
                    <span className="sr-only">{action.tooltip}</span>
                  </Button>
                ))}

                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={readOnly}
                      title="Upload Image"
                      className="h-8 w-8 p-0 ml-auto"
                    >
                      <Upload size={18} />
                      <span className="sr-only">Upload Image</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Upload Image</DialogTitle>
                      <DialogDescription>Upload an image to include in your content</DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="border-2 border-dashed rounded-md p-6 text-center">
                        <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground" />
                        <div className="mt-4">
                          <Button>Select Image</Button>
                        </div>
                        <p className="mt-2 text-xs text-muted-foreground">PNG, JPG, GIF up to 10MB</p>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit">Upload</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>

              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Start writing your content here..."
                className="min-h-[400px] font-mono"
                readOnly={readOnly}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview">
          <Card>
            <CardHeader>
              <CardTitle>{metadata.title || "Untitled Content"}</CardTitle>
              {metadata.description && <CardDescription>{metadata.description}</CardDescription>}
            </CardHeader>
            <CardContent>
              <DynamicContent>
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  {/* In a real app, you would render Markdown here */}
                  {content.split("\n").map((line, i) => (
                    <p key={i}>{line}</p>
                  ))}
                </div>
              </DynamicContent>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="metadata">
          <Card>
            <CardHeader>
              <CardTitle>Content Metadata</CardTitle>
              <CardDescription>Manage the metadata for your {contentType}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="title" className="text-sm font-medium">
                    Title
                  </label>
                  <Input
                    id="title"
                    value={metadata.title}
                    onChange={(e) => handleMetadataChange("title", e.target.value)}
                    placeholder="Enter title"
                    readOnly={readOnly}
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="slug" className="text-sm font-medium">
                    Slug
                  </label>
                  <Input
                    id="slug"
                    value={metadata.slug}
                    onChange={(e) => handleMetadataChange("slug", e.target.value)}
                    placeholder="enter-slug"
                    readOnly={readOnly}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label htmlFor="description" className="text-sm font-medium">
                    Description
                  </label>
                  <Textarea
                    id="description"
                    value={metadata.description}
                    onChange={(e) => handleMetadataChange("description", e.target.value)}
                    placeholder="Enter description"
                    readOnly={readOnly}
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="author" className="text-sm font-medium">
                    Author
                  </label>
                  <Input
                    id="author"
                    value={metadata.author}
                    onChange={(e) => handleMetadataChange("author", e.target.value)}
                    placeholder="Enter author name"
                    readOnly={readOnly}
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="publishDate" className="text-sm font-medium">
                    Publish Date
                  </label>
                  <Input
                    id="publishDate"
                    type="date"
                    value={metadata.publishDate}
                    onChange={(e) => handleMetadataChange("publishDate", e.target.value)}
                    readOnly={readOnly}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label htmlFor="tags" className="text-sm font-medium">
                    Tags
                  </label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {metadata.tags.map((tag) => (
                      <div
                        key={tag}
                        className="flex items-center bg-secondary text-secondary-foreground px-2 py-1 rounded-md text-sm"
                      >
                        {tag}
                        {!readOnly && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveTag(tag)}
                            className="h-4 w-4 p-0 ml-1"
                          >
                            <X className="h-3 w-3" />
                            <span className="sr-only">Remove {tag}</span>
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                  {!readOnly && (
                    <div className="flex space-x-2">
                      <Input
                        id="tags"
                        value={tagInput}
                        onChange={(e) => setTagInput(e.target.value)}
                        placeholder="Add a tag"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault()
                            handleAddTag()
                          }
                        }}
                      />
                      <Button onClick={handleAddTag} type="button">
                        Add
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setPreviewMode(true)}>
                Preview
              </Button>
              <Button onClick={handleSave} disabled={isSaving || readOnly}>
                {isSaving ? "Saving..." : "Save Changes"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
