"use client"

import { Badge } from "@/components/ui/badge"

import type React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Clock,
  Users,
  HelpCircle,
  Menu,
  X,
  LayoutDashboard,
  FolderKanban,
  CheckSquare,
  BarChart3,
  Link2,
  FileText,
  User,
  Shield,
  UserCog,
} from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import { GlobalSearch } from "@/components/search"
import { NotificationCenter } from "@/components/notifications"
import { useState, useEffect, useCallback } from "react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { useAuth } from "@/contexts/auth-context"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ErrorBoundary } from "react-error-boundary"
import { supabase } from "@/lib/supabase-client"
import { AdminOnly, ManagerPlus } from "@/components/role-based-access"

// Create a fallback component
function ErrorFallback({ error, resetErrorBoundary }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 text-center">
      <h2 className="text-2xl font-bold mb-4">Something went wrong</h2>
      <p className="mb-4 text-red-500">{error.message || "An unexpected error occurred"}</p>
      <Button onClick={resetErrorBoundary}>Try again</Button>
    </div>
  )
}

// Wrap the layout content with ErrorBoundary
export function SharedLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { user, signOut, isAdmin, isManager } = useAuth()

  // Close sidebar when route changes (for mobile)
  useEffect(() => {
    setSidebarOpen(false)
  }, [pathname])

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.getElementById("sidebar")
      const toggleButton = document.getElementById("sidebar-toggle")

      if (
        sidebarOpen &&
        sidebar &&
        !sidebar.contains(event.target as Node) &&
        toggleButton &&
        !toggleButton.contains(event.target as Node)
      ) {
        setSidebarOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [sidebarOpen])

  // Handle escape key to close sidebar
  useEffect(() => {
    const handleEscKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && sidebarOpen) {
        setSidebarOpen(false)
      }
    }

    document.addEventListener("keydown", handleEscKey)
    return () => {
      document.removeEventListener("keydown", handleEscKey)
    }
  }, [sidebarOpen])

  // User account dropdown component
  const UserAccountNav = () => {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="relative h-8 w-8 rounded-full">
            {user ? (
              <Avatar className="h-8 w-8">
                <AvatarImage src={user.avatar_url || "/placeholder.svg?height=32&width=32"} alt={user.name || "User"} />
                <AvatarFallback>{user.name ? user.name.substring(0, 2).toUpperCase() : "U"}</AvatarFallback>
              </Avatar>
            ) : (
              <User className="h-5 w-5" />
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          {user ? (
            <>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{user.name || "User"}</p>
                  {isAdmin && <p className="text-sm font-medium leading-none">Admin</p>}
                  <p className="text-xs text-muted-foreground">{user.email}</p>
                  {user.role && (
                    <Badge
                      variant={user.role === "admin" ? "default" : user.role === "manager" ? "secondary" : "outline"}
                      className="mt-1"
                    >
                      {user.role}
                    </Badge>
                  )}
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/profile">Profile</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings">Settings</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={(e) => {
                  e.preventDefault()
                  signOut()
                }}
              >
                Log out
              </DropdownMenuItem>
            </>
          ) : (
            <>
              <DropdownMenuItem asChild>
                <Link href="/login">Log in</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/login?tab=signup">Sign up</Link>
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    )
  }

  // Tasks navigation item with count
  const TasksNavItem = () => {
    const [pendingTasksCount, setPendingTasksCount] = useState<number | null>(null)
    const [isLoading, setIsLoading] = useState(false)

    const fetchTasksCount = useCallback(async () => {
      setIsLoading(true)
      try {
        // Fetch tasks that are not completed
        const { count, error } = await supabase
          .from("tasks")
          .select("*", { count: "exact", head: true })
          .neq("status", "completed")

        if (error) {
          console.error("Error fetching tasks count:", error)
          return
        }

        setPendingTasksCount(count)
      } catch (err) {
        console.error("Error in fetchTasksCount:", err)
      } finally {
        setIsLoading(false)
      }
    }, [])

    useEffect(() => {
      fetchTasksCount()

      // Set up a subscription to tasks table changes
      const subscription = supabase
        .channel("tasks-changes")
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "tasks",
          },
          () => {
            fetchTasksCount()
          },
        )
        .subscribe()

      return () => {
        subscription.unsubscribe()
      }
    }, [fetchTasksCount])

    return (
      <Link
        href="/tasks"
        className={cn(
          "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
          pathname === "/tasks" || pathname.startsWith("/tasks/") ? "bg-muted font-medium" : "text-foreground/80",
        )}
      >
        <CheckSquare className="mr-2 h-4 w-4" />
        <span>Tasks</span>
        {pendingTasksCount !== null && (
          <span className="ml-auto bg-primary/10 text-primary text-xs rounded-full px-2 py-0.5">
            {pendingTasksCount}
          </span>
        )}
      </Link>
    )
  }

  return (
    <ErrorBoundary FallbackComponent={ErrorFallback} onReset={() => window.location.reload()}>
      <div className="flex min-h-screen">
        {/* Sidebar - fixed on desktop, slide-in on mobile */}
        <aside
          id="sidebar"
          className={cn(
            "fixed inset-y-0 left-0 z-50 w-64 bg-background border-r transition-transform duration-200 ease-in-out",
            "flex flex-col h-full",
            sidebarOpen ? "translate-x-0" : "-translate-x-full",
            "lg:translate-x-0", // Always visible on desktop
          )}
          style={{ overflowY: "auto" }} // Ensure scrolling works
        >
          {/* Sidebar Header with Logo and Close Button */}
          <div className="flex items-center justify-between p-4 border-b">
            <Link href="/dashboard" className="flex items-center space-x-2">
              <Clock className="h-6 w-6 text-primary" />
              <span className="font-bold">DevTimeTracker</span>
            </Link>
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(false)}>
              <X className="h-5 w-5" />
              <span className="sr-only">Close sidebar</span>
            </Button>
          </div>

          {/* Sidebar Content */}
          <div className="flex-1 overflow-y-auto py-4 px-3">
            {/* Search */}
            <div className="mb-4 px-1">
              <GlobalSearch />
            </div>

            {/* Main Navigation */}
            <nav className="space-y-1 mb-6">
              <Link
                href="/dashboard"
                className={cn(
                  "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                  pathname === "/dashboard" ? "bg-muted font-medium" : "text-foreground/80",
                )}
              >
                <LayoutDashboard className="mr-2 h-4 w-4" />
                Dashboard
              </Link>
              <Link
                href="/projects"
                className={cn(
                  "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                  pathname === "/projects" || pathname.startsWith("/projects/")
                    ? "bg-muted font-medium"
                    : "text-foreground/80",
                )}
              >
                <FolderKanban className="mr-2 h-4 w-4" />
                Projects
              </Link>
              <TasksNavItem />
              <Link
                href="/analytics"
                className={cn(
                  "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                  pathname === "/analytics" ? "bg-muted font-medium" : "text-foreground/80",
                )}
              >
                <BarChart3 className="mr-2 h-4 w-4" />
                Analytics
              </Link>
              <Link
                href="/integrations"
                className={cn(
                  "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                  pathname === "/integrations" ? "bg-muted font-medium" : "text-foreground/80",
                )}
              >
                <Link2 className="mr-2 h-4 w-4" />
                Integrations
              </Link>
              <Link
                href="/reports"
                className={cn(
                  "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                  pathname === "/reports" ? "bg-muted font-medium" : "text-foreground/80",
                )}
              >
                <FileText className="mr-2 h-4 w-4" />
                Reports
              </Link>

              {/* Admin Section - Only visible to admins */}
              <AdminOnly>
                <div className="pt-4 pb-2">
                  <h3 className="px-3 text-xs font-semibold text-muted-foreground">Admin</h3>
                </div>
                <Link
                  href="/admin/dashboard"
                  className={cn(
                    "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                    pathname === "/admin/dashboard" ? "bg-muted font-medium" : "text-foreground/80",
                  )}
                >
                  <Shield className="mr-2 h-4 w-4" />
                  Admin Dashboard
                </Link>
                <Link
                  href="/admin/users"
                  className={cn(
                    "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                    pathname === "/admin/users" ? "bg-muted font-medium" : "text-foreground/80",
                  )}
                >
                  <UserCog className="mr-2 h-4 w-4" />
                  User Management
                </Link>
              </AdminOnly>

              {/* Manager Section - Only visible to managers and admins */}
              <ManagerPlus>
                <div className="pt-4 pb-2">
                  <h3 className="px-3 text-xs font-semibold text-muted-foreground">Management</h3>
                </div>
                <Link
                  href="/management/team"
                  className={cn(
                    "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                    pathname === "/management/team" ? "bg-muted font-medium" : "text-foreground/80",
                  )}
                >
                  <Users className="mr-2 h-4 w-4" />
                  Team Management
                </Link>
                <Link
                  href="/management/reports"
                  className={cn(
                    "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-muted",
                    pathname === "/management/reports" ? "bg-muted font-medium" : "text-foreground/80",
                  )}
                >
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Performance Reports
                </Link>
              </ManagerPlus>
            </nav>

            {/* Quick Actions */}
            <div className="space-y-2 px-1 mb-6">
              <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                <Link href="/help">
                  <HelpCircle className="mr-2 h-4 w-4" />
                  Help & Support
                </Link>
              </Button>
            </div>
          </div>

          {/* Sidebar Footer */}
          <div className="p-4 border-t flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <NotificationCenter />
              <UserAccountNav />
            </div>
            <ThemeToggle />
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 flex flex-col lg:pl-64">
          {/* Mobile Top Bar */}
          <div className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background/95 px-4 lg:hidden">
            <Button
              id="sidebar-toggle"
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle sidebar</span>
            </Button>
            <div className="flex-1 flex justify-between items-center">
              <Link href="/dashboard" className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-primary" />
                <span className="font-bold">DevTimeTracker</span>
              </Link>
              <div className="flex items-center space-x-2">
                <NotificationCenter />
                <UserAccountNav />
                <ThemeToggle />
              </div>
            </div>
          </div>

          {/* Page Content */}
          <main className="flex-1 overflow-y-auto">{children}</main>

          {/* Footer */}
          <footer className="border-t py-4 px-4 md:px-6 lg:px-8">
            <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
              <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
                &copy; {new Date().getFullYear()} DevTimeTracker. All rights reserved.
              </p>
              <div className="flex flex-wrap justify-center items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
                <Link href="/privacy" className="hover:underline">
                  Privacy Policy
                </Link>
                <Link href="/terms" className="hover:underline">
                  Terms of Service
                </Link>
                <Link href="/accessibility" className="hover:underline">
                  Accessibility
                </Link>
                <Link href="/contact" className="hover:underline">
                  Contact Us
                </Link>
              </div>
            </div>
          </footer>
        </div>

        {/* Overlay for mobile when sidebar is open */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-40 bg-black/50 lg:hidden"
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
          />
        )}
      </div>
    </ErrorBoundary>
  )
}
