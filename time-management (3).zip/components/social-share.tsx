"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Twitter, Facebook, Linkedin, Mail, LinkIcon, Check } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface SocialShareProps {
  url?: string
  title?: string
  description?: string
  className?: string
  compact?: boolean
}

export function SocialShare({
  url,
  title = "DevTimeTracker - Time Management for IT Professionals",
  description = "Advanced time management system for IT professionals",
  className = "",
  compact = false,
}: SocialShareProps) {
  const [copied, setCopied] = useState(false)

  // Use the current URL if none is provided
  const shareUrl = url || (typeof window !== "undefined" ? window.location.href : "")

  // Encode the parameters for sharing
  const encodedUrl = encodeURIComponent(shareUrl)
  const encodedTitle = encodeURIComponent(title)
  const encodedDescription = encodeURIComponent(description)

  // Share URLs for different platforms
  const twitterUrl = `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`
  const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`
  const linkedinUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`
  const mailUrl = `mailto:?subject=${encodedTitle}&body=${encodedDescription}%0A%0A${encodedUrl}`

  // Copy the URL to clipboard
  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div className={`flex ${compact ? "flex-col" : "flex-row"} gap-2 ${className}`}>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="outline"
              size={compact ? "icon" : "default"}
              onClick={() => window.open(twitterUrl, "_blank")}
              aria-label="Share on Twitter"
              className="focus-ring"
            >
              <Twitter className={compact ? "h-4 w-4" : "mr-2 h-4 w-4"} />
              {!compact && "Twitter"}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Share on Twitter</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="outline"
              size={compact ? "icon" : "default"}
              onClick={() => window.open(facebookUrl, "_blank")}
              aria-label="Share on Facebook"
              className="focus-ring"
            >
              <Facebook className={compact ? "h-4 w-4" : "mr-2 h-4 w-4"} />
              {!compact && "Facebook"}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Share on Facebook</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="outline"
              size={compact ? "icon" : "default"}
              onClick={() => window.open(linkedinUrl, "_blank")}
              aria-label="Share on LinkedIn"
              className="focus-ring"
            >
              <Linkedin className={compact ? "h-4 w-4" : "mr-2 h-4 w-4"} />
              {!compact && "LinkedIn"}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Share on LinkedIn</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="outline"
              size={compact ? "icon" : "default"}
              onClick={() => window.open(mailUrl, "_blank")}
              aria-label="Share via Email"
              className="focus-ring"
            >
              <Mail className={compact ? "h-4 w-4" : "mr-2 h-4 w-4"} />
              {!compact && "Email"}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Share via Email</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="outline"
              size={compact ? "icon" : "default"}
              onClick={copyToClipboard}
              aria-label="Copy link"
              className="focus-ring"
            >
              {copied ? (
                <>
                  <Check className={compact ? "h-4 w-4" : "mr-2 h-4 w-4"} />
                  {!compact && "Copied!"}
                </>
              ) : (
                <>
                  <LinkIcon className={compact ? "h-4 w-4" : "mr-2 h-4 w-4"} />
                  {!compact && "Copy Link"}
                </>
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>{copied ? "Copied!" : "Copy link"}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  )
}
