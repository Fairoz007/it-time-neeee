import { LoadingSpinner } from "@/components/loading-spinner"

export function AuthLoading() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-background to-muted">
      <div className="text-center">
        <LoadingSpinner className="mx-auto mb-4" />
        <h3 className="text-lg font-medium">Loading your account...</h3>
        <p className="text-sm text-muted-foreground">Please wait while we authenticate you</p>
      </div>
    </div>
  )
}
