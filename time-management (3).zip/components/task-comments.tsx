"use client"

import { useState, useEffect } from "react"
import { useTransition } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreHorizontal, Reply, ThumbsUp, Edit, Trash2 } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useToast } from "@/components/ui/use-toast"

import { addComment } from "./actions"
interface User {
  id: string
  name: string
  avatar?: string
  initials: string
}

interface Comment {
  id: string
  user: User
  content: string
  timestamp: Date
  likes: number
  liked?: boolean
  replies?: Comment[]
}

interface TaskCommentsProps {
  taskId: string
}

// Mock current user
const currentUser: User = {
  id: "current-user",
  name: "You",
  initials: "YO",
}

export function TaskComments({ taskId }: TaskCommentsProps) {
  const [comments, setComments] = useState<Comment[]>([])
  const [newComment, setNewComment] = useState("")
  const [replyingTo, setReplyingTo] = useState<string | null>(null)
  const [replyContent, setReplyContent] = useState("")
  const [editingComment, setEditingComment] = useState<string | null>(null)
  const [isPending, startTransition] = useTransition()
  const [editContent, setEditContent] = useState("")
  const { toast } = useToast()

  // Fetch comments on mount
  useEffect(() => {
    const fetchComments = async () => {
      // In a real app, you would fetch comments from the database
      // For now, we'll use mock data
      const mockComments: Comment[] = [
        {
          id: "comment-1",
          user: {
            id: "user-1",
            name: "John Doe",
            initials: "JD",
          },
          content: "This is a great task!",
          timestamp: new Date(),
          likes: 5,
          replies: [
            {
              id: "reply-1",
              user: {
                id: "user-2",
                name: "Jane Smith",
                initials: "JS",
              },
              content: "I agree!",
              timestamp: new Date(),
              likes: 2,
            },
          ],
        },
      ]
      setComments(mockComments)
    }

    fetchComments()
  }, [taskId])

  // Add a new comment
  const handleAddComment = async () => {
    if (!newComment.trim()) return
    startTransition(async () => {
      await addComment(taskId, newComment)
      setNewComment("")
      toast({
        title: "Comment added",
        description: "Your comment has been added successfully.",
      })
      const comment: Comment = {
        id: `comment-${Date.now()}`,
        user: currentUser,
        content: newComment,
        timestamp: new Date(),
        likes: 0,
        replies: [],
      }

      setComments([...comments, comment])
      setNewComment("")
    })
  }
  // Add a reply to a comment
  const handleAddReply = (commentId: string) => {
    if (!replyContent.trim()) return

    const reply: Comment = {
      id: `reply-${Date.now()}`,
      user: currentUser,
      content: replyContent,
      timestamp: new Date(),
      likes: 0,
    }

    const updatedComments = comments.map((comment) => {
      if (comment.id === commentId) {
        return {
          ...comment,
          replies: [...(comment.replies || []), reply],
        }
      }
      return comment
    })

    setComments(updatedComments)
    setReplyingTo(null)
    setReplyContent("")
  }

  // Toggle like on a comment
  const handleToggleLike = (commentId: string) => {
    const updateComment = (comments: Comment[]): Comment[] => {
      return comments.map((comment) => {
        if (comment.id === commentId) {
          return {
            ...comment,
            likes: comment.liked ? comment.likes - 1 : comment.likes + 1,
            liked: !comment.liked,
          }
        }

        if (comment.replies) {
          return {
            ...comment,
            replies: updateComment(comment.replies),
          }
        }

        return comment
      })
    }

    setComments(updateComment(comments))
  }

  // Start editing a comment
  const handleStartEdit = (comment: Comment) => {
    setEditingComment(comment.id)
    setEditContent(comment.content)
  }

  // Save edited comment
  const handleSaveEdit = (commentId: string) => {
    if (!editContent.trim()) return

    const updateComment = (comments: Comment[]): Comment[] => {
      return comments.map((comment) => {
        if (comment.id === commentId) {
          return {
            ...comment,
            content: editContent,
          }
        }

        if (comment.replies) {
          return {
            ...comment,
            replies: updateComment(comment.replies),
          }
        }

        return comment
      })
    }

    setComments(updateComment(comments))
    setEditingComment(null)
    setEditContent("")
  }

  // Delete a comment
  const handleDeleteComment = (commentId: string) => {
    const filterComments = (comments: Comment[]): Comment[] => {
      return comments
        .filter((comment) => comment.id !== commentId)
        .map((comment) => {
          if (comment.replies) {
            return {
              ...comment,
              replies: filterComments(comment.replies),
            }
          }
          return comment
        })
    }

    setComments(filterComments(comments))
  }

  // Render a single comment or reply
  const renderComment = (comment: Comment, isReply = false) => {
    const isCurrentUser = comment.user.id === currentUser.id

    return (
      <div key={comment.id} className={`mb-4 ${isReply ? "ml-12" : ""}`}>
        <div className="flex items-start space-x-3">
          <Avatar className="h-8 w-8">
            {comment.user.avatar && (
              <AvatarImage src={comment.user.avatar || "/placeholder.svg"} alt={comment.user.name} />
            )}
            <AvatarFallback>{comment.user.initials}</AvatarFallback>
          </Avatar>

          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium">{comment.user.name}</span>
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(comment.timestamp, { addSuffix: true })}
                </span>
              </div>

              {isCurrentUser && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleStartEdit(comment)}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => handleDeleteComment(comment.id)}
                      className="text-red-600 focus:text-red-600"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>

            {editingComment === comment.id ? (
              <div className="space-y-2">
                <Textarea
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  className="min-h-[80px]"
                />
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" size="sm" onClick={() => setEditingComment(null)}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={() => handleSaveEdit(comment.id)}>
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <p className="text-sm">{comment.content}</p>
            )}

            <div className="flex items-center space-x-4 pt-1">
              <Button
                variant="ghost"
                size="sm"
                className="h-auto p-0 text-xs"
                onClick={() => handleToggleLike(comment.id)}
              >
                <ThumbsUp className={`mr-1 h-3.5 w-3.5 ${comment.liked ? "fill-primary text-primary" : ""}`} />
                {comment.likes > 0 && comment.likes}
                <span className="ml-1">{comment.liked ? "Liked" : "Like"}</span>
              </Button>

              {!isReply && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-auto p-0 text-xs"
                  onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}
                >
                  <Reply className="mr-1 h-3.5 w-3.5" />
                  Reply
                </Button>
              )}
            </div>

            {replyingTo === comment.id && (
              <div className="mt-3 space-y-2">
                <Textarea
                  placeholder="Write a reply..."
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                  className="min-h-[80px]"
                />
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" size="sm" onClick={() => setReplyingTo(null)}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={() => handleAddReply(comment.id)}>
                    Reply
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>

        {comment.replies && comment.replies.length > 0 && (
          <div className="mt-3">{comment.replies.map((reply) => renderComment(reply, true))}</div>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Comments</h3>

      <div className="space-y-3">
        <Textarea
          placeholder="Add a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          className="min-h-[100px]"
        />
        <div className="flex justify-end">
          <Button onClick={handleAddComment} disabled={isPending}>
            Add Comment
          </Button>
        </div>
      </div>

      <div className="mt-6">
        {comments.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground">No comments yet. Be the first to comment!</p>
        ) : (
          comments.map((comment) => renderComment(comment))
        )}
      </div>
    </div>
  )
}
