"use client"

import { useState, useRef, useEffect } from "react"
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import { useRouter } from "next/navigation"

type SearchResult = {
  id: string
  type: "task" | "project" | "user" | "document"
  title: string
  description?: string
  url: string
}

// Mock search results - in a real app, this would come from an API
const mockSearchResults: SearchResult[] = [
  {
    id: "1",
    type: "task",
    title: "Fix authentication bug",
    description: "Critical issue with login system",
    url: "/tasks/1",
  },
  {
    id: "2",
    type: "task",
    title: "Update API documentation",
    description: "Add new endpoints and examples",
    url: "/tasks/2",
  },
  {
    id: "3",
    type: "project",
    title: "API Integration",
    description: "Third-party API integration project",
    url: "/projects/1",
  },
  {
    id: "4",
    type: "project",
    title: "Frontend Development",
    description: "UI/UX implementation for dashboard",
    url: "/projects/2",
  },
  { id: "5", type: "user", title: "John Doe", description: "Frontend Developer", url: "/team/1" },
  { id: "6", type: "user", title: "Jane Smith", description: "Project Manager", url: "/team/2" },
  {
    id: "7",
    type: "document",
    title: "Project Guidelines",
    description: "Company standards for project management",
    url: "/docs/1",
  },
  {
    id: "8",
    type: "document",
    title: "Coding Standards",
    description: "Best practices for code quality",
    url: "/docs/2",
  },
]

export function GlobalSearch() {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<SearchResult[]>([])
  const router = useRouter()
  const inputRef = useRef<HTMLInputElement>(null)

  // Keyboard shortcut to open search (Ctrl+K or Cmd+K)
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if ((e.key === "k" && (e.metaKey || e.ctrlKey)) || e.key === "/") {
        e.preventDefault()
        setOpen((open) => !open)
      }
    }

    document.addEventListener("keydown", down)
    return () => document.removeEventListener("keydown", down)
  }, [])

  // Search function
  const performSearch = (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([])
      return
    }

    const filteredResults = mockSearchResults.filter(
      (item) =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase())),
    )

    setResults(filteredResults)
  }

  // Handle search input change
  const handleSearchChange = (value: string) => {
    setQuery(value)
    performSearch(value)
  }

  // Handle selecting a search result
  const handleSelect = (result: SearchResult) => {
    setOpen(false)
    router.push(result.url)
  }

  return (
    <>
      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput
          ref={inputRef}
          placeholder="Search for tasks, projects, people..."
          value={query}
          onValueChange={handleSearchChange}
        />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>
          {results.length > 0 && (
            <>
              <CommandGroup heading="Tasks">
                {results
                  .filter((result) => result.type === "task")
                  .map((result) => (
                    <CommandItem key={result.id} onSelect={() => handleSelect(result)} className="flex items-center">
                      <div className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-blue-700">
                        <span className="text-xs">T</span>
                      </div>
                      <div>
                        <p>{result.title}</p>
                        {result.description && <p className="text-sm text-muted-foreground">{result.description}</p>}
                      </div>
                    </CommandItem>
                  ))}
              </CommandGroup>

              <CommandGroup heading="Projects">
                {results
                  .filter((result) => result.type === "project")
                  .map((result) => (
                    <CommandItem key={result.id} onSelect={() => handleSelect(result)} className="flex items-center">
                      <div className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-700">
                        <span className="text-xs">P</span>
                      </div>
                      <div>
                        <p>{result.title}</p>
                        {result.description && <p className="text-sm text-muted-foreground">{result.description}</p>}
                      </div>
                    </CommandItem>
                  ))}
              </CommandGroup>

              <CommandGroup heading="People">
                {results
                  .filter((result) => result.type === "user")
                  .map((result) => (
                    <CommandItem key={result.id} onSelect={() => handleSelect(result)} className="flex items-center">
                      <div className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-purple-100 text-purple-700">
                        <span className="text-xs">U</span>
                      </div>
                      <div>
                        <p>{result.title}</p>
                        {result.description && <p className="text-sm text-muted-foreground">{result.description}</p>}
                      </div>
                    </CommandItem>
                  ))}
              </CommandGroup>

              <CommandGroup heading="Documents">
                {results
                  .filter((result) => result.type === "document")
                  .map((result) => (
                    <CommandItem key={result.id} onSelect={() => handleSelect(result)} className="flex items-center">
                      <div className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-amber-100 text-amber-700">
                        <span className="text-xs">D</span>
                      </div>
                      <div>
                        <p>{result.title}</p>
                        {result.description && <p className="text-sm text-muted-foreground">{result.description}</p>}
                      </div>
                    </CommandItem>
                  ))}
              </CommandGroup>
            </>
          )}
        </CommandList>
      </CommandDialog>
    </>
  )
}
