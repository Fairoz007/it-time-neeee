"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { isAuthenticated } from "@/lib/auth-utils"
import { AuthLoading } from "@/components/auth-loading"

interface AuthCheckProps {
  children: React.ReactNode
  fallback?: React.ReactNode
  redirectTo?: string
}

export function AuthCheck({ children, fallback, redirectTo = "/login" }: AuthCheckProps) {
  const [isChecking, setIsChecking] = useState(true)
  const [isAuthed, setIsAuthed] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const authed = await isAuthenticated()
        setIsAuthed(authed)

        if (!authed && redirectTo) {
          const currentPath = window.location.pathname
          router.push(`${redirectTo}?redirect=${encodeURIComponent(currentPath)}`)
        }
      } catch (error) {
        console.error("Auth check error:", error)
      } finally {
        setIsChecking(false)
      }
    }

    checkAuth()
  }, [router, redirectTo])

  if (isChecking) {
    return <AuthLoading />
  }

  if (!isAuthed) {
    return fallback || null
  }

  return <>{children}</>
}
