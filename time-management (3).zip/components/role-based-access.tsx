"use client"

import { useAuth } from "@/contexts/auth-context"
import type { ReactNode } from "react"

interface RoleBasedAccessProps {
  children: ReactNode
  allowedRoles: Array<"admin" | "manager" | "user">
  fallback?: ReactNode
}

export function RoleBasedAccess({ children, allowedRoles, fallback }: RoleBasedAccessProps) {
  const { user, isAuthenticated } = useAuth()

  // If not authenticated, show fallback
  if (!isAuthenticated || !user) {
    console.log("RoleBasedAccess: Not authenticated, rendering fallback")
    return fallback ? <>{fallback}</> : null
  }

  // Check if user's role is in the allowed roles
  if (user.role && allowedRoles.includes(user.role)) {
    console.log("RoleBasedAccess: User authorized, rendering children")
    return <>{children}</>
  }

  // Not authorized, show fallback
  console.log("RoleBasedAccess: User not authorized, rendering fallback")
  return fallback ? <>{fallback}</> : null
}

export function AdminOnly({ children, fallback }: { children: ReactNode; fallback?: ReactNode }) {
  const { user, isAuthenticated, isAdmin } = useAuth()

  console.log("AdminOnly: Checking admin access")

  // If not authenticated, show fallback
  if (!isAuthenticated || !user) {
    console.log("AdminOnly: Not authenticated, rendering fallback")
    return fallback ? <>{fallback}</> : null
  }

  // Check if user is an admin
  if (isAdmin) {
    console.log("AdminOnly: User is admin, rendering children")
    return <>{children}</>
  }

  // Not authorized, show fallback
  console.log("AdminOnly: User is not admin, rendering fallback")
  return fallback ? <>{fallback}</> : null
}

export function ManagerPlus({ children, fallback }: { children: ReactNode; fallback?: ReactNode }) {
  return (
    <RoleBasedAccess allowedRoles={["admin", "manager"]} fallback={fallback}>
      {children}
    </RoleBasedAccess>
  )
}
