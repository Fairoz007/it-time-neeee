"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { format } from "date-fns"
import type { User } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

// Types
interface TaskFormProps {
  initialData?: Partial<TaskFormData>
  onSubmit: (data: TaskFormData) => Promise<void>
  onCancel?: () => void
  projects: Project[]
  users: User[]
  groups: UserGroup[]
}

interface TaskFormData {
  title: string
  description: string
  priority: "low" | "medium" | "high" | "critical"
  status: "todo" | "in_progress" | "completed"
  due_date: string
  project_id: string
  estimated_hours: number
  tags: string[]
  assignees: {
    users: string[] // User IDs
    groups: string[] // Group IDs
  }
}

interface Project {
  id: string
  name: string
}

interface User {
  id: string
  name: string
  email: string
  avatar_url?: string
  department?: string
}

interface UserGroup {
  id: string
  name: string
  description: string
  members: string[] // User IDs
}

export function TaskForm({ initialData, onSubmit, onCancel, projects, users, groups }: TaskFormProps) {
  const [formData, setFormData] = useState<TaskFormData>({
    title: "",
    description: "",
    priority: "medium",
    status: "todo",
    due_date: format(new Date(), "yyyy-MM-dd"),
    project_id: "",
    estimated_hours: 0,
    tags: [],
    assignees: {
      users: [],
      groups: []
    },
    ...initialData
  })
  
  const [tagInput, setTagInput] = useState("")
  const [assignmentTab, setAssignmentTab] = useState<"users" | "groups">("users")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [date, setDate] = useState<Date | undefined>(
    formData.due_date ? new Date(formData.due_date) : new Date()
  )
  
  // Update due_date when date changes
  useEffect(() => {
    if (date) {
      setFormData(prev => ({
        ...prev,
        due_date: format(date, "yyyy-MM-dd")
      }))
    }
  }, [date])
  
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.title || !formData.project_id) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      })
      return
    }
    
    setIsSubmitting(true)
    
    try {
      await onSubmit(formData)
    } catch (error) {
      console.error("Error submitting task:", error)
      toast({
        title: "Error",
        description: "Failed to save task. Please try again.",
        variant: "destructive"
      })
    } finally {
      setIsSubmitting(false)
    }
  }
  
  // Handle tag input
  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()]
      })
      setTagInput("")
    }
  }
  
  // Handle tag removal
  const handleRemoveTag = (tag: string) => {
    setFormData({
      ...formData,
      \
