import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckSquare, AlertCircle, Play } from "lucide-react"
import { format } from "date-fns"

export function RecentTasks() {
  // Mock data for recent tasks
  const tasks = [
    {
      id: "1",
      title: "Fix authentication bug",
      description: "Users are experiencing login issues after the latest deployment",
      priority: "critical",
      dueDate: new Date(),
      project: "API Integration",
    },
    {
      id: "2",
      title: "Update API documentation",
      description: "Add new endpoints and authentication flow",
      priority: "medium",
      dueDate: new Date(Date.now() + 86400000), // Tomorrow
      project: "API Integration",
    },
    {
      id: "3",
      title: "Design new dashboard layout",
      description: "Create wireframes and mockups for the new dashboard",
      priority: "high",
      dueDate: new Date(Date.now() + 172800000), // Day after tomorrow
      project: "Frontend Development",
    },
  ]

  // Get priority badge color
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-500"
      case "high":
        return "bg-amber-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Priority Tasks</CardTitle>
        <CardDescription>Tasks requiring immediate attention</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {tasks.map((task) => (
            <div key={task.id} className="flex items-center space-x-4">
              <div className="rounded-full bg-red-100 p-1">
                <AlertCircle
                  className={`h-4 w-4 ${task.priority === "critical" ? "text-red-600" : "text-amber-600"}`}
                />
              </div>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium leading-none">{task.title}</p>
                <div className="flex items-center">
                  <p className="text-xs text-muted-foreground mr-2">Due {format(task.dueDate, "MMM d, yyyy")}</p>
                  <span className={`text-xs ${getPriorityColor(task.priority)} px-1.5 py-0.5 rounded-full text-white`}>
                    {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                  </span>
                </div>
              </div>
              <Button variant="outline" size="sm">
                <Play className="mr-1 h-3 w-3" />
                Start
              </Button>
            </div>
          ))}

          <Button variant="outline" className="w-full mt-2">
            <CheckSquare className="mr-2 h-4 w-4" />
            Create New Task
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default RecentTasks
