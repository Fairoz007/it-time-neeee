"use client"

import { useState, useEffect, useRef, type ReactNode } from "react"
import { LoadingSpinner } from "@/components/loading-spinner"

interface DynamicContentProps {
  children: ReactNode
  loading?: boolean
  delay?: number
  fallback?: ReactNode
  onLoad?: () => void
  className?: string
}

export function DynamicContent({
  children,
  loading = false,
  delay = 300,
  fallback,
  onLoad,
  className = "",
}: DynamicContentProps) {
  const [isLoading, setIsLoading] = useState(loading)
  const [showContent, setShowContent] = useState(!loading)
  const [showFallback, setShowFallback] = useState(loading)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    if (loading) {
      setIsLoading(true)
      setShowContent(false)

      // Add a small delay before showing the loading state to prevent flashing
      timeoutRef.current = setTimeout(() => {
        setShowFallback(true)
      }, delay)
    } else {
      setIsLoading(false)
      setShowFallback(false)
      setShowContent(true)

      if (onLoad) {
        onLoad()
      }
    }

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [loading, delay, onLoad])

  return (
    <div className={className}>
      {showContent && <div className="animate-fade-in">{children}</div>}

      {showFallback && (
        <div className="animate-fade-in">
          {fallback || (
            <div className="flex items-center justify-center p-8">
              <LoadingSpinner />
            </div>
          )}
        </div>
      )}
    </div>
  )
}
