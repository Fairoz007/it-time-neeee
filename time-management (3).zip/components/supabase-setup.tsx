"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase-client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { LoadingSpinner } from "@/components/loading-spinner"
import { AlertCircle, CheckCircle } from "lucide-react"

export function SupabaseSetup() {
  const [status, setStatus] = useState<"checking" | "connected" | "error">("checking")
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  useEffect(() => {
    const checkConnection = async () => {
      try {
        // Try to connect to Supabase
        const { data, error } = await supabase.from("projects").select("count").limit(1)

        if (error) {
          throw error
        }

        setStatus("connected")
      } catch (err) {
        console.error("Supabase connection error:", err)
        setStatus("error")
        setErrorMessage(err instanceof Error ? err.message : "Unknown error")
      }
    }

    checkConnection()
  }, [])

  if (status === "checking") {
    return (
      <Card className="w-full max-w-md mx-auto mt-8">
        <CardHeader>
          <CardTitle>Checking Database Connection</CardTitle>
          <CardDescription>Verifying connection to Supabase...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <LoadingSpinner />
        </CardContent>
      </Card>
    )
  }

  if (status === "error") {
    return (
      <Card className="w-full max-w-md mx-auto mt-8 border-red-200">
        <CardHeader>
          <CardTitle className="flex items-center text-red-600">
            <AlertCircle className="mr-2 h-5 w-5" />
            Database Connection Error
          </CardTitle>
          <CardDescription>Could not connect to Supabase. Please check your configuration.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-red-50 p-4 rounded-md text-sm text-red-800">
            <p className="font-medium">Error details:</p>
            <p className="mt-1">{errorMessage}</p>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full" onClick={() => window.location.reload()}>
            Retry Connection
          </Button>
        </CardFooter>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-md mx-auto mt-8 border-green-200">
      <CardHeader>
        <CardTitle className="flex items-center text-green-600">
          <CheckCircle className="mr-2 h-5 w-5" />
          Database Connected
        </CardTitle>
        <CardDescription>Successfully connected to Supabase database.</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">
          Your application is now ready to use with Supabase as the data persistence layer. All dashboard components
          will fetch and store data in real-time.
        </p>
      </CardContent>
      <CardFooter>
        <Button className="w-full" onClick={() => (window.location.href = "/dashboard")}>
          Go to Dashboard
        </Button>
      </CardFooter>
    </Card>
  )
}
