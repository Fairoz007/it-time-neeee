"use client"

import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function AuthDebug() {
  const { user, session, redirectUrl } = useAuth()
  const [showDetails, setShowDetails] = useState(false)

  return (
    <Card className="w-full max-w-md mx-auto mt-4">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Authentication Debug
          <Button variant="outline" size="sm" onClick={() => setShowDetails(!showDetails)}>
            {showDetails ? "Hide Details" : "Show Details"}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div>
            <span className="font-medium">Auth Status:</span>{" "}
            <span className={user ? "text-green-600" : "text-red-600"}>
              {user ? "Authenticated" : "Not Authenticated"}
            </span>
          </div>

          <div>
            <span className="font-medium">Redirect URL:</span>{" "}
            <span className="text-blue-600">{redirectUrl || "None"}</span>
          </div>

          {showDetails && user && (
            <>
              <div className="mt-4">
                <span className="font-medium">User ID:</span> {user.id}
              </div>
              <div>
                <span className="font-medium">Email:</span> {user.email}
              </div>
              <div>
                <span className="font-medium">Created At:</span> {new Date(user.created_at).toLocaleString()}
              </div>
              <div className="mt-4">
                <span className="font-medium">Session Expires:</span>{" "}
                {session ? new Date(session.expires_at * 1000).toLocaleString() : "N/A"}
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
