// This file is intentionally left empty as we're removing authentication
// The middleware.ts file can be deleted entirely
