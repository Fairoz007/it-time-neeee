-- Correct insert query that includes the id column
INSERT INTO profiles (
  id,
  user_id, 
  full_name, 
  email, 
  role, 
  created_at, 
  updated_at
)
SELECT 
  uuid_generate_v4(), -- Generate a UUID for the id column
  au.id, 
  COALESCE(au.raw_user_meta_data->>'full_name', au.raw_user_meta_data->>'name', SPLIT_PART(au.email, '@', 1), 'User'),
  au.email,
  COALESCE(au.raw_user_meta_data->>'role', 'user'),
  NOW(),
  NOW()
FROM auth.users au
LEFT JOIN profiles p ON au.id = p.user_id
WHERE p.user_id IS NULL;
