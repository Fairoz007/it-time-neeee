-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Insert users from auth.users into profiles if they don't exist
-- This query handles the table structure shown in your screenshot
INSERT INTO profiles (
  id,           -- UUID with default uuid_generate_v4()
  user_id,      -- UUID from auth.users.id
  full_name,    -- Extracted from user metadata or email
  email,        -- From auth.users.email
  avatar_url,   -- Left as NULL
  department,   -- Left as NULL
  job_title,    -- Left as NULL
  bio,          -- Left as NULL
  created_at,   -- Current timestamp
  updated_at,   -- Current timestamp
  role          -- Default 'user' or from metadata if available
)
SELECT
  uuid_generate_v4(),  -- Generate UUID for id
  au.id,               -- user_id from auth.users
  COALESCE(
    au.raw_user_meta_data->>'full_name', 
    au.raw_user_meta_data->>'name', 
    SPLIT_PART(au.email, '@', 1), 
    'User'
  ),                   -- Extract name from metadata or email
  au.email,            -- Email from auth.users
  NULL,                -- avatar_url
  NULL,                -- department
  NULL,                -- job_title
  NULL,                -- bio
  COALESCE(au.created_at, NOW()),  -- created_at
  NOW(),               -- updated_at
  COALESCE(au.raw_user_meta_data->>'role', 'user')  -- role
FROM auth.users au
LEFT JOIN profiles p ON au.id = p.user_id
WHERE p.user_id IS NULL;  -- Only insert users that don't already have profiles
