-- Create a backup of the existing profiles table
CREATE TABLE profiles_backup AS SELECT * FROM profiles;

-- Drop the existing profiles table
DROP TABLE profiles;

-- Create a new profiles table with proper structure
CREATE TABLE profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT,
    email TEXT,
    avatar_url TEXT,
    department TEXT,
    job_title TEXT,
    bio TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    role VARCHAR(50) DEFAULT 'user' NOT NULL
);

-- Copy data from backup, generating new IDs where needed
INSERT INTO profiles (
    id,
    user_id,
    full_name,
    email,
    avatar_url,
    department,
    job_title,
    bio,
    created_at,
    updated_at,
    role
)
SELECT
    COALESCE(id, uuid_generate_v4()),
    user_id,
    full_name,
    email,
    avatar_url,
    department,
    job_title,
    bio,
    created_at,
    updated_at,
    COALESCE(role, 'user')
FROM profiles_backup;

-- Add indexes for performance
CREATE INDEX profiles_user_id_idx ON profiles(user_id);
CREATE INDEX profiles_email_idx ON profiles(email);
