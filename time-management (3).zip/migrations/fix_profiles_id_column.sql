-- Check if the id column exists and modify it to have a default value
ALTER TABLE profiles 
ALTER COLUMN id SET DEFAULT uuid_generate_v4();

-- Make sure the uuid-ossp extension is enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Add a comment explaining the column
COMMENT ON COLUMN profiles.id IS 'Primary key - automatically generated UUID';
