-- Check if role column exists, if not add it
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'profiles'
        AND column_name = 'role'
    ) THEN
        ALTER TABLE profiles ADD COLUMN role VARCHAR(50) DEFAULT 'user' NOT NULL;
        COMMENT ON COLUMN profiles.role IS 'User role: admin, manager, or user';
    END IF;
END
$$;
