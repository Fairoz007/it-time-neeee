-- Add role column to profiles table if it doesn't exist
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role VARCHAR(50) DEFAULT 'user';

-- Create index on role column
CREATE INDEX IF NOT EXISTS profiles_role_idx ON profiles(role);

-- Update existing profiles to have roles
-- This is just an example, in a real application you would assign roles more carefully
UPDATE profiles 
SET role = 'admin' 
WHERE id IN (SELECT id FROM profiles ORDER BY created_at ASC LIMIT 1);

UPDATE profiles 
SET role = 'manager' 
WHERE id IN (SELECT id FROM profiles WHERE role != 'admin' ORDER BY created_at ASC LIMIT 2);

-- Add department column if it doesn't exist
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS department VARCHAR(100);

-- Create index on department column
CREATE INDEX IF NOT EXISTS profiles_department_idx ON profiles(department);

-- Update some profiles with departments
UPDATE profiles 
SET department = 'Engineering' 
WHERE id IN (SELECT id FROM profiles ORDER BY RANDOM() LIMIT (SELECT COUNT(*) / 3 FROM profiles));

UPDATE profiles 
SET department = 'Design' 
WHERE id IN (SELECT id FROM profiles WHERE department IS NULL ORDER BY RANDOM() LIMIT (SELECT COUNT(*) / 4 FROM profiles));

UPDATE profiles 
SET department = 'Product' 
WHERE id IN (SELECT id FROM profiles WHERE department IS NULL ORDER BY RANDOM() LIMIT (SELECT COUNT(*) / 4 FROM profiles));

UPDATE profiles 
SET department = 'Marketing' 
WHERE department IS NULL;
