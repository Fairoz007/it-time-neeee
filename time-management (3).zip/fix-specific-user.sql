-- Fix the specific user mentioned in the error
UPDATE profiles
SET id = uuid_generate_v4()
WHERE user_id = 'ad424500-aa5a-4c2a-b5c0-23ba5ed6ef22'
AND id IS NULL;
