"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { supabase } from "@/lib/supabase-client"
import { toast } from "@/components/ui/use-toast"

interface TimeEntry {
  id: string
  task_id: string | null
  project_id: string | null
  user_id: string
  start_time: string
  end_time: string | null
  duration: number
  notes: string
  billable: boolean
}

interface ActiveTimeEntry {
  id: string
  taskId: string | null
  projectId: string | null
  startTime: string
  taskTitle?: string
  projectName?: string
}

export function useTimeTracking() {
  const [isTracking, setIsTracking] = useState(false)
  const [elapsedTime, setElapsedTime] = useState(0)
  const [activeEntry, setActiveEntry] = useState<ActiveTimeEntry | null>(null)
  const [notes, setNotes] = useState("")
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const lastTickRef = useRef<number>(Date.now())

  // Format seconds to HH:MM:SS
  const formatElapsedTime = useCallback(() => {
    const hours = Math.floor(elapsedTime / 3600)
    const minutes = Math.floor((elapsedTime % 3600) / 60)
    const seconds = elapsedTime % 60

    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
  }, [elapsedTime])

  // Check for existing active time entry on mount
  useEffect(() => {
    const checkForActiveEntry = async () => {
      try {
        // First check localStorage for a cached entry
        const storedEntry = localStorage.getItem("activeTimeEntry")

        if (storedEntry) {
          const parsedEntry = JSON.parse(storedEntry) as ActiveTimeEntry
          const startTimeMs = new Date(parsedEntry.startTime).getTime()
          const currentTimeMs = Date.now()
          const elapsedSeconds = Math.floor((currentTimeMs - startTimeMs) / 1000)

          setActiveEntry(parsedEntry)
          setIsTracking(true)
          setElapsedTime(elapsedSeconds)

          console.log("Restored time entry from localStorage:", parsedEntry)
          return
        }

        // If nothing in localStorage, check Supabase
        const { data, error } = await supabase
          .from("time_entries")
          .select("*, tasks(title), projects(name)")
          .is("end_time", null)
          .order("start_time", { ascending: false })
          .limit(1)
          .single()

        if (error) {
          // No active entry found or error
          console.log("No active time entry found in database")
          return
        }

        if (data) {
          const entry: ActiveTimeEntry = {
            id: data.id,
            taskId: data.task_id,
            projectId: data.project_id,
            startTime: data.start_time,
            taskTitle: data.tasks?.title,
            projectName: data.projects?.name,
          }

          setActiveEntry(entry)
          setIsTracking(true)

          // Calculate elapsed time
          const startTime = new Date(data.start_time).getTime()
          const currentTime = Date.now()
          const elapsedSeconds = Math.floor((currentTime - startTime) / 1000)
          setElapsedTime(elapsedSeconds)

          // Store in localStorage for persistence
          localStorage.setItem("activeTimeEntry", JSON.stringify(entry))

          console.log("Restored time entry from database:", entry)
        }
      } catch (error) {
        console.error("Error checking for active time entry:", error)
      }
    }

    checkForActiveEntry()
  }, [])

  // Set up interval for tracking time with drift compensation
  useEffect(() => {
    if (isTracking) {
      lastTickRef.current = Date.now()

      intervalRef.current = setInterval(() => {
        const now = Date.now()
        const actualElapsed = now - lastTickRef.current
        lastTickRef.current = now

        // Add the actual elapsed time (in seconds) to account for any drift
        setElapsedTime((prev) => prev + Math.floor(actualElapsed / 1000))
      }, 1000)
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isTracking])

  // Start time tracking
  const startTracking = async (options: {
    taskId?: string
    projectId?: string
    notes?: string
    taskTitle?: string
    projectName?: string
  }) => {
    try {
      if (isTracking) {
        toast({
          title: "Timer already running",
          description: "Please stop the current timer before starting a new one.",
        })
        return null
      }

      const { taskId, projectId, notes: initialNotes, taskTitle, projectName } = options
      const now = new Date().toISOString()
      const userId = "default-user" // Use a default user ID since we're not using authentication

      // Create entry in Supabase
      const { data, error } = await supabase
        .from("time_entries")
        .insert([
          {
            task_id: taskId || null,
            project_id: projectId || null,
            user_id: userId,
            start_time: now,
            notes: initialNotes || "",
            billable: true,
          },
        ])
        .select()

      if (error) {
        throw error
      }

      if (!data || data.length === 0) {
        throw new Error("Failed to create time entry")
      }

      const entry: ActiveTimeEntry = {
        id: data[0].id,
        taskId: taskId || null,
        projectId: projectId || null,
        startTime: now,
        taskTitle,
        projectName,
      }

      // Update state
      setActiveEntry(entry)
      setIsTracking(true)
      setElapsedTime(0)
      setNotes(initialNotes || "")

      // Store in localStorage for persistence
      localStorage.setItem("activeTimeEntry", JSON.stringify(entry))

      toast({
        title: "Timer started",
        description: taskTitle ? `Tracking time for "${taskTitle}"` : "Time tracking started",
      })

      return entry
    } catch (error) {
      console.error("Error starting time tracking:", error)
      toast({
        title: "Error starting timer",
        description: "There was a problem starting the timer. Please try again.",
        variant: "destructive",
      })
      return null
    }
  }

  // Stop time tracking
  const stopTracking = async (finalNotes?: string) => {
    if (!isTracking || !activeEntry) {
      return null
    }

    try {
      const now = new Date().toISOString()
      const notesToSave = finalNotes || notes

      // Update the entry in Supabase
      const { data, error } = await supabase
        .from("time_entries")
        .update({
          end_time: now,
          duration: elapsedTime,
          notes: notesToSave,
        })
        .eq("id", activeEntry.id)
        .select()

      if (error) {
        throw error
      }

      // If this was tracking a task, update the task's actual hours
      if (activeEntry.taskId) {
        const hoursSpent = elapsedTime / 3600 // Convert seconds to hours

        await supabase
          .from("tasks")
          .select("actual_hours")
          .eq("id", activeEntry.taskId)
          .single()
          .then(({ data: taskData, error: taskError }) => {
            if (!taskError && taskData) {
              const currentHours = taskData.actual_hours || 0

              supabase
                .from("tasks")
                .update({
                  actual_hours: currentHours + hoursSpent,
                })
                .eq("id", activeEntry.taskId)
                .then(() => {
                  console.log(`Updated task ${activeEntry.taskId} with ${hoursSpent} additional hours`)
                })
            }
          })
      }

      // If this was tracking a project, update the project's actual hours
      if (activeEntry.projectId) {
        const hoursSpent = elapsedTime / 3600 // Convert seconds to hours

        await supabase
          .from("projects")
          .select("actual_hours")
          .eq("id", activeEntry.projectId)
          .single()
          .then(({ data: projectData, error: projectError }) => {
            if (!projectError && projectData) {
              const currentHours = projectData.actual_hours || 0

              supabase
                .from("projects")
                .update({
                  actual_hours: currentHours + hoursSpent,
                })
                .eq("id", activeEntry.projectId)
                .then(() => {
                  console.log(`Updated project ${activeEntry.projectId} with ${hoursSpent} additional hours`)
                })
            }
          })
      }

      // Reset state
      setIsTracking(false)
      setActiveEntry(null)
      setElapsedTime(0)
      setNotes("")

      // Remove from localStorage
      localStorage.removeItem("activeTimeEntry")

      toast({
        title: "Timer stopped",
        description: `Time tracked: ${formatElapsedTime()}`,
      })

      return data?.[0] || null
    } catch (error) {
      console.error("Error stopping time tracking:", error)
      toast({
        title: "Error stopping timer",
        description: "There was a problem stopping the timer. Please try again.",
        variant: "destructive",
      })
      return null
    }
  }

  // Reset timer (only if not tracking)
  const resetTimer = () => {
    if (isTracking) {
      toast({
        title: "Cannot reset active timer",
        description: "Please stop the timer before resetting.",
        variant: "destructive",
      })
      return false
    }

    setElapsedTime(0)
    setNotes("")
    return true
  }

  // Discard current time entry
  const discardTimeEntry = async () => {
    if (!isTracking || !activeEntry) {
      return false
    }

    try {
      // Delete the entry from Supabase
      const { error } = await supabase.from("time_entries").delete().eq("id", activeEntry.id)

      if (error) {
        throw error
      }

      // Reset state
      setIsTracking(false)
      setActiveEntry(null)
      setElapsedTime(0)
      setNotes("")

      // Remove from localStorage
      localStorage.removeItem("activeTimeEntry")

      toast({
        title: "Timer discarded",
        description: "Time entry has been discarded.",
      })

      return true
    } catch (error) {
      console.error("Error discarding time entry:", error)
      toast({
        title: "Error discarding timer",
        description: "There was a problem discarding the timer. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  return {
    isTracking,
    elapsedTime,
    activeEntry,
    notes,
    setNotes,
    formatElapsedTime,
    startTracking,
    stopTracking,
    resetTimer,
    discardTimeEntry,
  }
}
