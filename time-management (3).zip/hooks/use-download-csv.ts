"use client"

import { useCallback } from "react"

export function useDownloadCsv() {
  const downloadCsv = useCallback((data: any[], filename: string) => {
    if (!data || data.length === 0) {
      console.warn("No data to download")
      return
    }

    const csv = convertArrayToCSV(data)
    download(csv, filename)
  }, [])

  const convertArrayToCSV = (data: any[]): string => {
    const header = Object.keys(data[0]).join(",")
    const rows = data.map((item) => Object.values(item).join(","))
    return `${header}\n${rows.join("\n")}`
  }

  const download = (csv: string, filename: string) => {
    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${filename}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return { downloadCsv }
}
