"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import {
  type Project,
  type Task,
  type TimeEntry,
  type Integration,
  fetchProjects,
  fetchTasks,
  fetchTimeEntries,
  fetchIntegrations,
  fetchDashboardMetrics,
} from "@/lib/supabase-client"

interface DataContextType {
  projects: Project[]
  tasks: Task[]
  timeEntries: TimeEntry[]
  integrations: Integration[]
  dashboardMetrics: {
    activeProjects: number
    pendingTasks: number
    hoursTrackedThisWeek: number
    productivityScore: number
  }
  loading: {
    projects: boolean
    tasks: boolean
    timeEntries: boolean
    integrations: boolean
    dashboardMetrics: boolean
  }
  error: {
    projects: string | null
    tasks: string | null
    timeEntries: string | null
    integrations: string | null
    dashboardMetrics: string | null
  }
  refreshProjects: () => Promise<void>
  refreshTasks: () => Promise<void>
  refreshTimeEntries: () => Promise<void>
  refreshIntegrations: () => Promise<void>
  refreshDashboardMetrics: () => Promise<void>
  refreshAll: () => Promise<void>
}

const DataContext = createContext<DataContextType | undefined>(undefined)

export function DataProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([])
  const [tasks, setTasks] = useState<Task[]>([])
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([])
  const [integrations, setIntegrations] = useState<Integration[]>([])
  const [dashboardMetrics, setDashboardMetrics] = useState({
    activeProjects: 0,
    pendingTasks: 0,
    hoursTrackedThisWeek: 0,
    productivityScore: 0,
  })

  const [loading, setLoading] = useState({
    projects: true,
    tasks: true,
    timeEntries: true,
    integrations: true,
    dashboardMetrics: true,
  })

  const [error, setError] = useState({
    projects: null as string | null,
    tasks: null as string | null,
    timeEntries: null as string | null,
    integrations: null as string | null,
    dashboardMetrics: null as string | null,
  })

  // Fetch initial data
  useEffect(() => {
    console.log("DataProvider: Initial data fetch")
    refreshAll()
  }, [])

  // Refresh functions
  // Improve error handling in the data context to prevent white screen on data fetch failures

  // Update the refreshProjects function to handle errors more gracefully
  const refreshProjects = async () => {
    console.log("Refreshing projects...")
    setLoading((prev) => ({ ...prev, projects: true }))
    setError((prev) => ({ ...prev, projects: null }))

    try {
      const data = await fetchProjects()
      console.log(`Fetched ${data.length} projects`)
      setProjects(data)
    } catch (err) {
      console.error("Error fetching projects:", err)
      setError((prev) => ({ ...prev, projects: "Failed to fetch projects. Using mock data instead." }))
      // Still set projects to empty array to prevent UI from breaking
      setProjects([])
    } finally {
      setLoading((prev) => ({ ...prev, projects: false }))
    }
  }

  const refreshTasks = async () => {
    console.log("Refreshing tasks...")
    setLoading((prev) => ({ ...prev, tasks: true }))
    setError((prev) => ({ ...prev, tasks: null }))

    try {
      const data = await fetchTasks()
      console.log(`Fetched ${data.length} tasks`)
      setTasks(data)
    } catch (err) {
      console.error("Error fetching tasks:", err)
      setError((prev) => ({ ...prev, tasks: "Failed to fetch tasks. Using mock data instead." }))
      // Still set tasks to empty array to prevent UI from breaking
      setTasks([])
    } finally {
      setLoading((prev) => ({ ...prev, tasks: false }))
    }
  }

  const refreshTimeEntries = async () => {
    console.log("Refreshing time entries...")
    setLoading((prev) => ({ ...prev, timeEntries: true }))
    setError((prev) => ({ ...prev, timeEntries: null }))

    try {
      const data = await fetchTimeEntries()
      console.log(`Fetched ${data.length} time entries`)
      setTimeEntries(data)
    } catch (err) {
      console.error("Error fetching time entries:", err)
      setError((prev) => ({ ...prev, timeEntries: "Failed to fetch time entries. Using mock data instead." }))
      setTimeEntries([])
    } finally {
      setLoading((prev) => ({ ...prev, timeEntries: false }))
    }
  }

  const refreshIntegrations = async () => {
    console.log("Refreshing integrations...")
    setLoading((prev) => ({ ...prev, integrations: true }))
    setError((prev) => ({ ...prev, integrations: null }))

    try {
      const data = await fetchIntegrations()
      console.log(`Fetched ${data.length} integrations`)
      setIntegrations(data)
    } catch (err) {
      console.error("Error fetching integrations:", err)
      setError((prev) => ({ ...prev, integrations: "Failed to fetch integrations. Using mock data instead." }))
      setIntegrations([])
    } finally {
      setLoading((prev) => ({ ...prev, integrations: false }))
    }
  }

  const refreshDashboardMetrics = async () => {
    console.log("Refreshing dashboard metrics...")
    setLoading((prev) => ({ ...prev, dashboardMetrics: true }))
    setError((prev) => ({ ...prev, dashboardMetrics: null }))

    try {
      // Use a default user ID since we're removing authentication
      const userId = "default-user"
      const metrics = await fetchDashboardMetrics(userId)
      console.log("Fetched dashboard metrics:", metrics)
      setDashboardMetrics(metrics)
    } catch (err) {
      console.error("Error fetching dashboard metrics:", err)
      setError((prev) => ({ ...prev, dashboardMetrics: "Failed to fetch dashboard metrics. Using mock data instead." }))
      setDashboardMetrics({
        activeProjects: 0,
        pendingTasks: 0,
        hoursTrackedThisWeek: 0,
        productivityScore: 0,
      })
    } finally {
      setLoading((prev) => ({ ...prev, dashboardMetrics: false }))
    }
  }

  const refreshAll = async () => {
    console.log("Refreshing all data...")
    try {
      // Use Promise.allSettled to continue even if some requests fail
      await Promise.allSettled([
        refreshProjects(),
        refreshTasks(),
        refreshTimeEntries(),
        refreshIntegrations(),
        refreshDashboardMetrics(),
      ])
      console.log("All data refresh attempts completed")
    } catch (err) {
      console.error("Error refreshing all data:", err)
    }
  }

  const value = {
    projects,
    tasks,
    timeEntries,
    integrations,
    dashboardMetrics,
    loading,
    error,
    refreshProjects,
    refreshTasks,
    refreshTimeEntries,
    refreshIntegrations,
    refreshDashboardMetrics,
    refreshAll,
  }

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>
}

export function useData() {
  const context = useContext(DataContext)
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider")
  }
  return context
}
