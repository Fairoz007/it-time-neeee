"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase-client"
import { toast } from "@/components/ui/use-toast"

// Define user type with role
interface User {
  id: string
  email: string
  name?: string
  avatar_url?: string
  role: "admin" | "manager" | "user" // Added role field
  department?: string
  created_at?: string
}

// Define auth context type
type AuthContextType = {
  user: User | null
  session: any | null
  isLoading: boolean
  isInitialized: boolean
  isAuthenticated: boolean
  isAdmin: boolean
  isManager: boolean
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  signUp: (
    email: string,
    password: string,
    name: string,
    role?: string,
  ) => Promise<{
    success: boolean
    error?: string
    warning?: string
  }>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>
  updateUserProfile: (updates: Partial<User>) => Promise<{ success: boolean; error?: string }>
  redirectUrl: string | null
  setRedirectUrl: (url: string | null) => void
}

// Create the context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  isLoading: true,
  isInitialized: false,
  isAuthenticated: false,
  isAdmin: false,
  isManager: false,
  signIn: async () => ({ success: false, error: "Not implemented" }),
  signUp: async () => ({ success: false, error: "Not implemented" }),
  signOut: async () => {},
  resetPassword: async () => ({ success: false, error: "Not implemented" }),
  updateUserProfile: async () => ({ success: false, error: "Not implemented" }),
  redirectUrl: null,
  setRedirectUrl: () => {},
})

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<any | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isInitialized, setIsInitialized] = useState(false)
  const [redirectUrl, setRedirectUrl] = useState<string | null>(null)
  const router = useRouter()

  // Initialize auth state
  useEffect(() => {
    const initAuth = async () => {
      try {
        // Get current session
        const { data, error } = await supabase.auth.getSession()

        if (error) {
          console.error("Error getting session:", error)
          setIsLoading(false)
          setIsInitialized(true)
          return
        }

        if (data.session) {
          setSession(data.session)

          // Get user profile with role information
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("user_id", data.session.user.id)
            .single()

          // Create a user object with role information
          const userObj: User = {
            id: data.session.user.id,
            email: data.session.user.email || "",
            name:
              data.session.user.user_metadata?.name ||
              profileData?.full_name ||
              data.session.user.email?.split("@")[0] ||
              "User",
            avatar_url: profileData?.avatar_url || data.session.user.user_metadata?.avatar_url,
            role: profileData?.role || "user", // Default to user role if not specified
            department: profileData?.department,
            created_at: profileData?.created_at,
          }

          setUser(userObj)
        }
      } catch (error) {
        console.error("Auth initialization error:", error)
      } finally {
        setIsLoading(false)
        setIsInitialized(true)
      }
    }

    // Set up auth state change listener
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      console.log("Auth state changed:", event, newSession ? "session exists" : "no session")

      if (event === "SIGNED_IN" && newSession) {
        setSession(newSession)

        try {
          // Get user profile with role information
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("user_id", newSession.user.id)
            .single()

          // Create a user object with role information
          const userObj: User = {
            id: newSession.user.id,
            email: newSession.user.email || "",
            name:
              newSession.user.user_metadata?.name ||
              profileData?.full_name ||
              newSession.user.email?.split("@")[0] ||
              "User",
            avatar_url: profileData?.avatar_url || newSession.user.user_metadata?.avatar_url,
            role: profileData?.role || "user", // Default to user role if not specified
            department: profileData?.department,
            created_at: profileData?.created_at,
          }

          setUser(userObj)

          // Redirect after sign in if there's a redirect URL
          if (redirectUrl) {
            router.push(redirectUrl)
            setRedirectUrl(null)
          } else {
            router.push("/dashboard")
          }
        } catch (error) {
          console.error("Error fetching user profile:", error)
        }
      } else if (event === "SIGNED_OUT") {
        setUser(null)
        setSession(null)
      } else if (event === "USER_UPDATED" && newSession) {
        try {
          // Get updated user profile with role information
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("user_id", newSession.user.id)
            .single()

          // Update user data when profile is updated
          const userObj: User = {
            id: newSession.user.id,
            email: newSession.user.email || "",
            name:
              newSession.user.user_metadata?.name ||
              profileData?.full_name ||
              newSession.user.email?.split("@")[0] ||
              "User",
            avatar_url: profileData?.avatar_url || newSession.user.user_metadata?.avatar_url,
            role: profileData?.role || "user", // Default to user role if not specified
            department: profileData?.department,
            created_at: profileData?.created_at,
          }

          setUser(userObj)
        } catch (error) {
          console.error("Error updating user profile:", error)
        }
      }
    })

    initAuth()

    // Cleanup function
    return () => {
      subscription.unsubscribe()
    }
  }, [router, redirectUrl])

  // Sign in function
  const signIn = async (email: string, password: string) => {
    try {
      setIsLoading(true)

      // Use try-catch to handle any errors from Supabase
      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        })

        if (error) {
          console.error("Supabase sign in error:", error)
          return {
            success: false,
            error: error.message || "Invalid email or password. Please try again.",
          }
        }

        // Success - the auth state listener will handle updating the user state
        toast({
          title: "Welcome back!",
          description: "You have successfully signed in.",
        })

        return { success: true }
      } catch (supabaseError) {
        console.error("Unexpected Supabase error:", supabaseError)
        return {
          success: false,
          error: "An unexpected error occurred. Please try again.",
        }
      }
    } catch (error: any) {
      console.error("Sign in function error:", error)
      return {
        success: false,
        error: error.message || "An unexpected error occurred. Please try again.",
      }
    } finally {
      setIsLoading(false)
    }
  }

  // Sign up function with role parameter
  const signUp = async (email: string, password: string, name: string, role = "user") => {
    try {
      // First create the user in Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: name,
            role,
          },
        },
      })

      if (authError) {
        console.error("Error during sign up:", authError)
        return { success: false, error: authError.message }
      }

      if (!authData.user) {
        return { success: false, error: "User creation failed" }
      }

      // Now create a profile entry in the profiles table
      const { error: profileError } = await supabase.from("profiles").insert([
        {
          user_id: authData.user.id,
          full_name: name,
          email: email,
          role: role,
          department: "", // This can be updated later if needed
          avatar_url: "", // Default empty avatar
          created_at: new Date().toISOString(),
        },
      ])

      if (profileError) {
        console.error("Error creating user profile:", profileError)
        // Even if profile creation fails, the user was created, so we should inform the user
        return {
          success: true,
          warning: "Account created but profile setup encountered an issue. Some features may be limited.",
        }
      }

      return { success: true }
    } catch (error: any) {
      console.error("Exception during sign up:", error)
      return { success: false, error: error.message || "An unexpected error occurred" }
    }
  }

  // Sign out function
  const signOut = async () => {
    try {
      setIsLoading(true)
      const { error } = await supabase.auth.signOut()

      if (error) {
        console.error("Sign out error:", error)
        toast({
          title: "Error",
          description: "Failed to sign out. Please try again.",
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Signed out",
        description: "You have been signed out successfully.",
      })

      router.push("/login")
    } catch (error) {
      console.error("Sign out error:", error)
      toast({
        title: "Error",
        description: "Failed to sign out. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Reset password function
  const resetPassword = async (email: string) => {
    try {
      setIsLoading(true)
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      })

      if (error) {
        console.error("Reset password error:", error)
        return {
          success: false,
          error: error.message || "Failed to send password reset email. Please try again.",
        }
      }

      toast({
        title: "Password reset email sent",
        description: "Check your email for a link to reset your password.",
      })

      return { success: true }
    } catch (error: any) {
      console.error("Reset password error:", error)
      return {
        success: false,
        error: error.message || "Failed to send password reset email. Please try again.",
      }
    } finally {
      setIsLoading(false)
    }
  }

  // Update user profile function
  const updateUserProfile = async (updates: Partial<User>) => {
    try {
      setIsLoading(true)

      // Update user metadata in auth
      const { data, error } = await supabase.auth.updateUser({
        data: {
          name: updates.name,
        },
      })

      if (error) {
        console.error("Update user profile error:", error)
        return {
          success: false,
          error: error.message || "Failed to update profile. Please try again.",
        }
      }

      // Update profile in profiles table
      if (user) {
        const { error: profileError } = await supabase
          .from("profiles")
          .update({
            full_name: updates.name,
            role: updates.role,
            department: updates.department,
            updated_at: new Date().toISOString(),
          })
          .eq("user_id", user.id)

        if (profileError) {
          console.error("Update profile error:", profileError)
          return {
            success: false,
            error: profileError.message || "Failed to update profile. Please try again.",
          }
        }

        // Update local user state
        setUser({
          ...user,
          ...updates,
        })
      }

      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      })

      return { success: true }
    } catch (error: any) {
      console.error("Update user profile error:", error)
      return {
        success: false,
        error: error.message || "Failed to update profile. Please try again.",
      }
    } finally {
      setIsLoading(false)
    }
  }

  const value = {
    user,
    session,
    isLoading,
    isInitialized,
    isAuthenticated: !!user,
    isAdmin: user?.role === "admin",
    isManager: user?.role === "manager",
    signIn,
    signUp,
    signOut,
    resetPassword,
    updateUserProfile,
    redirectUrl,
    setRedirectUrl,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}
