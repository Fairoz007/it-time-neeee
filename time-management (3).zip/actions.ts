"use server"

import { revalidatePath } from "next/cache"
import { supabase } from "@/lib/supabase-client"
import { toast } from "sonner"

export async function addComment(taskId: string, content: string) {
  const { data, error } = await supabase
    .from("comments")
    .insert([
      {
        task_id: taskId,
        content: content,
        user_id: "current-user", // Replace with actual user ID
      },
    ])
    .select()

  if (error) {
    console.error("Error adding comment:", error)
    toast({
      title: "Error",
      description: "Failed to add comment. Please try again.",
      variant: "destructive",
    })
    return
  }

  revalidatePath(`/tasks/${taskId}`)
  toast({
    title: "Comment added",
    description: "Your comment has been added successfully.",
  })
}

export async function editComment(commentId: string, content: string) {
  const { data, error } = await supabase.from("comments").update({ content }).eq("id", commentId).select()

  if (error) {
    console.error("Error editing comment:", error)
    toast({
      title: "Error",
      description: "Failed to edit comment. Please try again.",
      variant: "destructive",
    })
    return
  }

  revalidatePath(`/tasks/${commentId}`)
  toast({
    title: "Comment edited",
    description: "Your comment has been edited successfully.",
  })
}

export async function deleteComment(commentId: string) {
  const { data, error } = await supabase.from("comments").delete().eq("id", commentId)

  if (error) {
    console.error("Error deleting comment:", error)
    toast({
      title: "Error",
      description: "Failed to delete comment. Please try again.",
      variant: "destructive",
    })
    return
  }

  revalidatePath(`/tasks/${commentId}`)
  toast({
    title: "Comment deleted",
    description: "Your comment has been deleted successfully.",
  })
}

export async function toggleLike(commentId: string) {
  // Implement like toggle logic here
  console.log("Toggling like for comment:", commentId)
  revalidatePath(`/tasks/${commentId}`)
}
