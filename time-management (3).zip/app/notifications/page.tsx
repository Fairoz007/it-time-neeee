"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Bell, Check, Clock, AlertCircle, Search, Filter, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

type NotificationType = "task" | "deadline" | "mention" | "system"

interface Notification {
  id: string
  type: NotificationType
  title: string
  message: string
  time: string
  read: boolean
  actionUrl?: string
}

// Mock notifications - in a real app, these would come from an API
const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "deadline",
    title: "Upcoming Deadline",
    message: 'The "Fix authentication bug" task is due in 3 hours',
    time: "3 hours ago",
    read: false,
    actionUrl: "/tasks/1",
  },
  {
    id: "2",
    type: "task",
    title: "New Task Assigned",
    message: 'You have been assigned to "Review pull request #42"',
    time: "5 hours ago",
    read: false,
    actionUrl: "/tasks/2",
  },
  {
    id: "3",
    type: "mention",
    title: "Mentioned in Comment",
    message: 'John Doe mentioned you in a comment on "API Integration"',
    time: "1 day ago",
    read: true,
    actionUrl: "/projects/1",
  },
  {
    id: "4",
    type: "system",
    title: "System Maintenance",
    message: "The system will be down for maintenance on Sunday, 2AM-4AM",
    time: "2 days ago",
    read: true,
  },
  {
    id: "5",
    type: "task",
    title: "Task Completed",
    message: 'The task "Update API documentation" has been marked as completed',
    time: "3 days ago",
    read: true,
    actionUrl: "/tasks/5",
  },
  {
    id: "6",
    type: "mention",
    title: "Mentioned in Project",
    message: 'Sarah mentioned you in the "Frontend Development" project',
    time: "4 days ago",
    read: true,
    actionUrl: "/projects/2",
  },
  {
    id: "7",
    type: "system",
    title: "Account Security",
    message: "Your account password was changed successfully",
    time: "1 week ago",
    read: true,
  },
  {
    id: "8",
    type: "deadline",
    title: "Project Deadline",
    message: 'The "API Integration" project is due in 2 days',
    time: "1 week ago",
    read: true,
    actionUrl: "/projects/1",
  },
]

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications)
  const [activeTab, setActiveTab] = useState<"all" | "unread" | "read">("all")
  const [searchQuery, setSearchQuery] = useState("")

  // Mark notification as read
  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((notification) => (notification.id === id ? { ...notification, read: true } : notification)),
    )
  }

  // Mark all notifications as read
  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((notification) => ({ ...notification, read: true })))
  }

  // Filter notifications based on active tab and search query
  const filteredNotifications = notifications.filter((notification) => {
    // Filter by tab
    if (activeTab === "unread" && notification.read) return false
    if (activeTab === "read" && !notification.read) return false

    // Filter by search query
    if (
      searchQuery &&
      !notification.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !notification.message.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    return true
  })

  // Get icon based on notification type
  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case "task":
        return <Check className="h-4 w-4" />
      case "deadline":
        return <Clock className="h-4 w-4" />
      case "mention":
        return <AlertCircle className="h-4 w-4" />
      case "system":
        return <Bell className="h-4 w-4" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  // Get background color based on notification type
  const getNotificationColor = (type: NotificationType) => {
    switch (type) {
      case "task":
        return "bg-green-100 text-green-700"
      case "deadline":
        return "bg-red-100 text-red-700"
      case "mention":
        return "bg-blue-100 text-blue-700"
      case "system":
        return "bg-amber-100 text-amber-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  return (
    <div className="flex-1 space-y-4 p-0 md:px-6 pt-6">
      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/dashboard">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
        <h2 className="text-3xl font-bold tracking-tight">Notifications</h2>
        <div className="flex flex-col space-y-2 md:flex-row md:items-center md:space-x-2 md:space-y-0">
          <div className="relative w-full md:w-[300px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search notifications..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8"
            />
          </div>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button onClick={markAllAsRead} disabled={!notifications.some((n) => !n.read)}>
            Mark All as Read
          </Button>
        </div>
      </div>

      <Tabs
        defaultValue="all"
        value={activeTab}
        onValueChange={(value) => setActiveTab(value as any)}
        className="space-y-4"
      >
        <TabsList>
          <TabsTrigger value="all">All Notifications</TabsTrigger>
          <TabsTrigger value="unread">Unread</TabsTrigger>
          <TabsTrigger value="read">Read</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>
                {activeTab === "all" && "All Notifications"}
                {activeTab === "unread" && "Unread Notifications"}
                {activeTab === "read" && "Read Notifications"}
              </CardTitle>
              <CardDescription>
                {filteredNotifications.length} {filteredNotifications.length === 1 ? "notification" : "notifications"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {filteredNotifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-6">
                  <Bell className="mb-2 h-10 w-10 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">No notifications found</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={cn(
                        "flex items-start gap-4 rounded-lg border p-4 transition-colors hover:bg-muted/50",
                        !notification.read && "bg-muted/30",
                      )}
                    >
                      <div
                        className={cn(
                          "mt-1 flex h-10 w-10 items-center justify-center rounded-full",
                          getNotificationColor(notification.type),
                        )}
                      >
                        {getNotificationIcon(notification.type)}
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-medium">{notification.title}</h3>
                            {!notification.read && (
                              <Badge variant="outline" className="h-auto py-0 text-xs">
                                New
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground">{notification.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{notification.message}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {notification.actionUrl && (
                          <Button variant="outline" size="sm" asChild>
                            <Link href={notification.actionUrl}>View</Link>
                          </Button>
                        )}
                        {!notification.read && (
                          <Button size="sm" onClick={() => markAsRead(notification.id)}>
                            Mark as Read
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
