import { LoadingSpinner } from "@/components/loading-spinner"

export default function Loading() {
  return (
    <div className="flex-1 flex items-center justify-center p-8">
      <div className="text-center">
        <LoadingSpinner className="mx-auto mb-4" />
        <h3 className="text-lg font-medium">Loading notifications...</h3>
        <p className="text-sm text-muted-foreground">Please wait while we fetch your notifications</p>
      </div>
    </div>
  )
}
