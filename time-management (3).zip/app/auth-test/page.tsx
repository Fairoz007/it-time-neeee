"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/contexts/auth-context"
import { ProtectedRoute } from "@/components/protected-route"
import { SharedLayout } from "@/components/shared-layout"

export default function AuthTestPage() {
  const { user, session } = useAuth()
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <ProtectedRoute>
      <SharedLayout>
        <div className="container py-8">
          <Card>
            <CardHeader>
              <CardTitle>Authentication Test Page</CardTitle>
              <CardDescription>This page is protected and requires authentication</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">User Information</h3>
                  <pre className="mt-2 rounded-md bg-muted p-4 overflow-auto">
                    {JSON.stringify({ user, session }, null, 2)}
                  </pre>
                </div>
                <div>
                  <h3 className="text-lg font-medium">Current Time</h3>
                  <p className="mt-2">{currentTime}</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <p className="text-sm text-muted-foreground">
                If you can see this page, you are successfully authenticated.
              </p>
            </CardFooter>
          </Card>
        </div>
      </SharedLayout>
    </ProtectedRoute>
  )
}
