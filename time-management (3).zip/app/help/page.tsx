"use client"

import { useState } from "react"
import { SharedLayout } from "@/components/shared-layout"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import {
  Search,
  HelpCircle,
  Book,
  MessageCircle,
  FileText,
  ArrowRight,
  Mail,
  Phone,
  ExternalLink,
  Clock,
  BarChart2,
  GitMerge,
  CreditCard,
  Users,
  Zap,
} from "lucide-react"
import Link from "next/link"

// Mock FAQ data
const faqData = [
  {
    question: "How do I start tracking time?",
    answer:
      'To start tracking time, click the "Start Time Tracking" button in the header. You can also start tracking time directly from a task by clicking the "Start" button on the task card or detail page.',
  },
  {
    question: "How do I create a new project?",
    answer:
      'To create a new project, go to the Projects page and click the "Create Project" button. Fill in the project details in the form and click "Save Project" to create it.',
  },
  {
    question: "How do I invite team members?",
    answer:
      'To invite team members, click on the "Team" button in the header, then click "Invite New Member". Enter their email address and select their role, then click "Send Invitation".',
  },
  {
    question: "How do I generate reports?",
    answer:
      'To generate reports, go to the Reports page and select the type of report you want to create. Choose your filters and date range, then click "Generate Report". You can export the report in various formats.',
  },
  {
    question: "How do I set up integrations?",
    answer:
      "To set up integrations, go to the Integrations page and click on the integration you want to set up. Follow the instructions to connect your account and configure the integration settings.",
  },
  {
    question: "How do I track time for a specific task?",
    answer:
      'To track time for a specific task, go to the task detail page and click the "Start Timer" button. You can also add time entries manually by clicking "Add Time Entry" and filling in the details.',
  },
  {
    question: "How do I export my data?",
    answer:
      'To export your data, go to the Reports page and select the data you want to export. Click the "Export" button and choose your preferred format (CSV, Excel, PDF).',
  },
  {
    question: "How do I change my password?",
    answer:
      'To change your password, go to your Profile Settings, click on the "Security" tab, and select "Change Password". Enter your current password and your new password, then click "Update Password".',
  },
]

// Mock documentation categories
const documentationCategories = [
  {
    title: "Getting Started",
    icon: <Book className="h-5 w-5" />,
    description: "Learn the basics of DevTimeTracker",
    articles: [
      { title: "Introduction to DevTimeTracker", url: "#" },
      { title: "Setting Up Your Account", url: "#" },
      { title: "Creating Your First Project", url: "#" },
      { title: "Inviting Team Members", url: "#" },
      { title: "Basic Time Tracking", url: "#" },
    ],
  },
  {
    title: "Projects & Tasks",
    icon: <FileText className="h-5 w-5" />,
    description: "Manage your work efficiently",
    articles: [
      { title: "Creating and Managing Projects", url: "#" },
      { title: "Task Management", url: "#" },
      { title: "Task Dependencies", url: "#" },
      { title: "Project Templates", url: "#" },
      { title: "Project Permissions", url: "#" },
    ],
  },
  {
    title: "Time Tracking",
    icon: <Clock className="h-5 w-5" />,
    description: "Track time accurately",
    articles: [
      { title: "Manual Time Entries", url: "#" },
      { title: "Automatic Time Tracking", url: "#" },
      { title: "Timer Controls", url: "#" },
      { title: "Idle Time Detection", url: "#" },
      { title: "Time Tracking Best Practices", url: "#" },
    ],
  },
  {
    title: "Reports & Analytics",
    icon: <BarChart2 className="h-5 w-5" />,
    description: "Gain insights from your data",
    articles: [
      { title: "Creating Custom Reports", url: "#" },
      { title: "Understanding Analytics", url: "#" },
      { title: "Exporting Data", url: "#" },
      { title: "Scheduled Reports", url: "#" },
      { title: "Team Performance Metrics", url: "#" },
    ],
  },
  {
    title: "Integrations",
    icon: <GitMerge className="h-5 w-5" />,
    description: "Connect with other tools",
    articles: [
      { title: "Available Integrations", url: "#" },
      { title: "Setting Up GitHub Integration", url: "#" },
      { title: "Setting Up Slack Integration", url: "#" },
      { title: "Setting Up Jira Integration", url: "#" },
      { title: "Using the API", url: "#" },
    ],
  },
  {
    title: "Account & Billing",
    icon: <CreditCard className="h-5 w-5" />,
    description: "Manage your subscription",
    articles: [
      { title: "Subscription Plans", url: "#" },
      { title: "Billing Information", url: "#" },
      { title: "Payment Methods", url: "#" },
      { title: "Invoices & Receipts", url: "#" },
      { title: "Account Settings", url: "#" },
    ],
  },
]

export default function HelpPage() {
  const [searchQuery, setSearchQuery] = useState("")

  // Filter FAQs based on search query
  const filteredFaqs = searchQuery
    ? faqData.filter(
        (faq) =>
          faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          faq.answer.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : faqData

  return (
    <SharedLayout>
      <div className="container py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">How Can We Help You?</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions, browse our documentation, or contact our support team.
          </p>

          <div className="relative max-w-2xl mx-auto mt-6">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search for help articles, FAQs, or topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
        </div>

        <Tabs defaultValue="faq" className="space-y-8">
          <TabsList className="w-full max-w-2xl mx-auto grid grid-cols-3">
            <TabsTrigger value="faq" className="flex flex-col items-center py-2">
              <HelpCircle className="h-5 w-5 mb-1" />
              FAQs
            </TabsTrigger>
            <TabsTrigger value="documentation" className="flex flex-col items-center py-2">
              <Book className="h-5 w-5 mb-1" />
              Documentation
            </TabsTrigger>
            <TabsTrigger value="contact" className="flex flex-col items-center py-2">
              <MessageCircle className="h-5 w-5 mb-1" />
              Contact Support
            </TabsTrigger>
          </TabsList>

          <TabsContent value="faq" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
                <CardDescription>Find quick answers to common questions about DevTimeTracker</CardDescription>
              </CardHeader>
              <CardContent>
                {filteredFaqs.length === 0 ? (
                  <div className="text-center py-8">
                    <HelpCircle className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
                    <p className="mt-2 text-muted-foreground">No FAQs found matching your search</p>
                    <Button variant="outline" size="sm" className="mt-4" onClick={() => setSearchQuery("")}>
                      Clear search
                    </Button>
                  </div>
                ) : (
                  <Accordion type="single" collapsible className="w-full">
                    {filteredFaqs.map((faq, index) => (
                      <AccordionItem key={index} value={`item-${index}`}>
                        <AccordionTrigger>{faq.question}</AccordionTrigger>
                        <AccordionContent>{faq.answer}</AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <p className="text-sm text-muted-foreground">Can't find what you're looking for?</p>
                <Button variant="outline" asChild>
                  <Link href="#contact">
                    Contact Support
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="documentation" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {documentationCategories.map((category, index) => (
                <Card key={index} className="overflow-hidden transition-all hover:shadow-md">
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <div className="rounded-full bg-primary/10 p-2">{category.icon}</div>
                      <CardTitle>{category.title}</CardTitle>
                    </div>
                    <CardDescription>{category.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {category.articles.map((article, articleIndex) => (
                        <li key={articleIndex}>
                          <Link href={article.url} className="text-sm hover:underline flex items-center">
                            <FileText className="mr-2 h-4 w-4 text-muted-foreground" />
                            {article.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full" asChild>
                      <Link href="#">
                        View All {category.title} Articles
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="contact" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Support</CardTitle>
                  <CardDescription>Get in touch with our support team for personalized assistance</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <Mail className="h-5 w-5 mt-0.5 text-primary" />
                    <div>
                      <h3 className="font-medium">Email Support</h3>
                      <p className="text-muted-foreground">For general inquiries and non-urgent issues</p>
                      <a href="mailto:support@devtimetracker.com" className="text-primary hover:underline">
                        support@devtimetracker.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Phone className="h-5 w-5 mt-0.5 text-primary" />
                    <div>
                      <h3 className="font-medium">Phone Support</h3>
                      <p className="text-muted-foreground">For urgent issues and live assistance</p>
                      <a href="tel:+15551234567" className="text-primary hover:underline">
                        +1 (555) 123-4567
                      </a>
                      <p className="text-xs text-muted-foreground mt-1">Available Monday-Friday, 9AM-6PM PST</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <MessageCircle className="h-5 w-5 mt-0.5 text-primary" />
                    <div>
                      <h3 className="font-medium">Live Chat</h3>
                      <p className="text-muted-foreground">Chat with our support team in real-time</p>
                      <Button variant="outline" size="sm" className="mt-1">
                        Start Live Chat
                      </Button>
                      <p className="text-xs text-muted-foreground mt-1">Typically replies within 5 minutes</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full" asChild>
                    <Link href="/contact">
                      Contact Form
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Additional Resources</CardTitle>
                  <CardDescription>Explore more ways to get help and learn about DevTimeTracker</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-lg border p-4 transition-colors hover:bg-muted/50">
                    <div className="flex items-center space-x-2">
                      <Book className="h-5 w-5 text-primary" />
                      <h3 className="font-medium">Knowledge Base</h3>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Browse our comprehensive knowledge base with detailed articles and guides
                    </p>
                    <Button variant="link" size="sm" className="mt-2 px-0" asChild>
                      <Link href="#">
                        Browse Knowledge Base
                        <ExternalLink className="ml-1 h-3 w-3" />
                      </Link>
                    </Button>
                  </div>

                  <div className="rounded-lg border p-4 transition-colors hover:bg-muted/50">
                    <div className="flex items-center space-x-2">
                      <Users className="h-5 w-5 text-primary" />
                      <h3 className="font-medium">Community Forum</h3>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Connect with other users, share tips, and get help from the community
                    </p>
                    <Button variant="link" size="sm" className="mt-2 px-0" asChild>
                      <Link href="#">
                        Join Community Forum
                        <ExternalLink className="ml-1 h-3 w-3" />
                      </Link>
                    </Button>
                  </div>

                  <div className="rounded-lg border p-4 transition-colors hover:bg-muted/50">
                    <div className="flex items-center space-x-2">
                      <Zap className="h-5 w-5 text-primary" />
                      <h3 className="font-medium">Webinars & Training</h3>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Attend live webinars and training sessions to master DevTimeTracker
                    </p>
                    <Button variant="link" size="sm" className="mt-2 px-0" asChild>
                      <Link href="#">
                        View Upcoming Webinars
                        <ExternalLink className="ml-1 h-3 w-3" />
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </SharedLayout>
  )
}
