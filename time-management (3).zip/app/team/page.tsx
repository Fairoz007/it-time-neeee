"use client"

import { useState, useEffect } from "react"
import { SharedLayout } from "@/components/shared-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { Search, UserPlus, Users, UserCircle, Settings, Trash2, Edit, MoreHorizontal } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Supabase
import { supabase } from "@/lib/supabase-client"

// Types
interface User {
  id: string
  name: string
  email: string
  role: string
  avatar_url?: string
  department?: string
  created_at: string
}

interface UserGroup {
  id: string
  name: string
  description: string
  members: string[] // User IDs
  created_at: string
  created_by: string
}

export default function TeamPage() {
  const [activeTab, setActiveTab] = useState("members")
  const [users, setUsers] = useState<User[]>([])
  const [groups, setGroups] = useState<UserGroup[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  // New user/group dialog states
  const [isNewUserDialogOpen, setIsNewUserDialogOpen] = useState(false)
  const [isNewGroupDialogOpen, setIsNewGroupDialogOpen] = useState(false)
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    role: "member",
    department: "",
  })
  const [newGroup, setNewGroup] = useState({
    name: "",
    description: "",
    members: [] as string[],
  })

  // Load users and groups
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        // First, let's get all columns to see what's available
        const { data: profilesData, error: profilesError } = await supabase
          .from("profiles")
          .select("*")
          .order("created_at")
          .limit(100)

        if (profilesError) {
          throw profilesError
        }

        // Log the first profile to see its structure (helpful for debugging)
        if (profilesData && profilesData.length > 0) {
          console.log("Profile structure:", profilesData[0])
        }

        // Map the profiles data to the User interface using available fields
        const mappedUsers = (profilesData || []).map((profile) => {
          // Extract name from available fields - try different possible column names
          const name =
            profile.name ||
            profile.user_name ||
            profile.username ||
            (profile.user_id ? `User ${profile.user_id.substring(0, 6)}` : "Unknown User")

          return {
            id: profile.id || profile.user_id || `user-${Math.random().toString(36).substring(2, 9)}`,
            name: name,
            email: profile.email || "user@example.com", // Fallback to user_id if email not available
            role: profile.role || profile.job_title || "member",
            avatar_url: profile.avatar_url,
            department: profile.department,
            created_at: profile.created_at || new Date().toISOString(),
          }
        })

        setUsers(mappedUsers)

        // Mock groups
        const mockGroups: UserGroup[] = [
          {
            id: "group-1",
            name: "Engineering Team",
            description: "All engineering team members",
            members: mappedUsers.slice(0, 2).map((u) => u.id),
            created_at: new Date().toISOString(),
            created_by: mappedUsers[0]?.id || "user-1",
          },
          {
            id: "group-2",
            name: "Design Team",
            description: "All design team members",
            members: mappedUsers.slice(2, 3).map((u) => u.id),
            created_at: new Date().toISOString(),
            created_by: mappedUsers[0]?.id || "user-1",
          },
          {
            id: "group-3",
            name: "Project Alpha",
            description: "Members working on Project Alpha",
            members: mappedUsers.slice(0, 3).map((u) => u.id),
            created_at: new Date().toISOString(),
            created_by: mappedUsers[0]?.id || "user-1",
          },
        ]

        setGroups(mockGroups)
      } catch (error) {
        console.error("Error fetching team data:", error)
        toast({
          title: "Error",
          description: "Failed to load team data. Using mock data instead.",
          variant: "destructive",
        })

        // Provide mock data as fallback
        const mockUsers: User[] = [
          {
            id: "user-1",
            name: "John Doe",
            email: "john@example.com",
            role: "admin",
            avatar_url: "/green-tractor-field.png",
            department: "Engineering",
            created_at: new Date().toISOString(),
          },
          {
            id: "user-2",
            name: "Jane Smith",
            email: "jane@example.com",
            role: "member",
            avatar_url: "/javascript-code-abstract.png",
            department: "Design",
            created_at: new Date().toISOString(),
          },
          {
            id: "user-3",
            name: "Alex Johnson",
            email: "alex@example.com",
            role: "member",
            avatar_url: "/abstract-aj.png",
            department: "Engineering",
            created_at: new Date().toISOString(),
          },
        ]

        setUsers(mockUsers)

        const mockGroups: UserGroup[] = [
          {
            id: "group-1",
            name: "Engineering Team",
            description: "All engineering team members",
            members: ["user-1", "user-3"],
            created_at: new Date().toISOString(),
            created_by: "user-1",
          },
          {
            id: "group-2",
            name: "Design Team",
            description: "All design team members",
            members: ["user-2"],
            created_at: new Date().toISOString(),
            created_by: "user-1",
          },
        ]

        setGroups(mockGroups)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Filter users based on search query
  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.department?.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Filter groups based on search query
  const filteredGroups = groups.filter(
    (group) =>
      group.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      group.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Handle creating a new user
  const handleCreateUser = async () => {
    if (!newUser.name || !newUser.email) return

    try {
      // In a real app, this would be an API call to create the user
      const newUserId = `user-${users.length + 1}`
      const createdUser: User = {
        id: newUserId,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        department: newUser.department,
        avatar_url: `/placeholder.svg?height=40&width=40&query=${newUser.name.substring(0, 2)}`,
        created_at: new Date().toISOString(),
      }

      setUsers([...users, createdUser])
      setIsNewUserDialogOpen(false)
      setNewUser({
        name: "",
        email: "",
        role: "member",
        department: "",
      })

      toast({
        title: "User created",
        description: `${newUser.name} has been added to the team.`,
      })
    } catch (error) {
      console.error("Error creating user:", error)
      toast({
        title: "Error",
        description: "Failed to create user. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Handle creating a new group
  const handleCreateGroup = async () => {
    if (!newGroup.name) return

    try {
      // In a real app, this would be an API call to create the group
      const newGroupId = `group-${groups.length + 1}`
      const createdGroup: UserGroup = {
        id: newGroupId,
        name: newGroup.name,
        description: newGroup.description,
        members: newGroup.members,
        created_at: new Date().toISOString(),
        created_by: "user-1", // Current user ID in a real app
      }

      setGroups([...groups, createdGroup])
      setIsNewGroupDialogOpen(false)
      setNewGroup({
        name: "",
        description: "",
        members: [],
      })

      toast({
        title: "Group created",
        description: `${newGroup.name} group has been created.`,
      })
    } catch (error) {
      console.error("Error creating group:", error)
      toast({
        title: "Error",
        description: "Failed to create group. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Get user by ID
  const getUserById = (userId: string) => {
    return users.find((user) => user.id === userId)
  }

  // Get user name by ID
  const getUserNameById = (userId: string) => {
    const user = getUserById(userId)
    return user ? user.name : "Unknown User"
  }

  // Get user initials
  const getUserInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  // Define profile here to avoid the error
  const profile = {
    email: "john@example.com", // Provide a default value or fetch it as needed
  }

  return (
    <SharedLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Team Management</h1>
            <p className="text-muted-foreground">Manage team members and groups for task assignments</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => setIsNewUserDialogOpen(true)}>
              <UserPlus className="mr-2 h-4 w-4" />
              Add User
            </Button>
            <Button variant="outline" onClick={() => setIsNewGroupDialogOpen(true)}>
              <Users className="mr-2 h-4 w-4" />
              Create Group
            </Button>
          </div>
        </div>

        <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-x-4 md:space-y-0">
          <div className="relative w-full md:w-[300px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search team members or groups..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8"
            />
          </div>
        </div>

        <Tabs defaultValue="members" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="members">Team Members</TabsTrigger>
            <TabsTrigger value="groups">Groups</TabsTrigger>
          </TabsList>

          <TabsContent value="members" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Team Members</CardTitle>
                <CardDescription>Manage individual team members and their roles</CardDescription>
              </CardHeader>
              <CardContent>
                {filteredUsers.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <UserCircle className="mx-auto h-12 w-12 opacity-50 mb-2" />
                    <p>No team members found</p>
                    {searchQuery && (
                      <Button variant="link" onClick={() => setSearchQuery("")}>
                        Clear search
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <div className="grid grid-cols-5 border-b bg-muted/50 p-3 text-sm font-medium">
                      <div>Name</div>
                      <div>Email</div>
                      <div>Role</div>
                      <div>Department</div>
                      <div className="text-right">Actions</div>
                    </div>
                    {filteredUsers.map((user) => (
                      <div key={user.id} className="grid grid-cols-5 border-b p-3 text-sm hover:bg-muted/50">
                        <div className="flex items-center space-x-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={user.avatar_url || "/placeholder.svg"} alt={user.name} />
                            <AvatarFallback>{getUserInitials(user.name)}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{user.name}</span>
                        </div>
                        <div className="flex items-center">{user.email}</div>
                        <div className="flex items-center">
                          <Badge variant={user.role === "admin" ? "default" : "outline"}>
                            {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                          </Badge>
                        </div>
                        <div className="flex items-center">{user.department || "—"}</div>
                        <div className="flex items-center justify-end">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit User
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Settings className="mr-2 h-4 w-4" />
                                Manage Permissions
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Remove User
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="groups" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User Groups</CardTitle>
                <CardDescription>Manage groups for batch task assignments</CardDescription>
              </CardHeader>
              <CardContent>
                {filteredGroups.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="mx-auto h-12 w-12 opacity-50 mb-2" />
                    <p>No groups found</p>
                    {searchQuery && (
                      <Button variant="link" onClick={() => setSearchQuery("")}>
                        Clear search
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {filteredGroups.map((group) => (
                      <Card key={group.id} className="overflow-hidden">
                        <CardHeader className="pb-3">
                          <CardTitle>{group.name}</CardTitle>
                          <CardDescription>{group.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="pb-3">
                          <div className="space-y-2">
                            <h4 className="text-sm font-medium">Members ({group.members.length})</h4>
                            <div className="flex -space-x-2">
                              {group.members.slice(0, 5).map((memberId) => {
                                const user = getUserById(memberId)
                                return (
                                  <Avatar key={memberId} className="border-2 border-background h-8 w-8">
                                    <AvatarImage src={user?.avatar_url || "/placeholder.svg"} alt={user?.name} />
                                    <AvatarFallback>{user ? getUserInitials(user.name) : "??"}</AvatarFallback>
                                  </Avatar>
                                )
                              })}
                              {group.members.length > 5 && (
                                <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-background bg-muted text-xs font-medium">
                                  +{group.members.length - 5}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="flex justify-between">
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit Group
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <UserPlus className="mr-2 h-4 w-4" />
                                Add Members
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete Group
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add User Dialog */}
        <Dialog open={isNewUserDialogOpen} onOpenChange={setIsNewUserDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Add Team Member</DialogTitle>
              <DialogDescription>Add a new user to your team</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="name" className="text-sm font-medium">
                  Full Name
                </label>
                <Input
                  id="name"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  placeholder="John Doe"
                />
              </div>

              <div className="grid gap-2">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  placeholder={profile.email || "john@example.com"}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="role" className="text-sm font-medium">
                    Role
                  </label>
                  <Select value={newUser.role} onValueChange={(value) => setNewUser({ ...newUser, role: value })}>
                    <SelectTrigger id="role">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="member">Member</SelectItem>
                      <SelectItem value="manager">Manager</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <label htmlFor="department" className="text-sm font-medium">
                    Department
                  </label>
                  <Select
                    value={newUser.department}
                    onChange={(e) => setNewUser({ ...newUser, department: e.target.value })}
                  >
                    <SelectTrigger id="department">
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Engineering">Engineering</SelectItem>
                      <SelectItem value="Design">Design</SelectItem>
                      <SelectItem value="Product">Product</SelectItem>
                      <SelectItem value="Marketing">Marketing</SelectItem>
                      <SelectItem value="Sales">Sales</SelectItem>
                      <SelectItem value="Support">Support</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsNewUserDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateUser} disabled={!newUser.name || !newUser.email}>
                Add User
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </SharedLayout>
  )
}
