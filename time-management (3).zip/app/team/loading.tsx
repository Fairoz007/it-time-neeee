import { LoadingSpinner } from "@/components/loading-spinner"

export default function Loading() {
  return (
    <div className="flex-1 p-8 flex items-center justify-center">
      <div className="text-center">
        <LoadingSpinner className="mx-auto mb-4" />
        <h3 className="text-lg font-medium">Loading team data...</h3>
        <p className="text-sm text-muted-foreground">Please wait while we fetch the team information</p>
      </div>
    </div>
  )
}
