import { LoadingSpinner } from "@/components/loading-spinner"
import { SharedLayout } from "@/components/shared-layout"

export default function Loading() {
  return (
    <SharedLayout>
      <div className="flex-1 p-8 flex items-center justify-center">
        <div className="text-center">
          <LoadingSpinner className="mx-auto mb-4" />
          <h3 className="text-lg font-medium">Loading profile...</h3>
          <p className="text-sm text-muted-foreground">Please wait while we fetch your profile data</p>
        </div>
      </div>
    </SharedLayout>
  )
}
