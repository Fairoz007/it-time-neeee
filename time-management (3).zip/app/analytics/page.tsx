"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Calendar, Download, BarChart2, PieChart, TrendingUp, Clock, Filter } from "lucide-react"
import { SharedLayout } from "@/components/shared-layout"
import { AnimatedCounter } from "@/components/ui/animated-counter"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import type { DateRange } from "react-day-picker"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart as RePieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Mock data for charts
const productivityData = [
  { day: "Mon", score: 82, hours: 7.5 },
  { day: "Tue", score: 89, hours: 8.2 },
  { day: "Wed", score: 76, hours: 6.8 },
  { day: "Thu", score: 85, hours: 7.9 },
  { day: "Fri", score: 91, hours: 8.5 },
  { day: "Sat", score: 72, hours: 4.2 },
  { day: "Sun", score: 65, hours: 3.5 },
]

const timeAllocationData = [
  { name: "Development", value: 45 },
  { name: "Meetings", value: 20 },
  { name: "Planning", value: 15 },
  { name: "Code Review", value: 10 },
  { name: "Learning", value: 10 },
]

const projectProgressData = [
  { name: "API Integration", completed: 75, remaining: 25 },
  { name: "Frontend Dev", completed: 60, remaining: 40 },
  { name: "Database Migration", completed: 90, remaining: 10 },
  { name: "Testing & QA", completed: 30, remaining: 70 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

export default function AnalyticsPage() {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    to: new Date(),
  })

  return (
    <SharedLayout>
      <div className="flex-1 space-y-4 p-0 md:px-6 pt-6">
        <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
          <h2 className="text-3xl font-bold tracking-tight">Analytics</h2>
          <div className="flex flex-col space-y-2 md:flex-row md:items-center md:space-x-2 md:space-y-0">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="justify-start text-left font-normal md:w-[240px]">
                  <Calendar className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                      </>
                    ) : (
                      format(dateRange.from, "LLL dd, y")
                    )
                  ) : (
                    <span>Pick a date range</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <CalendarComponent
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange?.from}
                  selected={dateRange}
                  onSelect={setDateRange}
                  numberOfMonths={2}
                />
              </PopoverContent>
            </Popover>
            <Button variant="outline">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
            <Button>
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <Tabs defaultValue="productivity" className="space-y-4">
          <TabsList className="w-full sm:w-auto overflow-x-auto">
            <TabsTrigger value="productivity">Productivity</TabsTrigger>
            <TabsTrigger value="time">Time Allocation</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
          </TabsList>

          <TabsContent value="productivity" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Productivity Score</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    <AnimatedCounter value={87} formatter={(value) => `${value}%`} />
                  </div>
                  <p className="text-xs text-muted-foreground">+5% from last week</p>
                </CardContent>
              </Card>
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Focus Time</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    <AnimatedCounter value={24.5} formatter={(value) => `${value.toFixed(1)} hrs`} />
                  </div>
                  <p className="text-xs text-muted-foreground">71% of total time</p>
                </CardContent>
              </Card>
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tasks Completed</CardTitle>
                  <BarChart2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    <AnimatedCounter value={32} />
                  </div>
                  <p className="text-xs text-muted-foreground">+8 from last week</p>
                </CardContent>
              </Card>
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Interruptions</CardTitle>
                  <PieChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    <AnimatedCounter value={15} />
                  </div>
                  <p className="text-xs text-muted-foreground">-3 from last week</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card className="col-span-1 overflow-hidden transition-all hover:shadow-md">
                <CardHeader>
                  <CardTitle>Productivity Trends</CardTitle>
                  <CardDescription>Your productivity score over time</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ChartContainer
                    config={{
                      score: {
                        label: "Productivity Score",
                        color: "hsl(var(--chart-1))",
                      },
                      hours: {
                        label: "Hours Worked",
                        color: "hsl(var(--chart-2))",
                      },
                    }}
                    className="h-full"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={productivityData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="day" />
                        <YAxis yAxisId="left" orientation="left" domain={[0, 100]} />
                        <YAxis yAxisId="right" orientation="right" domain={[0, 10]} />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Legend />
                        <Line
                          yAxisId="left"
                          type="monotone"
                          dataKey="score"
                          stroke="var(--color-score)"
                          activeDot={{ r: 8 }}
                          name="Productivity Score"
                        />
                        <Line
                          yAxisId="right"
                          type="monotone"
                          dataKey="hours"
                          stroke="var(--color-hours)"
                          name="Hours Worked"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>

              <Card className="col-span-1 overflow-hidden transition-all hover:shadow-md">
                <CardHeader>
                  <CardTitle>Work Pattern Analysis</CardTitle>
                  <CardDescription>AI-powered insights into your work habits</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-lg bg-muted p-4 transition-all hover:bg-muted/80">
                      <h4 className="text-sm font-medium mb-2">Peak Productivity Hours</h4>
                      <p className="text-sm text-muted-foreground">
                        Your productivity peaks between 9-11 AM. Schedule complex tasks during this time for optimal
                        results.
                      </p>
                    </div>
                    <div className="rounded-lg bg-muted p-4 transition-all hover:bg-muted/80">
                      <h4 className="text-sm font-medium mb-2">Context Switching</h4>
                      <p className="text-sm text-muted-foreground">
                        You spend approximately 30% of your time context-switching between different tasks and projects.
                        Try batching similar tasks to reduce this overhead.
                      </p>
                    </div>
                    <div className="rounded-lg bg-muted p-4 transition-all hover:bg-muted/80">
                      <h4 className="text-sm font-medium mb-2">Meeting Impact</h4>
                      <p className="text-sm text-muted-foreground">
                        Meetings longer than 45 minutes significantly reduce your productivity for up to 30 minutes
                        afterward. Consider scheduling shorter, more focused meetings.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="time" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="col-span-1 overflow-hidden transition-all hover:shadow-md">
                <CardHeader>
                  <CardTitle>Time Allocation</CardTitle>
                  <CardDescription>How your time is distributed across activities</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={timeAllocationData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {timeAllocationData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                    </RePieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="col-span-1 overflow-hidden transition-all hover:shadow-md">
                <CardHeader>
                  <CardTitle>Project Progress</CardTitle>
                  <CardDescription>Completion status of active projects</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={projectProgressData}
                      layout="vertical"
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 100]} />
                      <YAxis type="category" dataKey="name" width={100} />
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                      <Bar dataKey="completed" stackId="a" fill="#4CAF50" name="Completed" />
                      <Bar dataKey="remaining" stackId="a" fill="#F5F5F5" name="Remaining" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </SharedLayout>
  )
}
