"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Users,
  Search,
  Filter,
  UserPlus,
  MoreHorizontal,
  Edit,
  AlertCircle,
  Mail,
  Clock,
  Calendar,
  CheckCircle,
  BarChart2,
  MessageSquare,
  PlusCircle,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { SharedLayout } from "@/components/shared-layout"
import { ManagerPlus } from "@/components/role-based-access"
import { LoadingSpinner } from "@/components/loading-spinner"
import { supabase } from "@/lib/supabase-client"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import { Textarea } from "@/components/ui/textarea"

export default function ManagementTeamPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [teamMembers, setTeamMembers] = useState<any[]>([])
  const [filteredMembers, setFilteredMembers] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("all")
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false)
  const [isPerformanceDialogOpen, setIsPerformanceDialogOpen] = useState(false)
  const [selectedMember, setSelectedMember] = useState<any>(null)
  const [inviteData, setInviteData] = useState({
    email: "",
    name: "",
    role: "user",
    department: "",
    message: "",
  })

  // Mock performance data
  const performanceData = {
    productivity: 87,
    taskCompletion: 92,
    timeTracked: 38.5,
    projectContribution: 78,
    recentActivity: [
      { date: "2023-05-10", action: "Completed task", target: "Fix authentication bug", status: "completed" },
      { date: "2023-05-09", action: "Started task", target: "Update API documentation", status: "in_progress" },
      { date: "2023-05-08", action: "Commented on", target: "Frontend Development project", status: "comment" },
      { date: "2023-05-07", action: "Created task", target: "Implement user roles", status: "created" },
    ],
  }

  useEffect(() => {
    const fetchTeamMembers = async () => {
      setLoading(true)
      try {
        const { data, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })

        if (error) throw error

        // Add mock performance data
        const membersWithPerformance =
          data?.map((member) => ({
            ...member,
            performance: {
              productivity: Math.floor(Math.random() * 30) + 70, // 70-100
              taskCompletion: Math.floor(Math.random() * 40) + 60, // 60-100
              timeTracked: Math.floor(Math.random() * 40) + 10, // 10-50 hours
              projectContribution: Math.floor(Math.random() * 30) + 70, // 70-100
            },
          })) || []

        setTeamMembers(membersWithPerformance)
        setFilteredMembers(membersWithPerformance)
      } catch (error) {
        console.error("Error fetching team members:", error)
        toast({
          title: "Error",
          description: "Failed to load team members",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchTeamMembers()
  }, [])

  // Filter team members when search query or department filter changes
  useEffect(() => {
    let result = teamMembers

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (member) =>
          (member.full_name && member.full_name.toLowerCase().includes(query)) ||
          (member.email && member.email.toLowerCase().includes(query)) ||
          (member.department && member.department.toLowerCase().includes(query)),
      )
    }

    // Apply department filter
    if (departmentFilter !== "all") {
      result = result.filter((member) => member.department === departmentFilter)
    }

    setFilteredMembers(result)
  }, [searchQuery, departmentFilter, teamMembers])

  // Handle sending invitation
  const handleSendInvite = async () => {
    try {
      // Validate inputs
      if (!inviteData.email || !inviteData.name) {
        toast({
          title: "Validation Error",
          description: "Please fill in all required fields",
          variant: "destructive",
        })
        return
      }

      // In a real app, this would send an invitation email
      // For now, we'll just show a success message
      toast({
        title: "Invitation Sent",
        description: `Invitation sent to ${inviteData.email}`,
      })

      // Reset form and close dialog
      setInviteData({
        email: "",
        name: "",
        role: "user",
        department: "",
        message: "",
      })
      setIsInviteDialogOpen(false)
    } catch (error: any) {
      console.error("Error sending invitation:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to send invitation",
        variant: "destructive",
      })
    }
  }

  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  // Get all unique departments
  const departments = Array.from(new Set(teamMembers.map((member) => member.department).filter(Boolean)))

  return (
    <ManagerPlus
      fallback={
        <div className="flex min-h-screen items-center justify-center">
          <div className="text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <h3 className="text-lg font-medium">Access Denied</h3>
            <p className="text-sm text-muted-foreground mb-4">You need manager permissions to access this page</p>
            <Button variant="outline" onClick={() => router.push("/dashboard")}>
              Back to Dashboard
            </Button>
          </div>
        </div>
      }
    >
      <SharedLayout>
        <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Team Management</h2>
            <div className="flex items-center space-x-2">
              <Button onClick={() => setIsInviteDialogOpen(true)}>
                <UserPlus className="mr-2 h-4 w-4" />
                Invite Team Member
              </Button>
            </div>
          </div>

          <Tabs defaultValue="members" className="space-y-4">
            <TabsList>
              <TabsTrigger value="members">Team Members</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="workload">Workload</TabsTrigger>
            </TabsList>

            <TabsContent value="members">
              <Card>
                <CardHeader>
                  <CardTitle>Team Members</CardTitle>
                  <CardDescription>Manage your team members and their roles</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0 mb-4">
                    <div className="flex flex-col space-y-2 md:flex-row md:items-center md:space-x-2 md:space-y-0">
                      <div className="relative w-full md:w-[300px]">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="Search team members..."
                          className="pl-8"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                      <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                        <SelectTrigger className="w-full md:w-[180px]">
                          <SelectValue placeholder="Filter by department" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Departments</SelectItem>
                          {departments.map((dept) => (
                            <SelectItem key={dept} value={dept}>
                              {dept}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <Filter className="mr-2 h-4 w-4" />
                        Advanced Filters
                      </Button>
                    </div>
                  </div>

                  {loading ? (
                    <div className="flex justify-center py-8">
                      <LoadingSpinner />
                    </div>
                  ) : filteredMembers.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Users className="mx-auto h-12 w-12 opacity-50 mb-2" />
                      <p>No team members found</p>
                      {searchQuery && (
                        <Button variant="link" onClick={() => setSearchQuery("")}>
                          Clear search
                        </Button>
                      )}
                    </div>
                  ) : (
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Team Member</TableHead>
                            <TableHead>Department</TableHead>
                            <TableHead>Role</TableHead>
                            <TableHead>Productivity</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredMembers.map((member) => (
                            <TableRow key={member.id}>
                              <TableCell className="font-medium">
                                <div className="flex items-center">
                                  <Avatar className="h-8 w-8 mr-2">
                                    <AvatarImage src={member.avatar_url || "/placeholder.svg"} alt={member.full_name} />
                                    <AvatarFallback>{getUserInitials(member.full_name)}</AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <div className="font-medium">{member.full_name || "Unnamed User"}</div>
                                    <div className="text-xs text-muted-foreground">{member.email}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>{member.department || "—"}</TableCell>
                              <TableCell>
                                <Badge
                                  variant={
                                    member.role === "admin"
                                      ? "default"
                                      : member.role === "manager"
                                        ? "secondary"
                                        : "outline"
                                  }
                                >
                                  {member.role || "user"}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center">
                                  <div className="w-24 mr-2">
                                    <Progress value={member.performance.productivity} className="h-2" />
                                  </div>
                                  <span className="text-sm">{member.performance.productivity}%</span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge className="bg-green-500">Active</Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      <MoreHorizontal className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                    <DropdownMenuItem
                                      onClick={() => {
                                        setSelectedMember(member)
                                        setIsPerformanceDialogOpen(true)
                                      }}
                                    >
                                      <BarChart2 className="mr-2 h-4 w-4" />
                                      View Performance
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <Edit className="mr-2 h-4 w-4" />
                                      Edit Member
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem>
                                      <Mail className="mr-2 h-4 w-4" />
                                      Send Message
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="performance">
              <Card>
                <CardHeader>
                  <CardTitle>Team Performance</CardTitle>
                  <CardDescription>Overview of your team's performance metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Avg. Productivity</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">
                          {filteredMembers.length > 0
                            ? Math.round(
                                filteredMembers.reduce((acc, member) => acc + member.performance.productivity, 0) /
                                  filteredMembers.length,
                              )
                            : 0}
                          %
                        </div>
                        <Progress
                          value={
                            filteredMembers.length > 0
                              ? Math.round(
                                  filteredMembers.reduce((acc, member) => acc + member.performance.productivity, 0) /
                                    filteredMembers.length,
                                )
                              : 0
                          }
                          className="h-2 mt-2"
                        />
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Task Completion</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">
                          {filteredMembers.length > 0
                            ? Math.round(
                                filteredMembers.reduce((acc, member) => acc + member.performance.taskCompletion, 0) /
                                  filteredMembers.length,
                              )
                            : 0}
                          %
                        </div>
                        <Progress
                          value={
                            filteredMembers.length > 0
                              ? Math.round(
                                  filteredMembers.reduce((acc, member) => acc + member.performance.taskCompletion, 0) /
                                    filteredMembers.length,
                                )
                              : 0
                          }
                          className="h-2 mt-2"
                        />
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Hours Tracked</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">
                          {filteredMembers.length > 0
                            ? filteredMembers.reduce((acc, member) => acc + member.performance.timeTracked, 0)
                            : 0}
                        </div>
                        <p className="text-xs text-muted-foreground">This week</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Project Contribution</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">
                          {filteredMembers.length > 0
                            ? Math.round(
                                filteredMembers.reduce(
                                  (acc, member) => acc + member.performance.projectContribution,
                                  0,
                                ) / filteredMembers.length,
                              )
                            : 0}
                          %
                        </div>
                        <Progress
                          value={
                            filteredMembers.length > 0
                              ? Math.round(
                                  filteredMembers.reduce(
                                    (acc, member) => acc + member.performance.projectContribution,
                                    0,
                                  ) / filteredMembers.length,
                                )
                              : 0
                          }
                          className="h-2 mt-2"
                        />
                      </CardContent>
                    </Card>
                  </div>

                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Team Member</TableHead>
                          <TableHead>Productivity</TableHead>
                          <TableHead>Task Completion</TableHead>
                          <TableHead>Hours Tracked</TableHead>
                          <TableHead>Project Contribution</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredMembers.map((member) => (
                          <TableRow key={member.id}>
                            <TableCell className="font-medium">
                              <div className="flex items-center">
                                <Avatar className="h-8 w-8 mr-2">
                                  <AvatarImage src={member.avatar_url || "/placeholder.svg"} alt={member.full_name} />
                                  <AvatarFallback>{getUserInitials(member.full_name)}</AvatarFallback>
                                </Avatar>
                                <div className="font-medium">{member.full_name || "Unnamed User"}</div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-24 mr-2">
                                  <Progress value={member.performance.productivity} className="h-2" />
                                </div>
                                <span className="text-sm">{member.performance.productivity}%</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-24 mr-2">
                                  <Progress value={member.performance.taskCompletion} className="h-2" />
                                </div>
                                <span className="text-sm">{member.performance.taskCompletion}%</span>
                              </div>
                            </TableCell>
                            <TableCell>{member.performance.timeTracked} hrs</TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-24 mr-2">
                                  <Progress value={member.performance.projectContribution} className="h-2" />
                                </div>
                                <span className="text-sm">{member.performance.projectContribution}%</span>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="workload">
              <Card>
                <CardHeader>
                  <CardTitle>Team Workload</CardTitle>
                  <CardDescription>Current workload distribution across team members</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {filteredMembers.map((member) => (
                      <div key={member.id} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <Avatar className="h-8 w-8 mr-2">
                              <AvatarImage src={member.avatar_url || "/placeholder.svg"} alt={member.full_name} />
                              <AvatarFallback>{getUserInitials(member.full_name)}</AvatarFallback>
                            </Avatar>
                            <span className="font-medium">{member.full_name || "Unnamed User"}</span>
                          </div>
                          <Badge
                            variant={member.performance.taskCompletion > 80 ? "outline" : "secondary"}
                            className={member.performance.taskCompletion > 80 ? "bg-green-100 text-green-800" : ""}
                          >
                            {member.performance.taskCompletion > 80 ? "Optimal" : "High Workload"}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>Workload</span>
                            <span>{100 - member.performance.taskCompletion}%</span>
                          </div>
                          <Progress value={100 - member.performance.taskCompletion} className="h-2" />
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Active Tasks: {Math.floor(Math.random() * 5) + 1}</span>
                            <span>Capacity: {Math.floor(Math.random() * 3) + 3} tasks</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Invite Team Member Dialog */}
        <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Invite Team Member</DialogTitle>
              <DialogDescription>Send an invitation to join your team</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="name" className="text-sm font-medium">
                  Full Name
                </label>
                <Input
                  id="name"
                  value={inviteData.name}
                  onChange={(e) => setInviteData({ ...inviteData, name: e.target.value })}
                  placeholder="John Doe"
                />
              </div>

              <div className="grid gap-2">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  value={inviteData.email}
                  onChange={(e) => setInviteData({ ...inviteData, email: e.target.value })}
                  placeholder="john@example.com"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="role" className="text-sm font-medium">
                    Role
                  </label>
                  <Select
                    value={inviteData.role}
                    onValueChange={(value) => setInviteData({ ...inviteData, role: value })}
                  >
                    <SelectTrigger id="role">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manager">Manager</SelectItem>
                      <SelectItem value="user">User</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <label htmlFor="department" className="text-sm font-medium">
                    Department
                  </label>
                  <Input
                    id="department"
                    value={inviteData.department}
                    onChange={(e) => setInviteData({ ...inviteData, department: e.target.value })}
                    placeholder="Engineering"
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <label htmlFor="message" className="text-sm font-medium">
                  Personal Message (Optional)
                </label>
                <Textarea
                  id="message"
                  value={inviteData.message}
                  onChange={(e) => setInviteData({ ...inviteData, message: e.target.value })}
                  placeholder="I'd like to invite you to join our team..."
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsInviteDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSendInvite}>Send Invitation</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Performance Dialog */}
        <Dialog open={isPerformanceDialogOpen} onOpenChange={setIsPerformanceDialogOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>Performance Details</DialogTitle>
              <DialogDescription>{selectedMember?.full_name}'s performance metrics and activity</DialogDescription>
            </DialogHeader>
            {selectedMember && (
              <div className="py-4">
                <div className="flex items-center space-x-4 mb-6">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={selectedMember.avatar_url || "/placeholder.svg"} alt={selectedMember.full_name} />
                    <AvatarFallback>{getUserInitials(selectedMember.full_name)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-lg font-medium">{selectedMember.full_name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {selectedMember.department || "No Department"} • {selectedMember.role || "User"}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold mb-2">{selectedMember.performance.productivity}%</div>
                        <p className="text-sm text-muted-foreground">Productivity</p>
                        <Progress value={selectedMember.performance.productivity} className="h-2 mt-2" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold mb-2">{selectedMember.performance.taskCompletion}%</div>
                        <p className="text-sm text-muted-foreground">Task Completion</p>
                        <Progress value={selectedMember.performance.taskCompletion} className="h-2 mt-2" />
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <h4 className="text-sm font-medium mb-2">Recent Activity</h4>
                <div className="space-y-3 mb-6">
                  {performanceData.recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="mt-0.5">
                        {activity.status === "completed" ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : activity.status === "in_progress" ? (
                          <Clock className="h-4 w-4 text-blue-500" />
                        ) : activity.status === "comment" ? (
                          <MessageSquare className="h-4 w-4 text-purple-500" />
                        ) : (
                          <PlusCircle className="h-4 w-4 text-gray-500" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm">
                          <span className="font-medium">{activity.action}</span> {activity.target}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(activity.date), "MMM d, yyyy")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <h4 className="text-sm font-medium mb-2">Time Tracked (Last 7 Days)</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Monday</span>
                    </div>
                    <span className="text-sm">{Math.floor(Math.random() * 4) + 4} hrs</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Tuesday</span>
                    </div>
                    <span className="text-sm">{Math.floor(Math.random() * 4) + 4} hrs</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Wednesday</span>
                    </div>
                    <span className="text-sm">{Math.floor(Math.random() * 4) + 4} hrs</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Thursday</span>
                    </div>
                    <span className="text-sm">{Math.floor(Math.random() * 4) + 4} hrs</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Friday</span>
                    </div>
                    <span className="text-sm">{Math.floor(Math.random() * 4) + 4} hrs</span>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsPerformanceDialogOpen(false)}>
                Close
              </Button>
              <Button>View Full Report</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </SharedLayout>
    </ManagerPlus>
  )
}
