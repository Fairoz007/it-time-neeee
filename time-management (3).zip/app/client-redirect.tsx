"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export function ClientRedirect() {
  const router = useRouter()

  useEffect(() => {
    router.push("/dashboard")
  }, [router])

  return null
}
