import { SharedLayout } from "@/components/shared-layout"

export default function AccessibilityPage() {
  return (
    <SharedLayout>
      <div className="container max-w-4xl py-12">
        <h1 className="mb-8 text-4xl font-bold">Accessibility Statement</h1>

        <div className="prose prose-sm dark:prose-invert max-w-none">
          <p className="lead">Last updated: {new Date().toLocaleDateString()}</p>

          <h2>Our Commitment</h2>
          <p>
            DevTimeTracker is committed to ensuring digital accessibility for people with disabilities. We are
            continually improving the user experience for everyone and applying the relevant accessibility standards.
          </p>

          <h2>Conformance Status</h2>
          <p>
            The Web Content Accessibility Guidelines (WCAG) defines requirements for designers and developers to improve
            accessibility for people with disabilities. It defines three levels of conformance: Level A, Level AA, and
            Level AAA. DevTimeTracker is partially conformant with WCAG 2.1 level AA. Partially conformant means that
            some parts of the content do not fully conform to the accessibility standard.
          </p>

          <h2>Accessibility Features</h2>
          <p>DevTimeTracker includes the following accessibility features:</p>
          <ul>
            <li>Keyboard navigation support throughout the application</li>
            <li>Proper heading structure for screen reader navigation</li>
            <li>Sufficient color contrast for text and interactive elements</li>
            <li>Text resizing without loss of content or functionality</li>
            <li>Alternative text for images and meaningful link text</li>
            <li>ARIA landmarks and attributes where appropriate</li>
            <li>Focus indicators for keyboard users</li>
            <li>Dark mode for users with light sensitivity</li>
          </ul>

          <h2>Limitations and Alternatives</h2>
          <p>
            Despite our best efforts to ensure accessibility of DevTimeTracker, there may be some limitations. Below is
            a description of known limitations, and potential solutions:
          </p>
          <ul>
            <li>
              <strong>Charts and Graphs:</strong> Some data visualizations may be difficult to interpret with screen
              readers. We provide data tables as alternatives where possible.
            </li>
            <li>
              <strong>Complex Interactions:</strong> Some advanced features may require fine motor control. We offer
              keyboard shortcuts and alternative workflows for these features.
            </li>
            <li>
              <strong>Third-party Content:</strong> We cannot control the accessibility of external content or
              integrations. We work with our partners to improve accessibility where possible.
            </li>
          </ul>

          <h2>Feedback</h2>
          <p>
            We welcome your feedback on the accessibility of DevTimeTracker. Please let us know if you encounter
            accessibility barriers:
          </p>
          <ul>
            <li>
              Email: <a href="mailto:accessibility@devtimetracker.com">accessibility@devtimetracker.com</a>
            </li>
            <li>Phone: +1 (555) 123-4567</li>
            <li>Feedback form: Available in the Help section of the application</li>
          </ul>

          <h2>Compatibility with Browsers and Assistive Technology</h2>
          <p>DevTimeTracker is designed to be compatible with the following assistive technologies:</p>
          <ul>
            <li>Screen readers (including NVDA, JAWS, VoiceOver, and TalkBack)</li>
            <li>Speech recognition software</li>
            <li>Screen magnification software</li>
            <li>Keyboard-only navigation</li>
          </ul>

          <h2>Technical Specifications</h2>
          <p>
            Accessibility of DevTimeTracker relies on the following technologies to work with the particular combination
            of web browser and any assistive technologies or plugins installed on your computer:
          </p>
          <ul>
            <li>HTML</li>
            <li>WAI-ARIA</li>
            <li>CSS</li>
            <li>JavaScript</li>
          </ul>

          <h2>Assessment Approach</h2>
          <p>DevTimeTracker assessed the accessibility of our application by the following approaches:</p>
          <ul>
            <li>Self-evaluation</li>
            <li>External evaluation by accessibility experts</li>
            <li>User testing with people with disabilities</li>
            <li>Automated testing tools</li>
          </ul>
        </div>
      </div>
    </SharedLayout>
  )
}
