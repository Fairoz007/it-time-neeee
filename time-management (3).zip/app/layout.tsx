import type React from "react"

export const metadata = {
  title: "DevTimeTracker - Time Management for IT Professionals",
  description: "Advanced time management system for IT professionals",
    generator: 'v0.dev'
}

import ClientLayout from "./client-layout"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <ClientLayout>{children}</ClientLayout>
}


import './globals.css'