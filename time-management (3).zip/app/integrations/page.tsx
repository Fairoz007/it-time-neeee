"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Github, Trello, Slack, Calendar, GitMerge, Plus, Settings } from "lucide-react"
import { SharedLayout } from "@/components/shared-layout"
import { useData } from "@/contexts/data-context"
import { LoadingSpinner } from "@/components/loading-spinner"
import type { Integration } from "@/lib/supabase-client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/contexts/auth-context"
import { useToast } from "@/components/ui/use-toast"
import { connectIntegration } from "@/lib/supabase-client"

export default function IntegrationsPage() {
  const { integrations, loading, error, refreshIntegrations } = useData()
  const [isAddIntegrationDialogOpen, setIsAddIntegrationDialogOpen] = useState(false)
  const [isConfigureDialogOpen, setIsConfigureDialogOpen] = useState(false)
  const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null)
  const [newIntegration, setNewIntegration] = useState({
    name: "",
    type: "",
    status: "disconnected" as Integration["status"],
    settings: {},
  })

  const { user } = useAuth()
  const { toast } = useToast()

  const handleAddIntegration = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to add integrations.",
        variant: "destructive",
      })
      setIsAddIntegrationDialogOpen(false)
      return
    }

    try {
      // Prepare integration data with user information
      const integrationData = {
        name: newIntegration.name,
        type: newIntegration.type,
        status: newIntegration.status,
        settings: {
          userId: user.id,
          username: user.name || user.email?.split("@")[0] || "User",
        },
      }

      console.log("Integration data being sent:", integrationData)

      // In a real app, you would call the API to create the integration
      const result = await connectIntegration(integrationData)

      if (result) {
        toast({
          title: "Integration added",
          description: `${newIntegration.name} has been added successfully.`,
        })
      } else {
        toast({
          title: "Integration failed",
          description: `Failed to add ${newIntegration.name}.`,
          variant: "destructive",
        })
      }

      // Reset form
      setNewIntegration({
        name: "",
        type: "",
        status: "disconnected",
        settings: {},
      })

      // Close dialog
      setIsAddIntegrationDialogOpen(false)

      // Refresh integrations
      console.log("Calling refreshIntegrations after adding integration")
      await refreshIntegrations()
    } catch (error) {
      console.error("Error adding integration:", error)
      toast({
        title: "Error",
        description: "Failed to add integration. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleConfigureIntegration = (integration: Integration) => {
    setSelectedIntegration(integration)
    setIsConfigureDialogOpen(true)
  }

  const handleSaveConfiguration = async () => {
    if (!selectedIntegration) return

    // In a real app, you would implement this
    console.log("Saving configuration for:", selectedIntegration)
    setIsConfigureDialogOpen(false)

    // Refresh integrations
    refreshIntegrations()
  }

  const handleToggleSetting = (integration: Integration, setting: string, value: boolean) => {
    // In a real app, you would implement this
    console.log("Toggling setting:", integration.name, setting, value)

    // Update the integration in the UI immediately for better UX
    const updatedSettings = { ...integration.settings, [setting]: value }

    // Refresh integrations
    refreshIntegrations()
  }

  const handleConnect = async (integration: Integration) => {
    // In a real app, you would implement this
    console.log("Connecting integration:", integration)

    // Associate the integration with the current user
    if (user) {
      const updatedSettings = {
        ...integration.settings,
        userId: user.id,
        username: user.name || user.email?.split("@")[0] || "User",
      }

      try {
        // Update the integration with user information
        await updateIntegration(integration.id, {
          status: "connected",
          settings: updatedSettings,
        })

        toast({
          title: "Integration connected",
          description: `${integration.name} has been connected successfully.`,
        })

        // Refresh integrations
        refreshIntegrations()
      } catch (error) {
        console.error("Error connecting integration:", error)
        toast({
          title: "Error",
          description: "Failed to connect integration. Please try again.",
          variant: "destructive",
        })
      }
    } else {
      toast({
        title: "Authentication required",
        description: "Please log in to connect integrations.",
        variant: "destructive",
      })
    }
  }

  // Get integration icon
  const getIntegrationIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "github":
        return <Github className="h-6 w-6" />
      case "slack":
        return <Slack className="h-6 w-6" />
      case "jira":
      case "trello":
        return <Trello className="h-6 w-6" />
      case "google calendar":
      case "calendar":
        return <Calendar className="h-6 w-6" />
      case "gitlab":
        return <GitMerge className="h-6 w-6" />
      default:
        return <Settings className="h-6 w-6" />
    }
  }

  return (
    <SharedLayout>
      <div className="flex min-h-screen flex-col">
        <div className="flex-1 space-y-4 p-8 pt-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Integrations</h2>
            <div className="flex items-center space-x-2">
              <Button onClick={() => setIsAddIntegrationDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Integration
              </Button>
            </div>
          </div>

          {loading.integrations ? (
            <div className="flex justify-center py-8">
              <LoadingSpinner />
            </div>
          ) : error.integrations ? (
            <div className="text-center py-8 text-red-500">
              <p>Error loading integrations: {error.integrations}</p>
              <Button variant="outline" className="mt-4" onClick={refreshIntegrations}>
                Retry
              </Button>
            </div>
          ) : integrations.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No integrations found</p>
              <Button className="mt-4" onClick={() => setIsAddIntegrationDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Integration
              </Button>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {/* Display all integrations */}
              {integrations.map((integration) => (
                <Card key={integration.id} className="border-l-4 border-l-blue-500">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <div className="flex flex-col space-y-1">
                      <div className="flex items-center space-x-2">
                        {getIntegrationIcon(integration.type)}
                        <CardTitle>{integration.name}</CardTitle>
                      </div>
                      {integration.settings?.repoUrl && (
                        <p className="text-xs text-muted-foreground">{integration.settings.repoUrl}</p>
                      )}
                      {integration.settings?.username && (
                        <p className="text-xs font-medium">User: {integration.settings.username}</p>
                      )}
                    </div>
                    <Badge className={integration.status === "connected" ? "bg-green-500" : "variant-outline"}>
                      {integration.status === "connected" ? "Connected" : "Not Connected"}
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="mb-4">
                      Track time on issues and pull requests, sync GitHub tasks with your task list.
                    </CardDescription>

                    {integration.status === "connected" ? (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Auto-track PR reviews</span>
                          <Switch
                            checked={integration.settings?.autoTrackPRs || false}
                            onCheckedChange={(value) => handleToggleSetting(integration, "autoTrackPRs", value)}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Sync issues as tasks</span>
                          <Switch
                            checked={integration.settings?.syncIssues || false}
                            onCheckedChange={(value) => handleToggleSetting(integration, "syncIssues", value)}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Track commit time</span>
                          <Switch
                            checked={integration.settings?.trackCommits || false}
                            onCheckedChange={(value) => handleToggleSetting(integration, "trackCommits", value)}
                          />
                        </div>

                        <div className="mt-4 flex justify-end">
                          <Button variant="outline" size="sm" onClick={() => handleConfigureIntegration(integration)}>
                            <Settings className="mr-2 h-4 w-4" />
                            Configure
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-4 flex justify-center">
                        <Button onClick={() => handleConnect(integration)}>
                          <Plus className="mr-2 h-4 w-4" />
                          Connect
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add Integration Dialog */}
      <Dialog open={isAddIntegrationDialogOpen} onOpenChange={setIsAddIntegrationDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add Integration</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="type" className="text-sm font-medium">
                Integration Type
              </label>
              <Select
                value={newIntegration.type}
                onValueChange={(value) => setNewIntegration({ ...newIntegration, type: value })}
              >
                <SelectTrigger id="type">
                  <SelectValue placeholder="Select integration type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="github">GitHub</SelectItem>
                  <SelectItem value="slack">Slack</SelectItem>
                  <SelectItem value="jira">Jira</SelectItem>
                  <SelectItem value="google calendar">Google Calendar</SelectItem>
                  <SelectItem value="gitlab">GitLab</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <label htmlFor="name" className="text-sm font-medium">
                Name
              </label>
              <Input
                id="name"
                value={newIntegration.name}
                onChange={(e) => setNewIntegration({ ...newIntegration, name: e.target.value })}
                placeholder="Integration name"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddIntegrationDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddIntegration} disabled={!newIntegration.type || !newIntegration.name}>
              Add Integration
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Configure Integration Dialog */}
      <Dialog open={isConfigureDialogOpen} onOpenChange={setIsConfigureDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Configure {selectedIntegration?.name}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {selectedIntegration?.type === "github" && (
              <>
                <div className="grid gap-2">
                  <label htmlFor="username" className="text-sm font-medium">
                    GitHub Username
                  </label>
                  <Input
                    id="username"
                    value={selectedIntegration?.settings?.username || ""}
                    onChange={(e) => {
                      if (selectedIntegration) {
                        setSelectedIntegration({
                          ...selectedIntegration,
                          settings: {
                            ...selectedIntegration.settings,
                            username: e.target.value,
                          },
                        })
                      }
                    }}
                    placeholder="Your GitHub username"
                  />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="repo" className="text-sm font-medium">
                    Repository URL
                  </label>
                  <Input
                    id="repo"
                    value={selectedIntegration?.settings?.repoUrl || ""}
                    onChange={(e) => {
                      if (selectedIntegration) {
                        setSelectedIntegration({
                          ...selectedIntegration,
                          settings: {
                            ...selectedIntegration.settings,
                            repoUrl: e.target.value,
                          },
                        })
                      }
                    }}
                    placeholder="https://github.com/username/repo"
                  />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="token" className="text-sm font-medium">
                    API Token
                  </label>
                  <Input
                    id="token"
                    type="password"
                    value={selectedIntegration?.settings?.apiToken || ""}
                    onChange={(e) => {
                      if (selectedIntegration) {
                        setSelectedIntegration({
                          ...selectedIntegration,
                          settings: {
                            ...selectedIntegration.settings,
                            apiToken: e.target.value,
                          },
                        })
                      }
                    }}
                    placeholder="GitHub API token"
                  />
                </div>
              </>
            )}

            {selectedIntegration?.type === "slack" && (
              <>
                <div className="grid gap-2">
                  <label htmlFor="workspace" className="text-sm font-medium">
                    Workspace
                  </label>
                  <Input
                    id="workspace"
                    value={selectedIntegration?.settings?.workspace || ""}
                    placeholder="Slack workspace name"
                  />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="token" className="text-sm font-medium">
                    Bot Token
                  </label>
                  <Input
                    id="token"
                    type="password"
                    value={selectedIntegration?.settings?.botToken || ""}
                    placeholder="Slack bot token"
                  />
                </div>
              </>
            )}

            {selectedIntegration?.type === "jira" && (
              <>
                <div className="grid gap-2">
                  <label htmlFor="url" className="text-sm font-medium">
                    Jira URL
                  </label>
                  <Input
                    id="url"
                    value={selectedIntegration?.settings?.jiraUrl || ""}
                    placeholder="https://your-domain.atlassian.net"
                  />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    Email
                  </label>
                  <Input id="email" value={selectedIntegration?.settings?.email || ""} placeholder="Your Jira email" />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="token" className="text-sm font-medium">
                    API Token
                  </label>
                  <Input
                    id="token"
                    type="password"
                    value={selectedIntegration?.settings?.apiToken || ""}
                    placeholder="Jira API token"
                  />
                </div>
              </>
            )}

            {selectedIntegration?.type === "google calendar" && (
              <>
                <div className="grid gap-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    Google Account
                  </label>
                  <Input
                    id="email"
                    value={selectedIntegration?.settings?.email || ""}
                    placeholder="Your Google email"
                  />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="calendars" className="text-sm font-medium">
                    Calendars to Sync
                  </label>
                  <Input
                    id="calendars"
                    value={selectedIntegration?.settings?.calendars || ""}
                    placeholder="Primary, Work, etc."
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfigureDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveConfiguration}>Save Configuration</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SharedLayout>
  )
}

async function updateIntegration(integrationId: string, data: any) {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`updateIntegration called for id ${integrationId} with:`, data)
      resolve(true)
    }, 500)
  })
}
