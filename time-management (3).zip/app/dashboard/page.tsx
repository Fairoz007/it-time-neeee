"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { BarChart2, CheckSquare, AlertCircle, ArrowUp, Clock4, GitPullRequest, Play, Pause } from "lucide-react"
import { useData } from "@/contexts/data-context"
import { TimerButton, TimerDisplay } from "@/components/timer"
import { LoadingSpinner } from "@/components/loading-spinner"
import type { Task } from "@/lib/supabase-client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { format } from "date-fns"
import { supabase } from "@/lib/supabase-client"
import { toast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { useTimeTracking } from "@/hooks/use-time-tracking"
import { ProtectedRoute } from "@/components/protected-route"
import { SharedLayout } from "@/components/shared-layout"
// Import other components and hooks as needed

export default function DashboardPage() {
  const router = useRouter()
  const { projects, tasks, dashboardMetrics, loading, error, refreshProjects, refreshTasks, refreshDashboardMetrics } =
    useData()
  const { startTracking, stopTracking, activeEntry, formatElapsedTime } = useTimeTracking()

  const [isNewTaskDialogOpen, setIsNewTaskDialogOpen] = useState(false)
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    priority: "medium",
    project_id: "",
    due_date: format(new Date(), "yyyy-MM-dd"),
  })
  const [dataLoaded, setDataLoaded] = useState(false)
  const [initialLoadAttempted, setInitialLoadAttempted] = useState(false)
  const [saving, setSaving] = useState(false)

  // Load dashboard data
  useEffect(() => {
    const loadDashboardData = async () => {
      if (!initialLoadAttempted) {
        console.log("Loading dashboard data...")
        setInitialLoadAttempted(true)

        try {
          // Try to load all data, but don't fail if individual requests fail
          await Promise.allSettled([
            refreshProjects().catch((err) => console.error("Error refreshing projects:", err)),
            refreshTasks().catch((err) => console.error("Error refreshing tasks:", err)),
            refreshDashboardMetrics().catch((err) => console.error("Error refreshing metrics:", err)),
          ])

          console.log("Dashboard data loaded successfully")
          setDataLoaded(true)
        } catch (err) {
          console.error("Error loading dashboard data:", err)
          toast({
            title: "Warning",
            description: "Some data could not be loaded. Using mock data instead.",
            variant: "destructive",
          })
          // Still set dataLoaded to true so the UI renders
          setDataLoaded(true)
        }
      }
    }

    loadDashboardData()
  }, [initialLoadAttempted, refreshProjects, refreshTasks, refreshDashboardMetrics])

  // Get high priority tasks
  const priorityTasks = tasks
    .filter((task) => task.status !== "completed" && (task.priority === "high" || task.priority === "critical"))
    .sort((a, b) => {
      const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 }
      return priorityOrder[a.priority] - priorityOrder[b.priority]
    })
    .slice(0, 3)

  // Get active projects with progress
  const activeProjects = projects
    .filter((project) => project.status === "active")
    .sort((a, b) => b.progress - a.progress)

  const handleStartTask = async (taskId: string) => {
    try {
      // Find the task
      const task = tasks.find((t) => t.id === taskId)
      if (!task) return

      // Start tracking time for this task
      const result = await startTracking({
        taskId,
        projectId: task.project_id,
        taskTitle: task.title,
        projectName: projects.find((p) => p.id === task.project_id)?.name,
      })

      if (result) {
        // Update task status to in_progress if it's not already
        if (task.status !== "in_progress") {
          await supabase.from("tasks").update({ status: "in_progress" }).eq("id", taskId)
          // Refresh tasks
          await refreshTasks()
        }
      }
    } catch (error) {
      console.error("Error starting task:", error)
      toast({
        title: "Error",
        description: "Failed to start time tracking. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleCreateTask = async () => {
    try {
      // Prepare task data
      const taskData = {
        title: newTask.title,
        description: newTask.description,
        priority: newTask.priority as Task["priority"],
        project_id: newTask.project_id,
        due_date: newTask.due_date,
        status: "todo" as Task["status"],
        assignee_id: "default-user", // Use a default user ID
        tags: [],
        dependencies: [],
        blocking: [],
        estimated_hours: 0,
        actual_hours: 0,
      }

      // Insert the task
      const { data, error } = await supabase.from("tasks").insert([taskData]).select()

      if (error) throw error

      toast({
        title: "Task created",
        description: "Your new task has been created successfully.",
      })

      // Reset form
      setNewTask({
        title: "",
        description: "",
        priority: "medium",
        project_id: "",
        due_date: format(new Date(), "yyyy-MM-dd"),
      })

      // Close dialog
      setIsNewTaskDialogOpen(false)

      // Refresh tasks
      await refreshTasks()
    } catch (err: any) {
      console.error("Error creating task:", err)
      toast({
        title: "Error",
        description: err.message || "Failed to create task. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  // Get priority badge color
  const getPriorityColor = (priority: Task["priority"]) => {
    switch (priority) {
      case "critical":
        return "bg-red-500"
      case "high":
        return "bg-amber-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  // Show loading state if data is still loading
  if (!dataLoaded && (loading.projects || loading.tasks || loading.dashboardMetrics)) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <LoadingSpinner className="mx-auto mb-4" />
          <h3 className="text-lg font-medium">Loading dashboard...</h3>
          <p className="text-sm text-muted-foreground">Please wait while we load your data</p>
        </div>
      </div>
    )
  }

  return (
    <ProtectedRoute>
      <SharedLayout>
        {/* Dashboard content */}
        <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
            <div className="flex items-center space-x-2">
              <TimerButton />
            </div>
          </div>

          {/* Rest of dashboard content */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {/* Dashboard cards */}
            <Card className="card-hover-effect">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Projects</CardTitle>
                <GitPullRequest className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                {loading.dashboardMetrics ? (
                  <LoadingSpinner className="h-8" />
                ) : (
                  <>
                    <div className="text-2xl font-bold">{dashboardMetrics?.activeProjects || 0}</div>
                    <p className="text-xs text-muted-foreground">
                      {dashboardMetrics?.activeProjects > 0
                        ? `${Math.round(
                            projects.filter((p) => p.status === "active").reduce((acc, p) => acc + p.progress, 0) /
                              dashboardMetrics.activeProjects,
                          )}% avg. progress`
                        : "No active projects"}
                    </p>
                  </>
                )}
              </CardContent>
            </Card>

            <Card className="card-hover-effect">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Tasks</CardTitle>
                <CheckSquare className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                {loading.dashboardMetrics ? (
                  <LoadingSpinner className="h-8" />
                ) : (
                  <>
                    <div className="text-2xl font-bold">{dashboardMetrics?.pendingTasks || 0}</div>
                    <p className="text-xs text-muted-foreground">
                      {tasks.filter((t) => t.status !== "completed" && new Date(t.due_date) <= new Date()).length || 0}{" "}
                      due today
                    </p>
                  </>
                )}
              </CardContent>
            </Card>

            <Card className="card-hover-effect">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Hours Tracked</CardTitle>
                <Clock4 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                {loading.dashboardMetrics ? (
                  <LoadingSpinner className="h-8" />
                ) : (
                  <>
                    <div className="text-2xl font-bold">{dashboardMetrics?.hoursTrackedThisWeek || 0}</div>
                    <p className="text-xs text-muted-foreground">This week</p>
                  </>
                )}
              </CardContent>
            </Card>

            <Card className="card-hover-effect">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Productivity Score</CardTitle>
                <BarChart2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                {loading.dashboardMetrics ? (
                  <LoadingSpinner className="h-8" />
                ) : (
                  <>
                    <div className="text-2xl font-bold">{dashboardMetrics?.productivityScore || 0}%</div>
                    <p className="text-xs text-muted-foreground">
                      <ArrowUp className="h-3 w-3 inline mr-1" />
                      +5% from last week
                    </p>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="w-full flex flex-nowrap overflow-x-auto pb-1 scrollbar-thin">
              <TabsTrigger value="overview" className="whitespace-nowrap">
                Overview
              </TabsTrigger>
              <TabsTrigger value="projects" className="whitespace-nowrap">
                Projects
              </TabsTrigger>
              <TabsTrigger value="tasks" className="whitespace-nowrap">
                Tasks
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
                <Card className="col-span-4">
                  <CardHeader>
                    <CardTitle>Project Progress</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {loading.projects ? (
                      <LoadingSpinner />
                    ) : error.projects ? (
                      <div className="text-center py-4">
                        <AlertCircle className="mx-auto h-8 w-8 text-red-500 mb-2" />
                        <p className="text-muted-foreground">Error loading projects</p>
                        <Button variant="outline" size="sm" className="mt-2" onClick={refreshProjects}>
                          Try Again
                        </Button>
                      </div>
                    ) : activeProjects.length === 0 ? (
                      <div className="text-center py-4">
                        <p className="text-muted-foreground">No active projects</p>
                        <Button variant="outline" size="sm" className="mt-2" onClick={() => router.push("/projects")}>
                          Create Project
                        </Button>
                      </div>
                    ) : (
                      activeProjects.slice(0, 4).map((project) => (
                        <div key={project.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <div className="h-2 w-2 rounded-full bg-primary"></div>
                              <span className="text-sm font-medium">{project.name}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">{project.progress}%</span>
                          </div>
                          <Progress value={project.progress} />
                          <div className="flex justify-between text-xs text-muted-foreground mt-1">
                            <span>Resource utilization: {project.resource_allocation}%</span>
                            <span>
                              Estimated completion:{" "}
                              {project.end_date ? format(new Date(project.end_date), "MMM d, yyyy") : "Not set"}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </CardContent>
                </Card>

                <Card className="col-span-3">
                  <CardHeader>
                    <CardTitle>Priority Tasks</CardTitle>
                    <CardDescription>Tasks requiring immediate attention</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {loading.tasks ? (
                      <LoadingSpinner />
                    ) : error.tasks ? (
                      <div className="text-center py-4">
                        <AlertCircle className="mx-auto h-8 w-8 text-red-500 mb-2" />
                        <p className="text-muted-foreground">Error loading tasks</p>
                        <Button variant="outline" size="sm" className="mt-2" onClick={refreshTasks}>
                          Try Again
                        </Button>
                      </div>
                    ) : priorityTasks.length === 0 ? (
                      <div className="text-center py-4">
                        <p className="text-muted-foreground">No priority tasks</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-2"
                          onClick={() => setIsNewTaskDialogOpen(true)}
                        >
                          Create Task
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {priorityTasks.map((task) => (
                          <div key={task.id} className="flex items-center space-x-4">
                            <div className="rounded-full bg-red-100 p-1">
                              <AlertCircle
                                className={`h-4 w-4 ${task.priority === "critical" ? "text-red-600" : "text-amber-600"}`}
                              />
                            </div>
                            <div className="flex-1 space-y-1">
                              <p className="text-sm font-medium leading-none">{task.title}</p>
                              <div className="flex items-center">
                                <p className="text-xs text-muted-foreground mr-2">
                                  Due {format(new Date(task.due_date), "MMM d, yyyy")}
                                </p>
                                <span
                                  className={`text-xs ${getPriorityColor(task.priority)} px-1.5 py-0.5 rounded-full text-white`}
                                >
                                  {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                                </span>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant={activeEntry?.taskId === task.id ? "destructive" : "default"}
                              onClick={() =>
                                activeEntry?.taskId === task.id ? stopTracking() : handleStartTask(task.id)
                              }
                            >
                              {activeEntry?.taskId === task.id ? (
                                <>
                                  <Pause className="mr-1 h-3 w-3" />
                                  {formatElapsedTime()}
                                </>
                              ) : (
                                <>
                                  <Play className="mr-1 h-3 w-3" />
                                  Start
                                </>
                              )}
                            </Button>
                          </div>
                        ))}

                        <Button variant="outline" className="w-full mt-2" onClick={() => setIsNewTaskDialogOpen(true)}>
                          <CheckSquare className="mr-2 h-4 w-4" />
                          Create New Task
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="projects" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Active Projects</CardTitle>
                  <CardDescription>Current projects in progress</CardDescription>
                </CardHeader>
                <CardContent>
                  {loading.projects ? (
                    <LoadingSpinner />
                  ) : activeProjects.length === 0 ? (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground">No active projects</p>
                      <Button variant="outline" size="sm" className="mt-2" onClick={() => router.push("/projects")}>
                        Create Project
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {activeProjects.map((project) => (
                        <div key={project.id} className="rounded-lg border p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="text-lg font-medium">{project.name}</h3>
                            <span className="text-sm bg-blue-100 text-blue-600 px-2 py-1 rounded-full">
                              {project.progress}% Complete
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground mb-4">{project.description}</p>
                          <Progress value={project.progress} className="mb-4" />
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Start Date:</span>{" "}
                              {format(new Date(project.start_date), "MMM d, yyyy")}
                            </div>
                            <div>
                              <span className="text-muted-foreground">End Date:</span>{" "}
                              {project.end_date ? format(new Date(project.end_date), "MMM d, yyyy") : "Not set"}
                            </div>
                            <div>
                              <span className="text-muted-foreground">Estimated Hours:</span> {project.estimated_hours}
                            </div>
                            <div>
                              <span className="text-muted-foreground">Actual Hours:</span> {project.actual_hours}
                            </div>
                          </div>
                          <div className="flex justify-end mt-4">
                            <Button
                              variant="outline"
                              size="sm"
                              className="mr-2"
                              onClick={() => router.push(`/projects/${project.id}`)}
                            >
                              View Details
                            </Button>
                            <Button
                              size="sm"
                              onClick={() =>
                                startTracking({
                                  projectId: project.id,
                                  projectName: project.name,
                                })
                              }
                            >
                              <Play className="mr-1 h-3 w-3" />
                              Track Time
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tasks" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>My Tasks</CardTitle>
                  <CardDescription>Tasks assigned to you</CardDescription>
                </CardHeader>
                <CardContent>
                  {loading.tasks ? (
                    <LoadingSpinner />
                  ) : tasks.length === 0 ? (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground">No tasks assigned</p>
                      <Button variant="outline" size="sm" className="mt-2" onClick={() => setIsNewTaskDialogOpen(true)}>
                        Create Task
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {tasks
                        .filter((task) => task.status !== "completed")
                        .slice(0, 5)
                        .map((task) => (
                          <div key={task.id} className="rounded-lg border p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="text-md font-medium">{task.title}</h3>
                              <span
                                className={`text-xs ${getPriorityColor(task.priority)} px-1.5 py-0.5 rounded-full text-white`}
                              >
                                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">{task.description}</p>
                            <div className="flex justify-between text-xs text-muted-foreground mb-4">
                              <span>Due: {format(new Date(task.due_date), "MMM d, yyyy")}</span>
                              <span>Project: {projects.find((p) => p.id === task.project_id)?.name || "Unknown"}</span>
                            </div>
                            <div className="flex justify-end">
                              <Button
                                variant="outline"
                                size="sm"
                                className="mr-2"
                                onClick={() => router.push(`/tasks/${task.id}`)}
                              >
                                View Details
                              </Button>
                              <Button
                                size="sm"
                                variant={activeEntry?.taskId === task.id ? "destructive" : "default"}
                                onClick={() =>
                                  activeEntry?.taskId === task.id ? stopTracking() : handleStartTask(task.id)
                                }
                              >
                                {activeEntry?.taskId === task.id ? (
                                  <>
                                    <Pause className="mr-1 h-3 w-3" />
                                    {formatElapsedTime()}
                                  </>
                                ) : (
                                  <>
                                    <Play className="mr-1 h-3 w-3" />
                                    Start
                                  </>
                                )}
                              </Button>
                            </div>
                          </div>
                        ))}

                      <Button variant="outline" className="w-full mt-2" onClick={() => setIsNewTaskDialogOpen(true)}>
                        <CheckSquare className="mr-2 h-4 w-4" />
                        Create New Task
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* New Task Dialog */}
          <Dialog open={isNewTaskDialogOpen} onOpenChange={setIsNewTaskDialogOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <label htmlFor="title" className="text-sm font-medium">
                    Title
                  </label>
                  <Input
                    id="title"
                    value={newTask.title}
                    onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                    placeholder="Task title"
                  />
                </div>

                <div className="grid gap-2">
                  <label htmlFor="description" className="text-sm font-medium">
                    Description
                  </label>
                  <Textarea
                    id="description"
                    value={newTask.description}
                    onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                    placeholder="Task description"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <label htmlFor="project" className="text-sm font-medium">
                      Project
                    </label>
                    <Select
                      value={newTask.project_id}
                      onValueChange={(value) => setNewTask({ ...newTask, project_id: value })}
                    >
                      <SelectTrigger id="project">
                        <SelectValue placeholder="Select a project" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects.map((project) => (
                          <SelectItem key={project.id} value={project.id}>
                            {project.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <label htmlFor="priority" className="text-sm font-medium">
                      Priority
                    </label>
                    <Select
                      value={newTask.priority}
                      onValueChange={(value) => setNewTask({ ...newTask, priority: value as Task["priority"] })}
                    >
                      <SelectTrigger id="priority">
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid gap-2">
                  <label htmlFor="due_date" className="text-sm font-medium">
                    Due Date
                  </label>
                  <Input
                    id="due_date"
                    type="date"
                    value={newTask.due_date}
                    onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsNewTaskDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateTask} disabled={!newTask.title || !newTask.project_id}>
                  Create Task
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        <TimerDisplay />
      </SharedLayout>
    </ProtectedRoute>
  )
}
