"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart2,
  Download,
  FileText,
  Clock,
  PieChart,
  Share2,
  Printer,
  ChevronDown,
  ArrowUpRight,
  Users,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useDownloadCsv } from "@/hooks/use-download-csv"

export default function ReportsPage() {
  const { downloadCsv } = useDownloadCsv()

  const handleExportCsv = () => {
    // Mock data for the report
    const reportData = [
      {
        Date: "2023-01-01",
        Project: "Project A",
        Task: "Task 1",
        Duration: "8 hours",
        TeamMember: "John Doe",
        Billable: "Yes",
      },
      {
        Date: "2023-01-02",
        Project: "Project B",
        Task: "Task 2",
        Duration: "6 hours",
        TeamMember: "Jane Smith",
        Billable: "Yes",
      },
      {
        Date: "2023-01-03",
        Project: "Project A",
        Task: "Task 3",
        Duration: "4 hours",
        TeamMember: "John Doe",
        Billable: "No",
      },
    ]

    // Define CSV headers
    const headers = ["Date", "Project", "Task", "Duration", "TeamMember", "Billable"]

    // Call the downloadCsv function
    downloadCsv(reportData, headers, "time-tracker-report.csv")
  }

  const handleExportPdf = () => {
    // Mock data for the report
    const reportData = [
      {
        Date: "2023-01-01",
        Project: "Project A",
        Task: "Task 1",
        Duration: "8 hours",
        TeamMember: "John Doe",
        Billable: "Yes",
      },
      {
        Date: "2023-01-02",
        Project: "Project B",
        Task: "Task 2",
        Duration: "6 hours",
        TeamMember: "Jane Smith",
        Billable: "Yes",
      },
      {
        Date: "2023-01-03",
        Project: "Project A",
        Task: "Task 3",
        Duration: "4 hours",
        TeamMember: "John Doe",
        Billable: "No",
      },
    ]

    // Define CSV headers
    const headers = ["Date", "Project", "Task", "Duration", "TeamMember", "Billable"]

    // Call the downloadCsv function
    downloadCsv(reportData, headers, "time-tracker-report.pdf")
  }

  const handleExportExcel = () => {
    // Mock data for the report
    const reportData = [
      {
        Date: "2023-01-01",
        Project: "Project A",
        Task: "Task 1",
        Duration: "8 hours",
        TeamMember: "John Doe",
        Billable: "Yes",
      },
      {
        Date: "2023-01-02",
        Project: "Project B",
        Task: "Task 2",
        Duration: "6 hours",
        TeamMember: "Jane Smith",
        Billable: "Yes",
      },
      {
        Date: "2023-01-03",
        Project: "Project A",
        Task: "Task 3",
        Duration: "4 hours",
        TeamMember: "John Doe",
        Billable: "No",
      },
    ]

    // Define CSV headers
    const headers = ["Date", "Project", "Task", "Duration", "TeamMember", "Billable"]

    // Call the downloadCsv function
    downloadCsv(reportData, headers, "time-tracker-report.xlsx")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex-1 space-y-6 p-6 md:p-8 lg:p-10">
        {/* Page Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
            <p className="text-muted-foreground mt-1">View and analyze your team's performance data</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" className="h-9">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                <DropdownMenuItem onClick={handleExportCsv}>
                  <FileText className="mr-2 h-4 w-4" />
                  Export as CSV
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportPdf}>
                  <FileText className="mr-2 h-4 w-4" />
                  Export as PDF
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportExcel}>
                  <FileText className="mr-2 h-4 w-4" />
                  Export as Excel
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <Separator />

        {/* Filters Section */}
        <div className="rounded-lg border bg-card p-4 shadow-sm">
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
            <div className="flex flex-col space-y-2 md:flex-row md:items-center md:space-x-2 md:space-y-0">
              <Select defaultValue="week">
                <SelectTrigger className="w-full md:w-[180px]">
                  <SelectValue placeholder="Time period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="day">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="quarter">This Quarter</SelectItem>
                  <SelectItem value="year">This Year</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-[180px]">
                  <SelectValue placeholder="Project" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Projects</SelectItem>
                  <SelectItem value="api">API Integration</SelectItem>
                  <SelectItem value="frontend">Frontend Development</SelectItem>
                  <SelectItem value="database">Database Migration</SelectItem>
                  <SelectItem value="testing">Testing & QA</SelectItem>
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-[180px]">
                  <SelectValue placeholder="Team member" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Team Members</SelectItem>
                  <SelectItem value="me">Just Me</SelectItem>
                  <SelectItem value="backend">Backend Team</SelectItem>
                  <SelectItem value="frontend">Frontend Team</SelectItem>
                  <SelectItem value="qa">QA Team</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Tabs Section */}
        <Tabs defaultValue="summary" className="space-y-6">
          <div className="overflow-x-auto">
            <TabsList className="w-full justify-start border-b p-0 h-auto">
              <TabsTrigger
                value="summary"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Summary
              </TabsTrigger>
              <TabsTrigger
                value="detailed"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Detailed
              </TabsTrigger>
              <TabsTrigger
                value="time"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Time Tracking
              </TabsTrigger>
              <TabsTrigger
                value="productivity"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Productivity
              </TabsTrigger>
              <TabsTrigger
                value="custom"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Custom Reports
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Summary Tab Content */}
          <TabsContent value="summary" className="space-y-6 mt-6">
            {/* Metrics Cards */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card className="overflow-hidden border-l-4 border-l-primary">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Hours</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">187.5</div>
                  <div className="flex items-center mt-1">
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      <ArrowUpRight className="mr-1 h-3 w-3" />
                      +12.5 from last week
                    </Badge>
                  </div>
                </CardContent>
              </Card>
              <Card className="overflow-hidden border-l-4 border-l-blue-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tasks Completed</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">42</div>
                  <div className="flex items-center mt-1">
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      <ArrowUpRight className="mr-1 h-3 w-3" />
                      +8 from last week
                    </Badge>
                  </div>
                </CardContent>
              </Card>
              <Card className="overflow-hidden border-l-4 border-l-yellow-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Average Productivity</CardTitle>
                  <BarChart2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">84%</div>
                  <div className="flex items-center mt-1">
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      <ArrowUpRight className="mr-1 h-3 w-3" />
                      +2% from last week
                    </Badge>
                  </div>
                </CardContent>
              </Card>
              <Card className="overflow-hidden border-l-4 border-l-purple-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Billable Hours</CardTitle>
                  <PieChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">162.5</div>
                  <div className="flex items-center mt-1">
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      87% of total hours
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts Section */}
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="col-span-1">
                <CardHeader className="flex flex-row items-center justify-between pb-3">
                  <div>
                    <CardTitle>Time Distribution by Project</CardTitle>
                    <CardDescription>Hours spent on each project this week</CardDescription>
                  </div>
                  <div className="flex space-x-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Share2 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Printer className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="h-[300px] flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <PieChart className="mx-auto h-12 w-12 mb-2" />
                    <p>Project time distribution chart would appear here</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="col-span-1">
                <CardHeader className="flex flex-row items-center justify-between pb-3">
                  <div>
                    <CardTitle>Daily Hours Tracked</CardTitle>
                    <CardDescription>Hours tracked each day this week</CardDescription>
                  </div>
                  <div className="flex space-x-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Share2 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Printer className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="h-[300px] flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <BarChart2 className="mx-auto h-12 w-12 mb-2" />
                    <p>Daily hours chart would appear here</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Team Member Summary Table */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Team Member Summary</CardTitle>
                    <CardDescription>Hours tracked and tasks completed by team member</CardDescription>
                  </div>
                  <Button variant="outline" size="sm">
                    <Users className="mr-2 h-4 w-4" />
                    View All Members
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-hidden">
                  <div className="grid grid-cols-5 bg-muted/50 p-3 text-sm font-medium">
                    <div>Team Member</div>
                    <div>Hours Tracked</div>
                    <div>Tasks Completed</div>
                    <div>Productivity</div>
                    <div>Billable Hours</div>
                  </div>
                  <div className="grid grid-cols-5 border-t p-3 text-sm hover:bg-muted/20">
                    <div className="font-medium">John D.</div>
                    <div>42.5</div>
                    <div>12</div>
                    <div>
                      <div className="flex items-center">
                        <span className="mr-2">88%</span>
                        <div className="h-2 w-24 rounded-full bg-muted">
                          <div className="h-2 rounded-full bg-green-500" style={{ width: "88%" }}></div>
                        </div>
                      </div>
                    </div>
                    <div>38.0</div>
                  </div>
                  <div className="grid grid-cols-5 border-t p-3 text-sm hover:bg-muted/20">
                    <div className="font-medium">Sarah M.</div>
                    <div>38.0</div>
                    <div>9</div>
                    <div>
                      <div className="flex items-center">
                        <span className="mr-2">92%</span>
                        <div className="h-2 w-24 rounded-full bg-muted">
                          <div className="h-2 rounded-full bg-green-500" style={{ width: "92%" }}></div>
                        </div>
                      </div>
                    </div>
                    <div>35.5</div>
                  </div>
                  <div className="grid grid-cols-5 border-t p-3 text-sm hover:bg-muted/20">
                    <div className="font-medium">Alex K.</div>
                    <div>45.0</div>
                    <div>14</div>
                    <div>
                      <div className="flex items-center">
                        <span className="mr-2">78%</span>
                        <div className="h-2 w-24 rounded-full bg-muted">
                          <div className="h-2 rounded-full bg-yellow-500" style={{ width: "78%" }}></div>
                        </div>
                      </div>
                    </div>
                    <div>36.0</div>
                  </div>
                  <div className="grid grid-cols-5 border-t p-3 text-sm hover:bg-muted/20">
                    <div className="font-medium">Lisa T.</div>
                    <div>32.0</div>
                    <div>7</div>
                    <div>
                      <div className="flex items-center">
                        <span className="mr-2">85%</span>
                        <div className="h-2 w-24 rounded-full bg-muted">
                          <div className="h-2 rounded-full bg-green-500" style={{ width: "85%" }}></div>
                        </div>
                      </div>
                    </div>
                    <div>28.0</div>
                  </div>
                  <div className="grid grid-cols-5 border-t p-3 text-sm hover:bg-muted/20">
                    <div className="font-medium">Michael R.</div>
                    <div>30.0</div>
                    <div>8</div>
                    <div>
                      <div className="flex items-center">
                        <span className="mr-2">79%</span>
                        <div className="h-2 w-24 rounded-full bg-muted">
                          <div className="h-2 rounded-full bg-yellow-500" style={{ width: "79%" }}></div>
                        </div>
                      </div>
                    </div>
                    <div>25.0</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
