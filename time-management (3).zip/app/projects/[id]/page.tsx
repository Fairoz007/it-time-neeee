"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { SharedLayout } from "@/components/shared-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LoadingSpinner } from "@/components/loading-spinner"
import { ArrowLeft, Clock, Users, Calendar, AlertCircle, LinkIcon } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { supabase, type Project, type Task } from "@/lib/supabase-client"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const isValidUUID = (uuid: string) => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
  return uuidRegex.test(uuid)
}

export default function ProjectDetailPage() {
  const params = useParams()
  const router = useRouter()
  const projectId = params.id as string

  const [project, setProject] = useState<Project | null>(null)
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isAddTaskDialogOpen, setIsAddTaskDialogOpen] = useState(false)
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    priority: "medium" as Task["priority"],
    status: "todo" as Task["status"],
    due_date: format(new Date(), "yyyy-MM-dd"),
    estimated_hours: 0,
    tags: [] as string[],
    dependencies: [] as string[],
    blocking: [],
  })
  const [userProfiles, setUserProfiles] = useState<{ id: string; name: string; email: string; avatar_url?: string }[]>(
    [],
  )
  const [task, setTask] = useState<Task | null>(null)

  useEffect(() => {
    async function fetchProjectData() {
      let taskData: Task | null = null
      let projectData: Project | null = null

      setLoading(true)
      setError(null)

      // Check if projectId is a valid UUID
      if (!isValidUUID(projectId)) {
        console.warn("Invalid projectId:", projectId)
        setError("Invalid project ID")
        setLoading(false)
        return
      }

      try {
        // Try to fetch task details from Supabase
        const { data, error } = await supabase.from("tasks").select("*").eq("id", projectId).single()

        if (error) throw error
        taskData = data

        // Fetch project details if we have a project_id
        if (taskData.project_id) {
          const { data: projData, error: projectError } = await supabase
            .from("projects")
            .select("*")
            .eq("id", taskData.project_id)
            .single()

          if (!projectError) {
            projectData = projData
          }
        }
      } catch (supabaseError: any) {
        console.warn("Supabase query failed, using mock data instead:", supabaseError.message)

        // Provide mock data for demonstration purposes
        taskData = {
          id: projectId,
          title: `Task ${projectId}`,
          description:
            "This is a mock task created because the database query failed. In a production environment, you would ensure proper UUID formatting for database queries.",
          priority: "medium",
          status: "in_progress",
          due_date: new Date().toISOString().split("T")[0],
          project_id: "mock-project-1",
          tags: ["mock", "example"],
          assignee_id: "default-user",
          dependencies: [],
          blocking: [],
          estimated_hours: 8,
          actual_hours: 2.5,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }

        projectData = {
          id: "mock-project-1",
          name: "Mock Project",
          description: "This is a mock project",
          status: "active",
          start_date: new Date().toISOString().split("T")[0],
          end_date: null,
          progress: 35,
          team_members: ["John Doe", "Sarah Smith"],
          resource_allocation: 75,
          estimated_hours: 120,
          actual_hours: 42,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          risk_level: "medium",
        }
      }

      setTask(taskData)
      if (projectData) {
        setProject(projectData)
      }

      // Check for active time entry
      try {
        const { data: timeEntryData, error: timeEntryError } = await supabase
          .from("time_entries")
          .select("*")
          .eq("task_id", projectId)
          .is("end_time", null)
          .order("start_time", { ascending: false })
          .limit(1)
          .single()
      } catch (timeEntryError: any) {
        console.warn("Error fetching time entries:", timeEntryError)
      }\
    } catch (err: any) 
      console.error("Error fetching task data:", err)
      setError("Failed to load task data. Please try again.")finally 
      setLoading(false)
  }

  // Add this check to ensure projectId is defined before calling fetchProjectData
  if (projectId) {
    fetchProjectData()
  }
}
, [projectId])

// Get status badge color
const getStatusBadge = (status: Project["status"]) => {
  switch (status) {
    case "active":
      return <Badge className="bg-blue-500">Active</Badge>
    case "completed":
      return <Badge className="bg-green-500">Completed</Badge>
    case "on_hold":
      return <Badge className="bg-amber-500">On Hold</Badge>
    default:
      return <Badge variant="outline">Unknown</Badge>
  }
}

// Get risk level badge
const getRiskBadge = (risk?: Project["risk_level"]) => {
  switch (risk) {
    case "high":
      return (
        <div className="flex items-center">
          <AlertCircle className="h-3 w-3 text-red-500 mr-1" />
          <p className="text-sm font-medium text-red-500">High</p>
        </div>
      )
    case "medium":
      return (
        <div className="flex items-center">
          <AlertCircle className="h-3 w-3 text-amber-500 mr-1" />
          <p className="text-sm font-medium text-amber-500">Medium</p>
        </div>
      )
    case "low":
      return (
        <div className="flex items-center">
          <AlertCircle className="h-3 w-3 text-green-500 mr-1" />
          <p className="text-sm font-medium text-green-500">Low</p>
        </div>
      )
    default:
      return null
  }
}

// Get priority badge color
const getPriorityColor = (priority: Task["priority"]) => {
  switch (priority) {
    case "critical":
      return "bg-red-500"
    case "high":
      return "bg-amber-500"
    case "medium":
      return "bg-yellow-500"
    case "low":
      return "bg-green-500"
    default:
      return "bg-gray-500"
  }
}

const handleAddTask = async () => {
  if (!newTask.title) return

  try {
    // Prepare the task data
    const taskData = {
      ...newTask,
      project_id: projectId,
      assignee_id: "current-user", // In a real app, this would be the current user's ID
      actual_hours: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    // Insert the new task into Supabase
    const { data, error } = await supabase.from("tasks").insert([taskData]).select()

    if (error) throw error

    toast({
      title: "Task created",
      description: `${newTask.title} has been created successfully.`,
    })

    // Reset form
    setNewTask({
      title: "",
      description: "",
      priority: "medium",
      status: "todo",
      due_date: format(new Date(), "yyyy-MM-dd"),
      estimated_hours: 0,
      tags: [],
      dependencies: [],
      blocking: [],
    })

    // Close the dialog
    setIsAddTaskDialogOpen(false)

    // Refresh tasks
    const { data: updatedTasks } = await supabase.from("tasks").select("*").eq("project_id", projectId)

    if (updatedTasks) {
      setTasks(updatedTasks)
    }
  } catch (err: any) {
    console.error("Error creating task:", err)
    toast({
      title: "Error",
      description: "Failed to create task. Please try again.",
      variant: "destructive",
    })
  }
}

if (loading) {
  return (
      <SharedLayout>
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <LoadingSpinner className="mx-auto mb-4" />
            <h3 className="text-lg font-medium">Loading project details...</h3>
            <p className="text-sm text-muted-foreground">Please wait while we fetch the project data</p>
          </div>
        </div>
      </SharedLayout>
    )
}

if (error || !project) {
  return (
      <SharedLayout>
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium">Error Loading Project</h3>
            <p className="text-sm text-muted-foreground mb-4">{error || "Project not found"}</p>
            <Button variant="outline" onClick={() => router.push("/projects")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Projects
            </Button>
          </div>
        </div>
      </SharedLayout>
    )
}

return (
    <SharedLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/projects">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Projects
            </Link>
          </Button>
        </div>

        <div className="flex flex-col space-y-2 md:flex-row md:items-start md:justify-between md:space-y-0">
          <div>
            <h1 className="text-2xl font-bold md:text-3xl">{project.name}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              {getStatusBadge(project.status)}
              {getRiskBadge(project.risk_level)}
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => router.push(`/projects/${project.id}/edit`)}>
              Edit Project
            </Button>
            <Button variant="outline" onClick={() => router.push(`/projects/${project.id}/team`)}>
              Manage Team
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <div className="md:col-span-2 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Project Details</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-line mb-6">{project.description}</p>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Progress</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">{project.progress}% Complete</span>
                    </div>
                    <Progress value={project.progress} />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">Start Date</span>
                      <p className="text-sm font-medium">{format(new Date(project.start_date), "MMM d, yyyy")}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">End Date</span>
                      <p className="text-sm font-medium">
                        {project.end_date ? format(new Date(project.end_date), "MMM d, yyyy") : "Not set"}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">Estimated Hours</span>
                      <p className="text-sm font-medium">{project.estimated_hours}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">Actual Hours</span>
                      <p className="text-sm font-medium">{project.actual_hours}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">Resource Allocation</span>
                      <p className="text-sm font-medium">{project.resource_allocation}%</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">Team Members</span>
                      <p className="text-sm font-medium">{project.team_members.length}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="tasks" className="space-y-4">
              <TabsList>
                <TabsTrigger value="tasks">Tasks</TabsTrigger>
                <TabsTrigger value="activity">Activity</TabsTrigger>
                <TabsTrigger value="files">Files</TabsTrigger>
              </TabsList>

              <TabsContent value="tasks" className="space-y-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Project Tasks</CardTitle>
                    <Button size="sm" onClick={() => setIsAddTaskDialogOpen(true)}>
                      Add Task
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {tasks.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <p>No tasks found for this project</p>
                        <Button className="mt-4" size="sm">
                          Create First Task
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {tasks.map((task) => (
                          <div
                            key={task.id}
                            className="flex items-center justify-between space-x-4 rounded-lg border p-4"
                          >
                            <div className="flex items-start space-x-4">
                              <div className={`rounded-full ${getPriorityColor(task.priority)} p-1`}>
                                <Clock className="h-5 w-5 text-white" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex items-center space-x-2">
                                  <p className="text-sm font-medium leading-none">{task.title}</p>
                                  <Badge variant="outline">
                                    {task.status.replace("_", " ").charAt(0).toUpperCase() + task.status.slice(1)}
                                  </Badge>
                                </div>
                                <p className="text-sm text-muted-foreground">{task.description}</p>
                                <div className="flex flex-wrap items-center gap-2 pt-2">
                                  <div className="flex items-center">
                                    <Calendar className="mr-1 h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      Due {format(new Date(task.due_date), "MMM d, yyyy")}
                                    </span>
                                  </div>
                                  <div className="flex items-center">
                                    <Users className="mr-1 h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      Assigned to {task.assignee_id}
                                    </span>
                                  </div>
                                  {task.dependencies.length > 0 && (
                                    <div className="flex items-center">
                                      <LinkIcon className="mr-1 h-3 w-3 text-muted-foreground" />
                                      <span className="text-xs text-muted-foreground">
                                        {task.dependencies.length} dependencies
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button variant="outline" size="sm" asChild>
                                <Link href={`/tasks/${task.id}`}>View</Link>
                              </Button>
                              <Button size="sm">Start</Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="activity" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Activity Log</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">
                      <p>Activity log will be displayed here</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="files" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Project Files</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">
                      <p>Project files will be displayed here</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Team Members</CardTitle>
              </CardHeader>
              <CardContent>
                {project.team_members.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    <p>No team members assigned</p>
                    <Button className="mt-4" size="sm" variant="outline" asChild>
                      <Link href={`/projects/${project.id}/team`}>Add Team Members</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {project.team_members.map((member, index) => {
                      // Find the user profile if available
                      const userProfile = userProfiles.find((u) => u.name === member)

                      return (
                        <div key={index} className="flex items-center space-x-2">
                          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                            {userProfile?.avatar_url ? (
                              <img
                                src={userProfile.avatar_url || "/placeholder.svg"}
                                alt={member}
                                className="h-full w-full object-cover"
                              />
                            ) : (
                              member.substring(0, 2).toUpperCase()
                            )}
                          </div>
                          <span>{member}</span>
                        </div>
                      )
                    })}
                    <Button className="w-full" size="sm" variant="outline" asChild>
                      <Link href={`/projects/${project.id}/team`}>Manage Team</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Project Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">Total Tasks</span>
                      <p className="text-xl font-bold">{tasks.length}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">Completed</span>
                      <p className="text-xl font-bold">{tasks.filter((t) => t.status === "completed").length}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">In Progress</span>
                      <p className="text-xl font-bold">{tasks.filter((t) => t.status === "in_progress").length}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs text-muted-foreground">To Do</span>
                      <p className="text-xl font-bold">{tasks.filter((t) => t.status === "todo").length}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      {/* Add Task Dialog */}
      <Dialog open={isAddTaskDialogOpen} onOpenChange={setIsAddTaskDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add New Task</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="title" className="text-sm font-medium">
                Title
              </label>
              <Input
                id="title"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                placeholder="Task title"
              />
            </div>

            <div className="grid gap-2">
              <label htmlFor="description" className="text-sm font-medium">
                Description
              </label>
              <Textarea
                id="description"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                placeholder="Task description"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label htmlFor="priority" className="text-sm font-medium">
                  Priority
                </label>
                <Select
                  value={newTask.priority}
                  onValueChange={(value) => setNewTask({ ...newTask, priority: value as Task["priority"] })}
                >
                  <SelectTrigger id="priority">
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <label htmlFor="status" className="text-sm font-medium">
                  Status
                </label>
                <Select
                  value={newTask.status}
                  onValueChange={(value) => setNewTask({ ...newTask, status: value as Task["status"] })}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todo">To Do</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label htmlFor="due_date" className="text-sm font-medium">
                  Due Date
                </label>
                <Input
                  id="due_date"
                  type="date"
                  value={newTask.due_date}
                  onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
                />
              </div>

              <div className="grid gap-2">
                <label htmlFor="estimated_hours" className="text-sm font-medium">
                  Estimated Hours
                </label>
                <Input
                  id="estimated_hours"
                  type="number"
                  min="0"
                  value={newTask.estimated_hours.toString()}
                  onChange={(e) => setNewTask({ ...newTask, estimated_hours: Number(e.target.value) || 0 })}
                />
              </div>
            </div>

            <div className="grid gap-2">
              <label htmlFor="tags" className="text-sm font-medium">
                Tags (comma separated)
              </label>
              <Input
                id="tags"
                placeholder="bug, feature, documentation"
                value={newTask.tags.join(", ")}
                onChange={(e) =>
                  setNewTask({
                    ...newTask,
                    tags: e.target.value
                      .split(",")
                      .map((tag) => tag.trim())
                      .filter(Boolean),
                  })
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddTaskDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddTask} disabled={!newTask.title}>
              Create Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SharedLayout>
  )
}
