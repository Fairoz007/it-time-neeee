"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { SharedLayout } from "@/components/shared-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LoadingSpinner } from "@/components/loading-spinner"
import { ArrowLeft, AlertCircle } from "lucide-react"
import Link from "next/link"
import { supabase, type Project, updateProject } from "@/lib/supabase-client"
import { toast } from "@/components/ui/use-toast"

export default function ProjectEditPage() {
  const params = useParams()
  const router = useRouter()
  const projectId = params.id as string

  const [project, setProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    status: "active" as Project["status"],
    start_date: "",
    end_date: "",
    estimated_hours: 0,
    actual_hours: 0,
    resource_allocation: 0,
    progress: 0,
    risk_level: "low" as Project["risk_level"],
  })

  useEffect(() => {
    async function fetchProjectData() {
      setLoading(true)
      setError(null)

      try {
        // Fetch project details
        const { data: projectData, error: projectError } = await supabase
          .from("projects")
          .select("*")
          .eq("id", projectId)
          .single()

        if (projectError) throw projectError

        setProject(projectData)

        // Initialize form data
        setFormData({
          name: projectData.name,
          description: projectData.description,
          status: projectData.status,
          start_date: projectData.start_date,
          end_date: projectData.end_date || "",
          estimated_hours: projectData.estimated_hours,
          actual_hours: projectData.actual_hours,
          resource_allocation: projectData.resource_allocation,
          progress: projectData.progress,
          risk_level: projectData.risk_level || "low",
        })
      } catch (err) {
        console.error("Error fetching project data:", err)
        setError("Failed to load project data. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchProjectData()
  }, [projectId])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNumberChange = (name: string, value: string) => {
    const numValue = value === "" ? 0 : Number(value)
    setFormData((prev) => ({ ...prev, [name]: numValue }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate end date is after start date
    if (formData.end_date && formData.start_date && new Date(formData.end_date) <= new Date(formData.start_date)) {
      toast({
        title: "Invalid date range",
        description: "End date must be after start date",
        variant: "destructive",
      })
      return
    }

    // Validate estimated hours is greater than zero
    if (formData.estimated_hours <= 0) {
      toast({
        title: "Invalid value",
        description: "Estimated hours must be greater than zero",
        variant: "destructive",
      })
      return
    }

    setSaving(true)

    try {
      const result = await updateProject(projectId, formData)

      if (!result) {
        throw new Error("Failed to update project")
      }

      toast({
        title: "Project updated",
        description: "Your changes have been saved successfully.",
      })

      // Navigate back to project details
      router.push(`/projects/${projectId}`)
    } catch (err) {
      console.error("Error updating project:", err)
      toast({
        title: "Error",
        description: "Failed to update project. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <SharedLayout>
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <LoadingSpinner className="mx-auto mb-4" />
            <h3 className="text-lg font-medium">Loading project details...</h3>
            <p className="text-sm text-muted-foreground">Please wait while we fetch the project data</p>
          </div>
        </div>
      </SharedLayout>
    )
  }

  if (error || !project) {
    return (
      <SharedLayout>
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium">Error Loading Project</h3>
            <p className="text-sm text-muted-foreground mb-4">{error || "Project not found"}</p>
            <Button variant="outline" onClick={() => router.push("/projects")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Projects
            </Button>
          </div>
        </div>
      </SharedLayout>
    )
  }

  return (
    <SharedLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" asChild>
            <Link href={`/projects/${projectId}`}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Project
            </Link>
          </Button>
        </div>

        <div className="flex flex-col space-y-2">
          <h1 className="text-2xl font-bold md:text-3xl">Edit Project</h1>
          <p className="text-muted-foreground">Update project details and settings</p>
        </div>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>Project Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <label htmlFor="name" className="text-sm font-medium">
                  Project Name
                </label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Project name"
                  required
                />
              </div>

              <div className="grid gap-2">
                <label htmlFor="description" className="text-sm font-medium">
                  Description
                </label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Project description"
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="status" className="text-sm font-medium">
                    Status
                  </label>
                  <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="on_hold">On Hold</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <label htmlFor="risk_level" className="text-sm font-medium">
                    Risk Level
                  </label>
                  <Select
                    value={formData.risk_level || "low"}
                    onValueChange={(value) => handleSelectChange("risk_level", value)}
                  >
                    <SelectTrigger id="risk_level">
                      <SelectValue placeholder="Select risk level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="start_date" className="text-sm font-medium">
                    Start Date
                  </label>
                  <Input
                    id="start_date"
                    name="start_date"
                    type="date"
                    value={formData.start_date}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="grid gap-2">
                  <label htmlFor="end_date" className="text-sm font-medium">
                    End Date
                  </label>
                  <Input
                    id="end_date"
                    name="end_date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => {
                      const newEndDate = e.target.value
                      // Validate that end date is after start date
                      if (newEndDate && formData.start_date && new Date(newEndDate) <= new Date(formData.start_date)) {
                        toast({
                          title: "Invalid date",
                          description: "End date must be after start date",
                          variant: "destructive",
                        })
                      }
                      handleInputChange(e)
                    }}
                  />
                  <p className="text-xs text-muted-foreground">Must be after start date</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="estimated_hours" className="text-sm font-medium">
                    Estimated Hours
                  </label>
                  <Input
                    id="estimated_hours"
                    name="estimated_hours"
                    type="number"
                    min="0.1"
                    step="0.1"
                    value={formData.estimated_hours}
                    onChange={(e) => {
                      const value = Number.parseFloat(e.target.value)
                      if (value <= 0) {
                        toast({
                          title: "Invalid value",
                          description: "Estimated hours must be greater than zero",
                          variant: "destructive",
                        })
                      }
                      handleNumberChange("estimated_hours", e.target.value)
                    }}
                  />
                  <p className="text-xs text-muted-foreground">Must be greater than zero</p>
                </div>

                <div className="grid gap-2">
                  <label htmlFor="actual_hours" className="text-sm font-medium">
                    Actual Hours
                  </label>
                  <Input
                    id="actual_hours"
                    name="actual_hours"
                    type="number"
                    min="0"
                    value={formData.actual_hours}
                    onChange={(e) => handleNumberChange("actual_hours", e.target.value)}
                  />
                </div>

                <div className="grid gap-2">
                  <label htmlFor="resource_allocation" className="text-sm font-medium">
                    Resource Allocation (%)
                  </label>
                  <Input
                    id="resource_allocation"
                    name="resource_allocation"
                    type="number"
                    min="0"
                    max="100"
                    value={formData.resource_allocation}
                    onChange={(e) => handleNumberChange("resource_allocation", e.target.value)}
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <label htmlFor="progress" className="text-sm font-medium">
                  Progress (%)
                </label>
                <Input
                  id="progress"
                  name="progress"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.progress}
                  onChange={(e) => handleNumberChange("progress", e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end space-x-2 mt-4">
            <Button variant="outline" type="button" onClick={() => router.push(`/projects/${projectId}`)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </form>
      </div>
    </SharedLayout>
  )
}
