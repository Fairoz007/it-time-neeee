"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Plus, AlertCircle, MoreHorizontal, Filter, Search } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { SharedLayout } from "@/components/shared-layout"
import { useData } from "@/contexts/data-context"
import { LoadingSpinner } from "@/components/loading-spinner"
import type { Project } from "@/lib/supabase-client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { format } from "date-fns"
import { updateProject } from "@/lib/supabase-client"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase-client"

export default function ProjectsPage() {
  const { projects, loading, error, refreshProjects } = useData()
  const [activeTab, setActiveTab] = useState<"active" | "completed" | "all">("active")
  const [searchQuery, setSearchQuery] = useState("")
  const [isNewProjectDialogOpen, setIsNewProjectDialogOpen] = useState(false)
  const [newProject, setNewProject] = useState({
    name: "",
    description: "",
    status: "active" as Project["status"],
    start_date: format(new Date(), "yyyy-MM-dd"),
    estimated_hours: 0,
    resource_allocation: 0,
  })

  const router = useRouter()

  // Filter projects based on active tab and search query
  const filteredProjects = projects.filter((project) => {
    // Filter by status
    if (activeTab !== "all" && project.status !== activeTab) {
      return false
    }

    // Filter by search query
    if (
      searchQuery &&
      !project.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !project.description.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    return true
  })

  const handleCreateProject = async () => {
    if (!newProject.name) return

    setIsNewProjectDialogOpen(false)

    try {
      // Prepare the project data
      const projectData = {
        ...newProject,
        progress: 0,
        team_members: [],
        actual_hours: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      // Insert the new project into Supabase
      const { data, error } = await supabase.from("projects").insert([projectData]).select()

      if (error) throw error

      toast({
        title: "Project created",
        description: `${newProject.name} has been created successfully.`,
      })

      // Reset form
      setNewProject({
        name: "",
        description: "",
        status: "active",
        start_date: format(new Date(), "yyyy-MM-dd"),
        estimated_hours: 0,
        resource_allocation: 0,
      })

      // Refresh projects
      await refreshProjects()
    } catch (error) {
      console.error("Error creating project:", error)
      toast({
        title: "Error",
        description: "Failed to create project. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Get status badge color
  const getStatusBadge = (status: Project["status"]) => {
    switch (status) {
      case "active":
        return <Badge className="bg-blue-500">Active</Badge>
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>
      case "on_hold":
        return <Badge className="bg-amber-500">On Hold</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  // Get risk level badge
  const getRiskBadge = (risk?: Project["risk_level"]) => {
    switch (risk) {
      case "high":
        return (
          <div className="flex items-center">
            <AlertCircle className="h-3 w-3 text-red-500 mr-1" />
            <p className="text-sm font-medium text-red-500">High</p>
          </div>
        )
      case "medium":
        return (
          <div className="flex items-center">
            <AlertCircle className="h-3 w-3 text-amber-500 mr-1" />
            <p className="text-sm font-medium text-amber-500">Medium</p>
          </div>
        )
      case "low":
        return (
          <div className="flex items-center">
            <AlertCircle className="h-3 w-3 text-green-500 mr-1" />
            <p className="text-sm font-medium text-green-500">Low</p>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <SharedLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Projects</h2>
          <div className="flex items-center space-x-2">
            <Button onClick={() => setIsNewProjectDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              New Project
            </Button>
          </div>
        </div>
        <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div className="flex flex-col space-y-2 md:flex-row md:items-center md:space-x-2 md:space-y-0">
            <div className="relative w-full md:w-[300px]">
              <Input
                placeholder="Search projects..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>
        </div>
        <Tabs
          defaultValue="active"
          value={activeTab}
          onValueChange={(value) => setActiveTab(value as "active" | "completed" | "all")}
          className="space-y-4"
        >
          <TabsList className="w-full sm:w-auto overflow-x-auto">
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="all">All Projects</TabsTrigger>
          </TabsList>
          <TabsContent value={activeTab} className="space-y-4">
            {loading.projects ? (
              <div className="flex justify-center py-8">
                <LoadingSpinner />
              </div>
            ) : error.projects ? (
              <div className="text-center py-8 text-red-500">
                <p>Error loading projects: {error.projects}</p>
                <Button variant="outline" className="mt-4" onClick={refreshProjects}>
                  Retry
                </Button>
              </div>
            ) : filteredProjects.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <p>No projects found</p>
                <Button className="mt-4" onClick={() => setIsNewProjectDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create New Project
                </Button>
              </div>
            ) : (
              filteredProjects.map((project) => (
                <Card key={project.id} className="card-hover-effect">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>{project.name}</CardTitle>
                      <CardDescription>{project.description}</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusBadge(project.status)}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => router.push(`/projects/${project.id}`)}>
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => router.push(`/projects/${project.id}/edit`)}>
                            Edit Project
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => router.push(`/projects/${project.id}/team`)}>
                            Manage Team
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={async () => {
                              try {
                                await updateProject(project.id, {
                                  status: "completed",
                                  progress: 100,
                                  end_date: new Date().toISOString(),
                                })
                                toast({
                                  title: "Project completed",
                                  description: `${project.name} has been marked as completed.`,
                                })
                                refreshProjects()
                              } catch (error) {
                                console.error("Error completing project:", error)
                                toast({
                                  title: "Error",
                                  description: "Failed to mark project as completed.",
                                  variant: "destructive",
                                })
                              }
                            }}
                          >
                            Mark as Completed
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={async () => {
                              try {
                                await updateProject(project.id, { status: "on_hold" })
                                toast({
                                  title: "Project on hold",
                                  description: `${project.name} has been put on hold.`,
                                })
                                refreshProjects()
                              } catch (error) {
                                console.error("Error putting project on hold:", error)
                                toast({
                                  title: "Error",
                                  description: "Failed to put project on hold.",
                                  variant: "destructive",
                                })
                              }
                            }}
                          >
                            Put on Hold
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-medium">{project.progress}%</span>
                        </div>
                        <Progress value={project.progress} />
                      </div>
                      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                        <div className="space-y-1">
                          <span className="text-xs text-muted-foreground">Start Date</span>
                          <p className="text-sm font-medium">{format(new Date(project.start_date), "MMM d, yyyy")}</p>
                        </div>
                        <div className="space-y-1">
                          <span className="text-xs text-muted-foreground">Deadline</span>
                          <p className="text-sm font-medium">
                            {project.end_date ? format(new Date(project.end_date), "MMM d, yyyy") : "Not set"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <span className="text-xs text-muted-foreground">Team</span>
                          <p className="text-sm font-medium">{project.team_members.length} members</p>
                        </div>
                        <div className="space-y-1">
                          <span className="text-xs text-muted-foreground">Tasks</span>
                          <p className="text-sm font-medium">12 (8 completed)</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                        <div className="space-y-1">
                          <span className="text-xs text-muted-foreground">Resource Allocation</span>
                          <p className="text-sm font-medium">{project.resource_allocation}%</p>
                        </div>
                        <div className="space-y-1">
                          <span className="text-xs text-muted-foreground">Estimated Hours</span>
                          <p className="text-sm font-medium">{project.estimated_hours}</p>
                        </div>
                        <div className="space-y-1">
                          <span className="text-xs text-muted-foreground">Hours Tracked</span>
                          <p className="text-sm font-medium">{project.actual_hours}</p>
                        </div>
                        <div className="space-y-1">
                          <span className="text-xs text-muted-foreground">Risk Level</span>
                          {getRiskBadge(project.risk_level)}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* New Project Dialog */}
      <Dialog open={isNewProjectDialogOpen} onOpenChange={setIsNewProjectDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Create New Project</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="name" className="text-sm font-medium">
                Project Name
              </label>
              <Input
                id="name"
                value={newProject.name}
                onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                placeholder="Project name"
              />
            </div>

            <div className="grid gap-2">
              <label htmlFor="description" className="text-sm font-medium">
                Description
              </label>
              <Textarea
                id="description"
                value={newProject.description}
                onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                placeholder="Project description"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label htmlFor="status" className="text-sm font-medium">
                  Status
                </label>
                <Select
                  value={newProject.status}
                  onValueChange={(value) => setNewProject({ ...newProject, status: value as Project["status"] })}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="on_hold">On Hold</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <label htmlFor="start_date" className="text-sm font-medium">
                  Start Date
                </label>
                <Input
                  id="start_date"
                  type="date"
                  value={newProject.start_date}
                  onChange={(e) => setNewProject({ ...newProject, start_date: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label htmlFor="estimated_hours" className="text-sm font-medium">
                  Estimated Hours
                </label>
                <Input
                  id="estimated_hours"
                  type="number"
                  value={newProject.estimated_hours.toString()}
                  onChange={(e) =>
                    setNewProject({ ...newProject, estimated_hours: Number.parseInt(e.target.value) || 0 })
                  }
                />
              </div>

              <div className="grid gap-2">
                <label htmlFor="resource_allocation" className="text-sm font-medium">
                  Resource Allocation (%)
                </label>
                <Input
                  id="resource_allocation"
                  type="number"
                  min="0"
                  max="100"
                  value={newProject.resource_allocation.toString()}
                  onChange={(e) =>
                    setNewProject({ ...newProject, resource_allocation: Number.parseInt(e.target.value) || 0 })
                  }
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNewProjectDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateProject} disabled={!newProject.name}>
              Create Project
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SharedLayout>
  )
}
