import { SharedLayout } from "@/components/shared-layout"

export default function PrivacyPolicyPage() {
  return (
    <SharedLayout>
      <div className="container max-w-4xl py-12">
        <h1 className="mb-8 text-4xl font-bold">Privacy Policy</h1>

        <div className="prose prose-sm dark:prose-invert max-w-none">
          <p className="lead">Last updated: {new Date().toLocaleDateString()}</p>

          <h2>1. Introduction</h2>
          <p>
            DevTimeTracker ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains
            how we collect, use, disclose, and safeguard your information when you use our time management application.
          </p>

          <h2>2. Information We Collect</h2>
          <p>We collect information that you provide directly to us, including:</p>
          <ul>
            <li>Account information (name, email address, password)</li>
            <li>Profile information (job title, department, profile picture)</li>
            <li>Time tracking data (tasks, projects, time entries)</li>
            <li>Communication data (messages, comments, feedback)</li>
            <li>Usage data (features used, interactions with the application)</li>
          </ul>

          <h2>3. How We Use Your Information</h2>
          <p>We use the information we collect to:</p>
          <ul>
            <li>Provide, maintain, and improve our services</li>
            <li>Process and complete transactions</li>
            <li>Send you technical notices, updates, and administrative messages</li>
            <li>Respond to your comments, questions, and requests</li>
            <li>Analyze usage patterns and trends</li>
            <li>Personalize your experience</li>
            <li>Protect against, identify, and prevent fraud and other illegal activity</li>
          </ul>

          <h2>4. Data Security</h2>
          <p>
            We implement appropriate technical and organizational measures to protect the security of your personal
            information. However, please be aware that no security measures are perfect or impenetrable, and we cannot
            guarantee the security of your data.
          </p>

          <h2>5. Data Retention</h2>
          <p>
            We retain your information for as long as your account is active or as needed to provide you services,
            comply with our legal obligations, resolve disputes, and enforce our agreements.
          </p>

          <h2>6. Your Rights</h2>
          <p>Depending on your location, you may have certain rights regarding your personal information, including:</p>
          <ul>
            <li>Access to your personal information</li>
            <li>Correction of inaccurate or incomplete information</li>
            <li>Deletion of your personal information</li>
            <li>Restriction or objection to processing</li>
            <li>Data portability</li>
            <li>Withdrawal of consent</li>
          </ul>

          <h2>7. Changes to This Privacy Policy</h2>
          <p>
            We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new
            Privacy Policy on this page and updating the "Last updated" date.
          </p>

          <h2>8. Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at:
            <br />
            Email: privacy@devtimetracker.com
            <br />
            Address: 123 Tech Street, Suite 456, San Francisco, CA 94105
          </p>
        </div>
      </div>
    </SharedLayout>
  )
}
