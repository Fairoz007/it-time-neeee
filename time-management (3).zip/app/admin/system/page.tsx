"use client"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"
import { SharedLayout } from "@/components/shared-layout"
import { AdminOnly } from "@/components/role-based-access"
import { useRouter } from "next/navigation"

export default function AdminSystemPage() {
  const router = useRouter()
  return (
    <AdminOnly
      fallback={
        <div className="flex min-h-screen items-center justify-center">
          <div className="text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <h3 className="text-lg font-medium">Access Denied</h3>
            <p className="text-sm text-muted-foreground mb-4">You don't have permission to access this page</p>
            <Button variant="outline" onClick={() => router.push("/dashboard")}>
              Back to Dashboard
            </Button>
          </div>
        </div>
      }
    >
      <SharedLayout>
        <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          <div className="flex items-center justify-between space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">System Settings</h2>
          </div>
        </div>
      </SharedLayout>
    </AdminOnly>
  )
}
