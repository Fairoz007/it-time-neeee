"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Users,
  Settings,
  BarChart2,
  Clock,
  Shield,
  Server,
  Activity,
  Download,
  UserPlus,
  CheckCircle,
  XCircle,
} from "lucide-react"
import { SharedLayout } from "@/components/shared-layout"
import { LoadingSpinner } from "@/components/loading-spinner"
import { supabase } from "@/lib/supabase-client"
import { toast } from "@/components/ui/use-toast"
import { Progress } from "@/components/ui/progress"
import { AnimatedCounter } from "@/components/ui/animated-counter"

export default function AdminDashboardPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalProjects: 0,
    totalTasks: 0,
    completedTasks: 0,
    systemHealth: 98,
    storageUsed: 42,
  })
  const [recentUsers, setRecentUsers] = useState<any[]>([])
  const [recentActivity, setRecentActivity] = useState<any[]>([])

  useEffect(() => {
    const fetchAdminData = async () => {
      setLoading(true)
      try {
        // Fetch user count
        const { count: userCount, error: userError } = await supabase
          .from("profiles")
          .select("*", { count: "exact", head: true })

        if (userError) throw userError

        // Fetch project count
        const { count: projectCount, error: projectError } = await supabase
          .from("projects")
          .select("*", { count: "exact", head: true })

        if (projectError) throw projectError

        // Fetch task counts
        const { count: taskCount, error: taskError } = await supabase
          .from("tasks")
          .select("*", { count: "exact", head: true })

        if (taskError) throw taskError

        const { count: completedTaskCount, error: completedTaskError } = await supabase
          .from("tasks")
          .select("*", { count: "exact", head: true })
          .eq("status", "completed")

        if (completedTaskError) throw completedTaskError

        // Fetch recent users
        const { data: recentUsersData, error: recentUsersError } = await supabase
          .from("profiles")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(5)

        if (recentUsersError) throw recentUsersError

        // Fetch recent activity from the database
        const { data: activityData, error: activityError } = await supabase
          .from("activity_log")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(5)

        // Set the stats
        setStats({
          totalUsers: userCount || 0,
          activeUsers: Math.floor((userCount || 0) * 0.7), // Simulate active users
          totalProjects: projectCount || 0,
          totalTasks: taskCount || 0,
          completedTasks: completedTaskCount || 0,
          systemHealth: 98, // Simulated
          storageUsed: 42, // Simulated
        })

        // Set recent users
        setRecentUsers(recentUsersData || [])

        // Set recent activity from database or use fallback data
        if (activityData && activityData.length > 0) {
          setRecentActivity(activityData)
        } else {
          // Fallback activity data
          setRecentActivity([
            {
              id: 1,
              user: "John Doe",
              action: "created a new project",
              target: "API Integration",
              time: "5 minutes ago",
              type: "create",
            },
            {
              id: 2,
              user: "Sarah Smith",
              action: "completed a task",
              target: "Fix authentication bug",
              time: "15 minutes ago",
              type: "complete",
            },
            {
              id: 3,
              user: "Alex Johnson",
              action: "updated project status",
              target: "Frontend Development",
              time: "1 hour ago",
              type: "update",
            },
            { id: 4, user: "Emily Chen", action: "joined the team", target: "", time: "3 hours ago", type: "join" },
            {
              id: 5,
              user: "Michael Brown",
              action: "deleted a task",
              target: "Outdated requirement",
              time: "5 hours ago",
              type: "delete",
            },
          ])
        }
      } catch (error) {
        console.error("Error fetching admin data:", error)
        toast({
          title: "Error",
          description: "Failed to load admin dashboard data",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchAdminData()
  }, [])

  // Get activity icon based on type
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "create":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "complete":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "update":
        return <Activity className="h-4 w-4 text-blue-500" />
      case "join":
        return <UserPlus className="h-4 w-4 text-purple-500" />
      case "delete":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  // Handle edit user click
  const handleEditUser = (userId: string) => {
    router.push(`/admin/users/edit/${userId}`)
  }

  return (
    <SharedLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Admin Dashboard</h2>
          <div className="flex items-center space-x-2">
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Download Report
            </Button>
            <Button onClick={() => router.push("/admin/system")}>
              <Settings className="mr-2 h-4 w-4" />
              System Settings
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-8">
            <LoadingSpinner />
          </div>
        ) : (
          <>
            {/* Stats Overview */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    <AnimatedCounter value={stats.totalUsers} />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    <AnimatedCounter value={stats.activeUsers} /> active in last 30 days
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Projects</CardTitle>
                  <BarChart2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    <AnimatedCounter value={stats.totalProjects} />
                  </div>
                  <p className="text-xs text-muted-foreground">Across {Math.ceil(stats.totalUsers * 0.6)} teams</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Task Completion</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    <AnimatedCounter
                      value={stats.totalTasks ? Math.round((stats.completedTasks / stats.totalTasks) * 100) : 0}
                      formatter={(value) => `${value}%`}
                    />
                  </div>
                  <div className="mt-2">
                    <Progress value={stats.totalTasks ? (stats.completedTasks / stats.totalTasks) * 100 : 0} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">System Health</CardTitle>
                  <Shield className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    <AnimatedCounter value={stats.systemHealth} formatter={(value) => `${value}%`} />
                  </div>
                  <div className="mt-2">
                    <Progress
                      value={stats.systemHealth}
                      className={stats.systemHealth > 90 ? "bg-green-100" : "bg-amber-100"}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              {/* Recent Users */}
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Recent Users</CardTitle>
                  <CardDescription>New users that have joined recently</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentUsers.length === 0 ? (
                      <div className="text-center py-4 text-muted-foreground">
                        <p>No recent users found</p>
                      </div>
                    ) : (
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>User</TableHead>
                              <TableHead>Role</TableHead>
                              <TableHead>Joined</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {recentUsers.map((user) => (
                              <TableRow key={user.id}>
                                <TableCell className="font-medium">
                                  <div className="flex items-center">
                                    <Avatar className="h-8 w-8 mr-2">
                                      <AvatarImage src={user.avatar_url || "/placeholder.svg"} alt={user.full_name} />
                                      <AvatarFallback>{getUserInitials(user.full_name)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <div className="font-medium">{user.full_name || "User"}</div>
                                      <div className="text-xs text-muted-foreground">{user.email}</div>
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge variant={user.role === "admin" ? "default" : "outline"}>
                                    {user.role || "user"}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  {user.created_at ? new Date(user.created_at).toLocaleDateString() : "Unknown"}
                                </TableCell>
                                <TableCell>
                                  <Button variant="ghost" size="sm" onClick={() => handleEditUser(user.id)}>
                                    Edit
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                    <Button variant="outline" className="w-full" onClick={() => router.push("/admin/users")}>
                      View All Users
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest actions across the platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity.length === 0 ? (
                      <div className="text-center py-4 text-muted-foreground">
                        <p>No recent activity found</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {recentActivity.map((activity) => (
                          <div key={activity.id} className="flex items-start space-x-4">
                            <div className="mt-0.5">{getActivityIcon(activity.type)}</div>
                            <div className="space-y-1">
                              <p className="text-sm">
                                <span className="font-medium">{activity.user}</span> {activity.action}
                                {activity.target && <span className="font-medium"> {activity.target}</span>}
                              </p>
                              <p className="text-xs text-muted-foreground">{activity.time}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    <Button variant="outline" className="w-full" onClick={() => router.push("/admin/activity")}>
                      View All Activity
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* System Status */}
            <Card>
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>Current system performance and resource usage</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">CPU Usage</span>
                        <span className="text-sm text-muted-foreground">24%</span>
                      </div>
                      <Progress value={24} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Memory Usage</span>
                        <span className="text-sm text-muted-foreground">38%</span>
                      </div>
                      <Progress value={38} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Storage Usage</span>
                        <span className="text-sm text-muted-foreground">{stats.storageUsed}%</span>
                      </div>
                      <Progress value={stats.storageUsed} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Network</span>
                        <span className="text-sm text-muted-foreground">17%</span>
                      </div>
                      <Progress value={17} className="h-2" />
                    </div>
                  </div>

                  <div className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Server className="h-5 w-5 text-muted-foreground" />
                        <span className="font-medium">Database Status</span>
                      </div>
                      <Badge className="bg-green-500">Healthy</Badge>
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Connections:</span> 24/100
                      </div>
                      <div>
                        <span className="text-muted-foreground">Query Time:</span> 42ms avg
                      </div>
                      <div>
                        <span className="text-muted-foreground">Size:</span> 256MB
                      </div>
                      <div>
                        <span className="text-muted-foreground">Last Backup:</span> 2 hours ago
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </SharedLayout>
  )
}
