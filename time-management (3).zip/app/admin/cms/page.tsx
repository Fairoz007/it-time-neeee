"use client"

import { useState } from "react"
import { SharedLayout } from "@/components/shared-layout"
import { ContentEditor } from "@/components/cms/content-editor"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Plus, Edit, Trash2, MoreHorizontal, Eye, FileDown, Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"

// Mock content data
const mockContent = [
  {
    id: "1",
    title: "Getting Started with DevTimeTracker",
    slug: "getting-started",
    description: "Learn how to set up and use DevTimeTracker effectively",
    author: "John Doe",
    status: "published",
    type: "documentation",
    publishDate: "2025-04-15",
    updatedDate: "2025-05-01",
    tags: ["guide", "onboarding"],
  },
  {
    id: "2",
    title: "Advanced Time Tracking Techniques",
    slug: "advanced-time-tracking",
    description: "Master advanced features for better productivity",
    author: "Jane Smith",
    status: "published",
    type: "documentation",
    publishDate: "2025-04-20",
    updatedDate: "2025-04-20",
    tags: ["advanced", "productivity"],
  },
  {
    id: "3",
    title: "May 2025 Product Updates",
    slug: "may-2025-updates",
    description: "New features and improvements in the May release",
    author: "Alex Johnson",
    status: "draft",
    type: "post",
    publishDate: "2025-05-10",
    updatedDate: "2025-05-05",
    tags: ["updates", "features"],
  },
  {
    id: "4",
    title: "Privacy Policy",
    slug: "privacy-policy",
    description: "Our privacy policy and data handling practices",
    author: "Legal Team",
    status: "published",
    type: "page",
    publishDate: "2025-01-01",
    updatedDate: "2025-04-10",
    tags: ["legal", "policy"],
  },
  {
    id: "5",
    title: "Integrating with Third-Party Tools",
    slug: "third-party-integrations",
    description: "How to connect DevTimeTracker with other tools",
    author: "Michael Chen",
    status: "archived",
    type: "documentation",
    publishDate: "2024-11-15",
    updatedDate: "2025-03-20",
    tags: ["integrations", "api"],
  },
]

export default function CMSPage() {
  const [content, setContent] = useState(mockContent)
  const [searchQuery, setSearchQuery] = useState("")
  const [isCreating, setIsCreating] = useState(false)
  const [isEditing, setIsEditing] = useState<string | null>(null)
  const [selectedType, setSelectedType] = useState<"all" | "page" | "post" | "documentation">("all")

  // Filter content based on search query and type
  const filteredContent = content.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesType = selectedType === "all" || item.type === selectedType

    return matchesSearch && matchesType
  })

  // Handle content creation
  const handleCreateContent = (content: string, metadata: any) => {
    const newItem = {
      id: `${Date.now()}`,
      title: metadata.title,
      slug: metadata.slug,
      description: metadata.description,
      author: metadata.author,
      status: metadata.status,
      type: metadata.type || "page",
      publishDate: metadata.publishDate,
      updatedDate: new Date().toISOString().split("T")[0],
      tags: metadata.tags,
    }

    setContent((prev) => [...prev, newItem])
    setIsCreating(false)
  }

  // Handle content update
  const handleUpdateContent = (id: string, content: string, metadata: any) => {
    setContent((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              title: metadata.title,
              slug: metadata.slug,
              description: metadata.description,
              author: metadata.author,
              status: metadata.status,
              publishDate: metadata.publishDate,
              updatedDate: new Date().toISOString().split("T")[0],
              tags: metadata.tags,
            }
          : item,
      ),
    )

    setIsEditing(null)
  }

  // Handle content deletion
  const handleDeleteContent = (id: string) => {
    setContent((prev) => prev.filter((item) => item.id !== id))
  }

  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "published":
        return "bg-green-500"
      case "draft":
        return "bg-yellow-500"
      case "archived":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <SharedLayout>
      <div className="container py-8">
        <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Content Management</h1>
            <p className="text-muted-foreground">Manage website content, blog posts, and documentation</p>
          </div>
          <div className="flex items-center space-x-2">
            <Dialog open={isCreating} onOpenChange={setIsCreating}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Content
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle>Create New Content</DialogTitle>
                  <DialogDescription>Create a new page, blog post, or documentation</DialogDescription>
                </DialogHeader>
                <ContentEditor onSave={handleCreateContent} />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="mt-6 space-y-4">
          <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
            <Tabs
              defaultValue="all"
              value={selectedType}
              onValueChange={(value) => setSelectedType(value as any)}
              className="w-full md:w-auto"
            >
              <TabsList>
                <TabsTrigger value="all">All Content</TabsTrigger>
                <TabsTrigger value="page">Pages</TabsTrigger>
                <TabsTrigger value="post">Blog Posts</TabsTrigger>
                <TabsTrigger value="documentation">Documentation</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="relative w-full md:w-[300px]">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search content..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Author</TableHead>
                    <TableHead>Last Updated</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredContent.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <FileText className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
                        <p className="mt-2 text-muted-foreground">No content found</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-4"
                          onClick={() => {
                            setSearchQuery("")
                            setSelectedType("all")
                          }}
                        >
                          Clear filters
                        </Button>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredContent.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div className="font-medium">{item.title}</div>
                          <div className="text-sm text-muted-foreground">{item.slug}</div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.type.charAt(0).toUpperCase() + item.type.slice(1)}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(item.status)}>
                            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell>{item.author}</TableCell>
                        <TableCell>{format(new Date(item.updatedDate), "MMM d, yyyy")}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => setIsEditing(item.id)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                View
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <FileDown className="mr-2 h-4 w-4" />
                                Export
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteContent(item.id)}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>

                          <Dialog open={isEditing === item.id} onOpenChange={(open) => !open && setIsEditing(null)}>
                            <DialogContent className="max-w-4xl">
                              <DialogHeader>
                                <DialogTitle>Edit Content</DialogTitle>
                                <DialogDescription>
                                  Edit {item.type}: {item.title}
                                </DialogDescription>
                              </DialogHeader>
                              <ContentEditor
                                initialContent="This is the content of the page. In a real application, this would be loaded from the database."
                                onSave={(content, metadata) => handleUpdateContent(item.id, content, metadata)}
                                contentType={item.type as any}
                              />
                            </DialogContent>
                          </Dialog>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </SharedLayout>
  )
}
