// Environment variables with fallbacks for development
export const env = {
  NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL || "https://rwfzorhmynhkcoottxuo.supabase.co",
  NEXT_PUBLIC_SUPABASE_ANON_KEY:
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ3ZnpvcmhteW5oa2Nvb3R0eHVvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQyMjYxMTYsImV4cCI6MjA1OTgwMjExNn0.hbvqGNTxPAQ2sV0VD4QxSRI7i-7i0lpjOOlFneK8L9Y",
  NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL || "https://devtimetracker.com",
}

// Log environment variables for debugging (only in development)
if (typeof window !== "undefined" && process.env.NODE_ENV === "development") {
  console.log("Environment variables:", {
    SUPABASE_URL: env.NEXT_PUBLIC_SUPABASE_URL ? "Set" : "Missing",
    SUPABASE_KEY: env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "Set" : "Missing",
    SITE_URL: env.NEXT_PUBLIC_SITE_URL,
  })
}
