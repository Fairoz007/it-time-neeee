"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { SharedLayout } from "@/components/shared-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { TaskComments } from "@/components/task-comments"
import {
  Clock,
  CheckSquare,
  AlertCircle,
  Calendar,
  LinkIcon,
  ArrowLeft,
  Play,
  Pause,
  Edit,
  ChevronDown,
} from "lucide-react"
import Link from "next/link"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { supabase, type Task, type Project } from "@/lib/supabase-client"
import { format } from "date-fns"
import { toast } from "@/components/ui/use-toast"
import { LoadingSpinner } from "@/components/loading-spinner"
import { useTimeTracking } from "@/hooks/use-time-tracking"

export default function TaskDetailPage() {
  const params = useParams()
  const router = useRouter()
  const taskId = params.id as string

  const { isTracking, elapsedTime, formatElapsedTime, startTracking, stopTracking, activeEntry } = useTimeTracking()

  const [task, setTask] = useState<Task | null>(null)
  const [project, setProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [notes, setNotes] = useState("")

  useEffect(() => {
    async function fetchTaskData() {
      setLoading(true)
      setError(null)

      try {
        let taskData
        let projectData

        try {
          // Try to fetch task details from Supabase
          const { data, error } = await supabase.from("tasks").select("*").eq("id", taskId).single()

          if (error) throw error
          taskData = data

          // Fetch project details if we have a project_id
          if (taskData.project_id) {
            const { data: projData, error: projectError } = await supabase
              .from("projects")
              .select("*")
              .eq("id", taskData.project_id)
              .single()

            if (!projectError) {
              projectData = projData
            }
          }
        } catch (supabaseError) {
          console.warn("Supabase query failed, using mock data instead:", supabaseError.message)

          // Provide mock data for demonstration purposes
          taskData = {
            id: taskId,
            title: `Task ${taskId}`,
            description:
              "This is a mock task created because the database query failed. In a production environment, you would ensure proper UUID formatting for database queries.",
            priority: "medium",
            status: "in_progress",
            due_date: new Date().toISOString().split("T")[0],
            project_id: "mock-project-1",
            tags: ["mock", "example"],
            assignee_id: "default-user",
            dependencies: [],
            blocking: [],
            estimated_hours: 8,
            actual_hours: 2.5,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }

          projectData = {
            id: "mock-project-1",
            name: "Mock Project",
            description: "This is a mock project",
            status: "active",
            start_date: new Date().toISOString().split("T")[0],
            end_date: null,
            progress: 35,
            team_members: ["John Doe", "Sarah Smith"],
            resource_allocation: 75,
            estimated_hours: 120,
            actual_hours: 42,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            risk_level: "medium",
          }
        }

        setTask(taskData)
        if (projectData) {
          setProject(projectData)
        }

        // Check for active time entry
        try {
          const { data: timeEntryData, error: timeEntryError } = await supabase
            .from("time_entries")
            .select("*")
            .eq("task_id", taskId)
            .is("end_time", null)
            .order("start_time", { ascending: false })
            .limit(1)
            .single()
        } catch (timeEntryError) {
          console.warn("Error fetching time entries:", timeEntryError)
        }
      } catch (err) {
        console.error("Error fetching task data:", err)
        setError("Failed to load task data. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchTaskData()
  }, [taskId])

  const handleStartTimer = async () => {
    if (isTracking) return

    if (!task) return

    await startTracking({
      taskId: task.id,
      projectId: task.project_id,
      taskTitle: task.title,
      projectName: project?.name,
    })
  }

  const handleStopTimer = async () => {
    if (!isTracking) return

    await stopTracking(notes)
    setNotes("")
  }

  const handleResetTimer = () => {
    setNotes("")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "todo":
        return "bg-gray-500"
      case "in_progress":
        return "bg-blue-500"
      case "completed":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-500"
      case "high":
        return "bg-amber-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return format(date, "MMM d, yyyy, h:mm a")
  }

  const calculateProgress = () => {
    if (!task) return 0
    if (task.estimated_hours === 0) return 0
    return Math.min(100, Math.round((task.actual_hours / task.estimated_hours) * 100))
  }

  if (loading) {
    return (
      <SharedLayout>
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <LoadingSpinner className="mx-auto mb-4" />
            <h3 className="text-lg font-medium">Loading task details...</h3>
            <p className="text-sm text-muted-foreground">Please wait while we fetch the task data</p>
          </div>
        </div>
      </SharedLayout>
    )
  }

  if (error || !task) {
    return (
      <SharedLayout>
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium">Error Loading Task</h3>
            <p className="text-sm text-muted-foreground mb-4">{error || "Task not found"}</p>
            <Button variant="outline" onClick={() => router.push("/tasks")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Tasks
            </Button>
          </div>
        </div>
      </SharedLayout>
    )
  }

  return (
    <SharedLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/tasks">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Tasks
            </Link>
          </Button>
        </div>

        <div className="flex flex-col space-y-2 md:flex-row md:items-start md:justify-between md:space-y-0">
          <div>
            <h1 className="text-2xl font-bold md:text-3xl">{task.title}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <Badge className={getStatusColor(task.status)}>
                {task.status === "todo" ? "To Do" : task.status === "in_progress" ? "In Progress" : "Completed"}
              </Badge>
              <Badge className={getPriorityColor(task.priority)}>
                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
              </Badge>
              {project && (
                <Badge variant="outline" asChild>
                  <Link href={`/projects/${project.id}`}>{project.name}</Link>
                </Badge>
              )}
              {task.tags.map((tag) => (
                <Badge key={tag} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              variant={isTracking ? "destructive" : "default"}
              onClick={isTracking ? handleStopTimer : handleStartTimer}
            >
              {isTracking ? (
                <>
                  <Pause className="mr-2 h-4 w-4" />
                  {formatElapsedTime()}
                </>
              ) : (
                <>
                  <Play className="mr-2 h-4 w-4" />
                  Start Timer
                </>
              )}
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Actions
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Task Actions</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => router.push(`/tasks/${task.id}/edit`)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Task
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={async () => {
                    try {
                      await supabase.from("tasks").update({ status: "completed" }).eq("id", task.id)

                      toast({
                        title: "Task completed",
                        description: "Task has been marked as completed.",
                      })

                      // Update local state
                      setTask({
                        ...task,
                        status: "completed",
                      })
                    } catch (err) {
                      console.error("Error completing task:", err)
                      toast({
                        title: "Error",
                        description: "Failed to mark task as completed.",
                        variant: "destructive",
                      })
                    }
                  }}
                >
                  <CheckSquare className="mr-2 h-4 w-4" />
                  Mark as Completed
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <div className="md:col-span-2 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Details</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-line">{task.description}</p>

                <div className="mt-6 space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Progress</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">{calculateProgress()}% Complete</span>
                      <span className="text-sm text-muted-foreground">
                        {task.actual_hours.toFixed(1)} / {task.estimated_hours} hours
                      </span>
                    </div>
                    <Progress value={calculateProgress()} />
                  </div>

                  {(task.dependencies.length > 0 || task.blocking.length > 0) && (
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">Dependencies</h3>

                      {task.dependencies.length > 0 && (
                        <div className="space-y-1">
                          <h4 className="text-xs text-muted-foreground">This task depends on:</h4>
                          <ul className="space-y-1">
                            {task.dependencies.map((dep) => (
                              <li key={dep} className="flex items-center text-sm">
                                <CheckSquare className="mr-2 h-4 w-4 text-green-500" />
                                <Link href={`/tasks/${dep}`} className="hover:underline">
                                  {dep}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {task.blocking.length > 0 && (
                        <div className="space-y-1 mt-2">
                          <h4 className="text-xs text-muted-foreground">This task is blocking:</h4>
                          <ul className="space-y-1">
                            {task.blocking.map((block) => (
                              <li key={block} className="flex items-center text-sm">
                                <AlertCircle className="mr-2 h-4 w-4 text-amber-500" />
                                <Link href={`/tasks/${block}`} className="hover:underline">
                                  {block}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="comments" className="space-y-4">
              <TabsList>
                <TabsTrigger value="comments">Comments</TabsTrigger>
                <TabsTrigger value="activity">Activity</TabsTrigger>
                <TabsTrigger value="time">Time Tracking</TabsTrigger>
              </TabsList>

              <TabsContent value="comments">
                <Card>
                  <CardContent className="pt-6">
                    <TaskComments taskId={taskId} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="activity">
                <Card>
                  <CardHeader>
                    <CardTitle>Activity Log</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8 text-muted-foreground">
                      <p>Activity log will be displayed here</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="time">
                <Card>
                  <CardHeader>
                    <CardTitle>Time Tracking</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="flex flex-col space-y-2 md:flex-row md:items-center md:justify-between md:space-y-0">
                        <div>
                          <h3 className="text-2xl font-bold">{formatElapsedTime()}</h3>
                          <p className="text-sm text-muted-foreground">Total time tracked</p>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            variant={isTracking ? "destructive" : "default"}
                            onClick={isTracking ? handleStopTimer : handleStartTimer}
                          >
                            {isTracking ? (
                              <>
                                <Pause className="mr-2 h-4 w-4" />
                                Pause
                              </>
                            ) : (
                              <>
                                <Play className="mr-2 h-4 w-4" />
                                Start
                              </>
                            )}
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-sm font-medium">Add Notes</h3>
                        <Textarea
                          placeholder="What are you working on?"
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          className="min-h-[100px]"
                        />
                        <div className="flex justify-end">
                          <Button onClick={handleStopTimer} disabled={!isTracking}>
                            Save Time Entry
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-sm font-medium">Time Entries</h3>
                        <div className="rounded-md border">
                          <div className="grid grid-cols-4 border-b bg-muted/50 p-3 text-sm font-medium">
                            <div>Date</div>
                            <div>Duration</div>
                            <div>User</div>
                            <div>Notes</div>
                          </div>
                          <div className="grid grid-cols-4 border-b p-3 text-sm">
                            <div>May 10, 2025</div>
                            <div>1.5 hours</div>
                            <div>John Doe</div>
                            <div>Investigating token validation issue</div>
                          </div>
                          <div className="grid grid-cols-4 p-3 text-sm">
                            <div>May 9, 2025</div>
                            <div>1.0 hour</div>
                            <div>John Doe</div>
                            <div>Initial debugging</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Task Info</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h3 className="text-sm text-muted-foreground">Assignee</h3>
                    <div className="flex items-center space-x-2">
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                        {task.assignee_id.substring(0, 2).toUpperCase()}
                      </div>
                      <span>{task.assignee_id}</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-sm text-muted-foreground">Status</h3>
                    <Select defaultValue={task.status}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todo">To Do</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-sm text-muted-foreground">Priority</h3>
                    <Select defaultValue={task.priority}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-sm text-muted-foreground">Due Date</h3>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{format(new Date(task.due_date), "MMM d, yyyy")}</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-sm text-muted-foreground">Project</h3>
                    <div className="flex items-center space-x-2">
                      <LinkIcon className="h-4 w-4 text-muted-foreground" />
                      {project ? (
                        <Link href={`/projects/${project.id}`} className="hover:underline">
                          {project.name}
                        </Link>
                      ) : (
                        <span>Not assigned</span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-sm text-muted-foreground">Estimated Time</h3>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{task.estimated_hours} hours</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-sm text-muted-foreground">Time Tracked</h3>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>{task.actual_hours.toFixed(1)} hours</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Related Tasks</CardTitle>
              </CardHeader>
              <CardContent>
                {task.dependencies.length === 0 && task.blocking.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    <p>No related tasks</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {[...task.dependencies, ...task.blocking].map((relatedTaskId) => (
                      <div key={relatedTaskId} className="rounded-md border p-3 transition-colors hover:bg-muted/50">
                        <Link href={`/tasks/${relatedTaskId}`} className="block hover:underline">
                          <h4 className="font-medium">{relatedTaskId}</h4>
                        </Link>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </SharedLayout>
  )
}
