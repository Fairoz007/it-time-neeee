"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { SharedLayout } from "@/components/shared-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LoadingSpinner } from "@/components/loading-spinner"
import { ArrowLeft, AlertCircle } from "lucide-react"
import Link from "next/link"
import { supabase, type Task, updateTask } from "@/lib/supabase-client"
import { toast } from "@/components/ui/use-toast"
import { format } from "date-fns"

export default function TaskEditPage() {
  const params = useParams()
  const router = useRouter()
  const taskId = params.id as string

  const [task, setTask] = useState<Task | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    priority: "medium" as Task["priority"],
    status: "todo" as Task["status"],
    due_date: format(new Date(), "yyyy-MM-dd"),
    estimated_hours: 0,
    tags: [] as string[],
    dependencies: [] as string[],
    blocking: [],
  })

  useEffect(() => {
    async function fetchTaskData() {
      setLoading(true)
      setError(null)

      try {
        // Fetch task details
        const { data: taskData, error: taskError } = await supabase.from("tasks").select("*").eq("id", taskId).single()

        if (taskError) throw taskError

        setTask(taskData)

        // Initialize form data
        setFormData({
          title: taskData.title,
          description: taskData.description,
          priority: taskData.priority,
          status: taskData.status,
          due_date: taskData.due_date,
          estimated_hours: taskData.estimated_hours,
          tags: taskData.tags,
          dependencies: taskData.dependencies,
          blocking: taskData.blocking,
        })
      } catch (err) {
        console.error("Error fetching task data:", err)
        setError("Failed to load task data. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchTaskData()
  }, [taskId])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNumberChange = (name: string, value: string) => {
    const numValue = value === "" ? 0 : Number(value)
    setFormData((prev) => ({ ...prev, [name]: numValue }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)

    try {
      const result = await updateTask(taskId, formData)

      if (!result) {
        throw new Error("Failed to update task")
      }

      toast({
        title: "Task updated",
        description: "Your changes have been saved successfully.",
      })

      // Navigate back to task details
      router.push(`/tasks/${taskId}`)
    } catch (err) {
      console.error("Error updating task:", err)
      toast({
        title: "Error",
        description: "Failed to update task. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <SharedLayout>
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <LoadingSpinner className="mx-auto mb-4" />
            <h3 className="text-lg font-medium">Loading task details...</h3>
            <p className="text-sm text-muted-foreground">Please wait while we fetch the task data</p>
          </div>
        </div>
      </SharedLayout>
    )
  }

  if (error || !task) {
    return (
      <SharedLayout>
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium">Error Loading Task</h3>
            <p className="text-sm text-muted-foreground mb-4">{error || "Task not found"}</p>
            <Button variant="outline" onClick={() => router.push("/tasks")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Tasks
            </Button>
          </div>
        </div>
      </SharedLayout>
    )
  }

  return (
    <SharedLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" asChild>
            <Link href={`/tasks/${taskId}`}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Task
            </Link>
          </Button>
        </div>

        <div className="flex flex-col space-y-2">
          <h1 className="text-2xl font-bold md:text-3xl">Edit Task</h1>
          <p className="text-muted-foreground">Update task details and settings</p>
        </div>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>Task Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <label htmlFor="title" className="text-sm font-medium">
                  Title
                </label>
                <Input
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="Task title"
                  required
                />
              </div>

              <div className="grid gap-2">
                <label htmlFor="description" className="text-sm font-medium">
                  Description
                </label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Task description"
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="priority" className="text-sm font-medium">
                    Priority
                  </label>
                  <Select value={formData.priority} onValueChange={(value) => handleSelectChange("priority", value)}>
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <label htmlFor="status" className="text-sm font-medium">
                    Status
                  </label>
                  <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todo">To Do</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-2">
                <label htmlFor="due_date" className="text-sm font-medium">
                  Due Date
                </label>
                <Input
                  id="due_date"
                  name="due_date"
                  type="date"
                  value={formData.due_date}
                  onChange={handleInputChange}
                />
              </div>

              <div className="grid gap-2">
                <label htmlFor="estimated_hours" className="text-sm font-medium">
                  Estimated Hours
                </label>
                <Input
                  id="estimated_hours"
                  name="estimated_hours"
                  type="number"
                  min="0"
                  value={formData.estimated_hours}
                  onChange={(e) => handleNumberChange("estimated_hours", e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end space-x-2 mt-4">
            <Button variant="outline" type="button" onClick={() => router.push(`/tasks/${taskId}`)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </form>
      </div>
    </SharedLayout>
  )
}
