"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CheckSquare, AlertCircle, Plus, GitBranch, Clock, Users, LinkIcon } from "lucide-react"
import { Separator } from "@/components/ui/separator"
import { SharedLayout } from "@/components/shared-layout"
import { supabase } from "@/lib/supabase-client"
import { LoadingSpinner } from "@/components/loading-spinner"
import { format } from "date-fns"
import { useRouter } from "next/navigation"

// Task type definition
interface Task {
  id: string
  title: string
  description: string
  priority: "low" | "medium" | "high" | "critical"
  status: "todo" | "in_progress" | "completed"
  due_date: string
  project_id: string
  tags: string[]
  assignee_id: string
  dependencies: string[]
  blocking: string[]
  estimated_hours: number
  actual_hours: number
  created_at: string
  updated_at: string
}

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("all")
  const router = useRouter()

  // Fetch tasks from the database
  useEffect(() => {
    async function fetchTasks() {
      setLoading(true)
      setError(null)

      try {
        const { data, error } = await supabase.from("tasks").select("*").order("due_date", { ascending: true })

        if (error) throw error

        setTasks(data || [])
      } catch (err) {
        console.error("Error fetching tasks:", err)
        setError("Failed to load tasks. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchTasks()
  }, [])

  // Filter tasks based on active tab
  const getFilteredTasks = () => {
    switch (activeTab) {
      case "today":
        const today = new Date().toISOString().split("T")[0]
        return tasks.filter((task) => task.due_date === today)
      case "upcoming":
        const tomorrow = new Date()
        tomorrow.setDate(tomorrow.getDate() + 1)
        const nextWeek = new Date()
        nextWeek.setDate(nextWeek.getDate() + 7)
        return tasks.filter((task) => new Date(task.due_date) >= tomorrow && new Date(task.due_date) <= nextWeek)
      case "completed":
        return tasks.filter((task) => task.status === "completed")
      case "dependencies":
        return tasks.filter((task) => task.dependencies.length > 0 || task.blocking.length > 0)
      default:
        return tasks
    }
  }

  // Get high priority tasks
  const getHighPriorityTasks = () => {
    return getFilteredTasks().filter((task) => task.priority === "high" || task.priority === "critical")
  }

  // Get medium priority tasks
  const getMediumPriorityTasks = () => {
    return getFilteredTasks().filter((task) => task.priority === "medium")
  }

  // Get low priority tasks
  const getLowPriorityTasks = () => {
    return getFilteredTasks().filter((task) => task.priority === "low")
  }

  // Get priority badge color
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-100"
      case "high":
        return "bg-red-100"
      case "medium":
        return "bg-amber-100"
      case "low":
        return "bg-green-100"
      default:
        return "bg-gray-100"
    }
  }

  // Get priority text color
  const getPriorityTextColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "text-red-600"
      case "high":
        return "text-red-600"
      case "medium":
        return "text-amber-600"
      case "low":
        return "text-green-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <SharedLayout>
      <div className="flex-1 space-y-6 p-6 md:p-8 lg:p-10">
        {/* Page Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Tasks</h1>
            <p className="text-muted-foreground mt-1">Manage and track your team's tasks</p>
          </div>
        </div>

        <Separator />

        {/* Filters Section */}

        {/* Tabs Section */}
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <div className="overflow-x-auto">
            <TabsList className="w-full justify-start border-b p-0 h-auto">
              <TabsTrigger
                value="all"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                All Tasks
              </TabsTrigger>
              <TabsTrigger
                value="today"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Today
              </TabsTrigger>
              <TabsTrigger
                value="upcoming"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Upcoming
              </TabsTrigger>
              <TabsTrigger
                value="completed"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Completed
              </TabsTrigger>
              <TabsTrigger
                value="dependencies"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary py-3 px-4"
              >
                Dependencies
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value={activeTab} className="space-y-6 mt-6">
            {loading ? (
              <div className="flex justify-center py-8">
                <LoadingSpinner />
              </div>
            ) : error ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-8">
                  <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
                  <p className="text-center text-muted-foreground">{error}</p>
                  <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
                    Retry
                  </Button>
                </CardContent>
              </Card>
            ) : getHighPriorityTasks().length === 0 &&
              getMediumPriorityTasks().length === 0 &&
              getLowPriorityTasks().length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-8">
                  <CheckSquare className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-center text-muted-foreground">No tasks found</p>
                  <Button className="mt-4">
                    <Plus className="mr-2 h-4 w-4" />
                    Create New Task
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <>
                {getHighPriorityTasks().length > 0 && (
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle>High Priority</CardTitle>
                          <CardDescription>Tasks requiring immediate attention</CardDescription>
                        </div>
                        <Badge variant="destructive" className="px-3 py-1">
                          {getHighPriorityTasks().filter((t) => t.priority === "critical").length} Critical
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {getHighPriorityTasks().map((task) => (
                          <div
                            key={task.id}
                            className="flex items-center justify-between space-x-4 rounded-lg border p-4 hover:bg-muted/50 transition-colors"
                          >
                            <div className="flex items-start space-x-4">
                              <div className={`rounded-full ${getPriorityColor(task.priority)} p-1`}>
                                <AlertCircle className={`h-5 w-5 ${getPriorityTextColor(task.priority)}`} />
                              </div>
                              <div className="space-y-1">
                                <div className="flex items-center space-x-2">
                                  <p className="text-sm font-medium leading-none">{task.title}</p>
                                  {task.tags.map((tag) => (
                                    <Badge key={tag} variant="outline">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                                <p className="text-sm text-muted-foreground">{task.description}</p>
                                <div className="flex flex-wrap items-center gap-2 pt-2">
                                  <div className="flex items-center">
                                    <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      Due {format(new Date(task.due_date), "MMM d, yyyy")}
                                    </span>
                                  </div>
                                  <div className="flex items-center">
                                    <Users className="mr-1 h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      Assigned to {task.assignee_id}
                                    </span>
                                  </div>
                                  {task.dependencies.length > 0 && (
                                    <div className="flex items-center">
                                      <LinkIcon className="mr-1 h-3 w-3 text-muted-foreground" />
                                      <span className="text-xs text-muted-foreground">
                                        {task.dependencies.length} dependencies
                                      </span>
                                    </div>
                                  )}
                                  {task.blocking.length > 0 && (
                                    <div className="flex items-center">
                                      <GitBranch className="mr-1 h-3 w-3 text-muted-foreground" />
                                      <span className="text-xs text-muted-foreground">
                                        Blocks {task.blocking.length} tasks
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {getMediumPriorityTasks().length > 0 && (
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle>Medium Priority</CardTitle>
                          <CardDescription>Tasks to be completed soon</CardDescription>
                        </div>
                        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 px-3 py-1">
                          {getMediumPriorityTasks().length} Tasks
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {getMediumPriorityTasks().map((task) => (
                          <div
                            key={task.id}
                            className="flex items-center justify-between space-x-4 rounded-lg border p-4 hover:bg-muted/50 transition-colors"
                          >
                            <div className="flex items-start space-x-4">
                              <div className="rounded-full bg-amber-100 p-1">
                                <AlertCircle className="h-5 w-5 text-amber-600" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex items-center space-x-2">
                                  <p className="text-sm font-medium leading-none">{task.title}</p>
                                  {task.tags.map((tag) => (
                                    <Badge key={tag} variant="outline">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                                <p className="text-sm text-muted-foreground">{task.description}</p>
                                <div className="flex flex-wrap items-center gap-2 pt-2">
                                  <div className="flex items-center">
                                    <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      Due {format(new Date(task.due_date), "MMM d, yyyy")}
                                    </span>
                                  </div>
                                  <div className="flex items-center">
                                    <Users className="mr-1 h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      Assigned to {task.assignee_id}
                                    </span>
                                  </div>
                                  {task.dependencies.length > 0 && (
                                    <div className="flex items-center">
                                      <LinkIcon className="mr-1 h-3 w-3 text-muted-foreground" />
                                      <span className="text-xs text-muted-foreground">
                                        {task.dependencies.length} dependencies
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {getLowPriorityTasks().length > 0 && (
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle>Low Priority</CardTitle>
                          <CardDescription>Tasks with lower urgency</CardDescription>
                        </div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 px-3 py-1">
                          {getLowPriorityTasks().length} Tasks
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {getLowPriorityTasks().map((task) => (
                          <div
                            key={task.id}
                            className="flex items-center justify-between space-x-4 rounded-lg border p-4 hover:bg-muted/50 transition-colors"
                          >
                            <div className="flex items-start space-x-4">
                              <div className="rounded-full bg-green-100 p-1">
                                <AlertCircle className="h-5 w-5 text-green-600" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex items-center space-x-2">
                                  <p className="text-sm font-medium leading-none">{task.title}</p>
                                  {task.tags.map((tag) => (
                                    <Badge key={tag} variant="outline">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                                <p className="text-sm text-muted-foreground">{task.description}</p>
                                <div className="flex flex-wrap items-center gap-2 pt-2">
                                  <div className="flex items-center">
                                    <Clock className="mr-1 h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      Due {format(new Date(task.due_date), "MMM d, yyyy")}
                                    </span>
                                  </div>
                                  <div className="flex items-center">
                                    <Users className="mr-1 h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">
                                      Assigned to {task.assignee_id}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </TabsContent>
          <TabsContent value="dependencies" className="space-y-6 mt-6">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Task Dependencies</CardTitle>
                    <CardDescription>Visualize and manage task dependencies</CardDescription>
                  </div>
                  <Button variant="outline" size="sm">
                    <GitBranch className="mr-2 h-4 w-4" />
                    Manage Dependencies
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <LoadingSpinner />
                  </div>
                ) : error ? (
                  <div className="text-center py-8 text-red-500">
                    <p>{error}</p>
                    <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
                      Retry
                    </Button>
                  </div>
                ) : tasks.filter((t) => t.dependencies.length > 0 || t.blocking.length > 0).length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No task dependencies found</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="rounded-lg border p-4">
                      <h3 className="text-sm font-medium mb-2">Authentication System</h3>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-red-500">
                          <CheckSquare className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">Implement OAuth provider</span>
                          <Badge variant="outline" className="ml-auto">
                            Completed
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-red-500">
                          <CheckSquare className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">Create authentication middleware</span>
                          <Badge variant="outline" className="ml-auto">
                            Completed
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-red-500">
                          <AlertCircle className="h-4 w-4 text-red-500" />
                          <span className="text-sm font-medium">Fix authentication bug</span>
                          <Badge className="ml-auto bg-red-500">Blocking</Badge>
                        </div>
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-gray-300">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Implement user roles and permissions</span>
                          <Badge variant="outline" className="ml-auto">
                            Waiting
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-gray-300">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Add multi-factor authentication</span>
                          <Badge variant="outline" className="ml-auto">
                            Waiting
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-lg border p-4">
                      <h3 className="text-sm font-medium mb-2">Frontend Components</h3>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-amber-500">
                          <CheckSquare className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">Design component library</span>
                          <Badge variant="outline" className="ml-auto">
                            Completed
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-amber-500">
                          <AlertCircle className="h-4 w-4 text-amber-500" />
                          <span className="text-sm font-medium">Review pull request #42</span>
                          <Badge className="ml-auto bg-amber-500">In Progress</Badge>
                        </div>
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-gray-300">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Implement dashboard widgets</span>
                          <Badge variant="outline" className="ml-auto">
                            Waiting
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2 pl-4 border-l-2 border-gray-300">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Create responsive layouts</span>
                          <Badge variant="outline" className="ml-auto">
                            Waiting
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </SharedLayout>
  )
}
