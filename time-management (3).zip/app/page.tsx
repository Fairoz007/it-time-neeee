import Link from "next/link"
import { ClientRedirect } from "./client-redirect"

export default function Home() {
  return (
    <>
      <ClientRedirect />
      <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-background to-muted p-4">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">DevTimeTracker</h1>
          <p className="mb-6 text-muted-foreground">Advanced time management for IT professionals</p>
          <Link
            href="/dashboard"
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
          >
            Go to Dashboard
          </Link>
        </div>
      </div>
    </>
  )
}
